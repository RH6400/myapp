#!/usr/bin/env bash
# ব্যবহার: Flutter ইনস্টল থাকা কম্পিউটারে এই ফোল্ডারের ভিতরে চালান।
set -e
flutter create --org com.example --project-name routine_coach --platforms=android .
python3 - <<'PY'
import re, pathlib
# 1) minSdk ২৩ করা (alarm প্যাকেজের জন্য)
for name in ("android/app/build.gradle", "android/app/build.gradle.kts"):
    p = pathlib.Path(name)
    if p.exists():
        s = p.read_text()
        s = re.sub(r"minSdk(Version)?\s*=?\s*flutter\.minSdkVersion", "minSdk = 23", s)
        p.write_text(s)
# 2) পারমিশন
m = pathlib.Path("android/app/src/main/AndroidManifest.xml")
s = m.read_text()
perms = """    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/>
    <uses-permission android:name="android.permission.USE_EXACT_ALARM"/>
    <uses-permission android:name="android.permission.USE_FULL_SCREEN_INTENT"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.VIBRATE"/>
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
    <uses-permission android:name="android.permission.INTERNET"/>
"""
if "SCHEDULE_EXACT_ALARM" not in s:
    s = s.replace("<application", perms + "    <application", 1)
    m.write_text(s)
PY
flutter pub get
echo "প্রস্তুত! ফোন/এমুলেটর যুক্ত করে চালান: flutter run"
