#!/usr/bin/env bash
# GitHub Actions এই ফাইল চালায় (src/routine_coach ফোল্ডারের ভেতরে)।
# repo-র রুটে google-services.json থাকলে Firebase চালু হয়; না থাকলে অ্যাপ শুধু ফোনে চলে।
set -e
flutter create --org com.rh6400 --project-name routine_coach --platforms=android .

python3 - <<'PY'
import json, os, pathlib, re

# ---------- Gradle ----------
gradle = None
for name in ("android/app/build.gradle.kts", "android/app/build.gradle"):
    p = pathlib.Path(name)
    if p.exists():
        gradle = p
        break
if gradle is None:
    raise SystemExit("android/app/build.gradle(.kts) not found")
kts = gradle.name.endswith(".kts")
s = gradle.read_text()

# minSdk 23
s = re.sub(r"minSdk(Version)?\s*=?\s*flutter\.minSdkVersion", "minSdk = 23", s)

# applicationId
new_id = 'applicationId = "com.rh6400.uthan"' if kts else 'applicationId "com.rh6400.uthan"'
s, n = re.subn(r'applicationId\s*=?\s*["\'][^"\']+["\']', new_id, s, count=1)
if n == 0:
    raise SystemExit("applicationId not found in gradle file")

# core library desugaring (flutter_local_notifications)
if "compileOptions {" not in s:
    raise SystemExit("compileOptions block not found in gradle file")
if kts:
    s = s.replace("compileOptions {", "compileOptions {\n        isCoreLibraryDesugaringEnabled = true", 1)
    s += '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n'
else:
    s = s.replace("compileOptions {", "compileOptions {\n        coreLibraryDesugaringEnabled true", 1)
    s += "\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n}\n"

# স্থায়ী সাইন-কী (শুধু GitHub secret সেট করা থাকলে)
ks = os.environ.get("UTHAN_KEYSTORE")
if ks and os.path.exists(ks):
    if kts:
        block = (
            "    signingConfigs {\n"
            '        create("uthan") {\n'
            '            storeFile = file(System.getenv("UTHAN_KEYSTORE"))\n'
            '            storePassword = System.getenv("UTHAN_PASS")\n'
            '            keyAlias = "uthan"\n'
            '            keyPassword = System.getenv("UTHAN_PASS")\n'
            "        }\n"
            "    }\n"
        )
        s = s.replace("android {", "android {\n" + block, 1)
        s = s.replace('signingConfigs.getByName("debug")', 'signingConfigs.getByName("uthan")')
    else:
        block = (
            "    signingConfigs {\n"
            "        uthan {\n"
            '            storeFile file(System.getenv("UTHAN_KEYSTORE"))\n'
            '            storePassword System.getenv("UTHAN_PASS")\n'
            '            keyAlias "uthan"\n'
            '            keyPassword System.getenv("UTHAN_PASS")\n'
            "        }\n"
            "    }\n"
        )
        s = s.replace("android {", "android {\n" + block, 1)
        s = s.replace("signingConfig signingConfigs.debug", "signingConfig signingConfigs.uthan")
    print("signing: stable keystore enabled")
else:
    print("signing: debug key (no keystore secret)")
gradle.write_text(s)

# ---------- Manifest ----------
m = pathlib.Path("android/app/src/main/AndroidManifest.xml")
s = m.read_text()
perms = [
    "POST_NOTIFICATIONS", "SCHEDULE_EXACT_ALARM", "USE_EXACT_ALARM", "USE_FULL_SCREEN_INTENT",
    "WAKE_LOCK", "VIBRATE", "RECEIVE_BOOT_COMPLETED", "INTERNET", "REQUEST_IGNORE_BATTERY_OPTIMIZATIONS",
]
add = "".join(
    '    <uses-permission android:name="android.permission.%s"/>\n' % x
    for x in perms
    if 'android.permission.%s"' % x not in s
)
s = s.replace("<application", add + "    <application", 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="Uthan"', s, count=1)
recv = (
    '        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />\n'
    '        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">\n'
    "            <intent-filter>\n"
    '                <action android:name="android.intent.action.BOOT_COMPLETED"/>\n'
    '                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>\n'
    '                <action android:name="android.intent.action.QUICKBOOT_POWERON" />\n'
    '                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>\n'
    "            </intent-filter>\n"
    "        </receiver>\n"
)
if "ScheduledNotificationReceiver" not in s:
    s = s.replace("</application>", recv + "    </application>", 1)
m.write_text(s)

# ---------- Firebase কনফিগ (google-services.json থাকলে) ----------
gj = pathlib.Path(os.environ.get("GSJ", "../../google-services.json"))
cfg = pathlib.Path("lib/firebase_config.dart")
if gj.exists():
    j = json.loads(gj.read_text())
    pi = j["project_info"]
    cl = j["client"][0]
    for c in j["client"]:
        if c["client_info"]["android_client_info"]["package_name"] == "com.rh6400.uthan":
            cl = c
    web = ""
    for o in cl.get("oauth_client", []):
        if o.get("client_type") == 3:
            web = o["client_id"]
    cfg.write_text(
        "// setup.sh তৈরি করেছে (google-services.json থেকে)।\n"
        "const String kFirebaseApiKey = '%s';\n"
        "const String kFirebaseAppId = '%s';\n"
        "const String kFirebaseSenderId = '%s';\n"
        "const String kFirebaseProjectId = '%s';\n"
        "const String kWebClientId = '%s';\n"
        % (
            cl["api_key"][0]["current_key"],
            cl["client_info"]["mobilesdk_app_id"],
            pi["project_number"],
            pi["project_id"],
            web,
        )
    )
    print("firebase: configured for project", pi["project_id"])
else:
    print("firebase: google-services.json not found, app runs without online features")
PY

flutter pub get
echo "setup done"
