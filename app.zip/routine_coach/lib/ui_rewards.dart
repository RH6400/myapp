import 'dart:math';
import 'package:flutter/material.dart';
import 'cloud.dart';
import 'i18n.dart';
import 'state.dart';
import 'ui_common.dart';

class RewardsTab extends StatelessWidget {
  const RewardsTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final cs = Theme.of(context).colorScheme;
        final w = app.weekStats();
        final pct = w[1] == 0 ? 0.0 : w[0] / w[1];
        final hrs = w[2] ~/ 60;
        final mins = w[2] % 60;
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${L('লেভেল', 'Level')} ${app.level} • ${app.xp} XP',
                      style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(value: app.xpIntoLevel / 200, minHeight: 8),
                  const SizedBox(height: 6),
                  Text('${200 - app.xpIntoLevel} XP ${L('বাকি পরের লেভেলে', 'to the next level')}',
                      style: TextStyle(color: cs.onSurfaceVariant)),
                ]),
              ),
            ),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(L('গত ৭ দিন', 'Last 7 days'), style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(value: pct, minHeight: 8),
                  const SizedBox(height: 6),
                  Text(
                    '${L('শেষ করা কাজ', 'Tasks done')} ${w[0]}/${w[1]} • ${L('ফোকাস', 'Focus')} $hrs${L(' ঘণ্টা ', ' h ')}$mins${L(' মিনিট', ' min')}',
                    style: TextStyle(color: cs.onSurfaceVariant),
                  ),
                  const SizedBox(height: 4),
                  Text('${L('স্ট্রিক', 'Streak')}: ${app.streak} ${L('দিন', 'days')}',
                      style: TextStyle(color: cs.onSurfaceVariant)),
                ]),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(4, 12, 4, 8),
              child: Text(L('অর্জন', 'Achievements'), style: Theme.of(context).textTheme.titleMedium),
            ),
            for (final a in achievementList)
              Builder(builder: (context) {
                final ok = app.unlocked.contains(a.id);
                final v = min(a.value(app), a.target);
                return Card(
                  color: ok ? cs.primaryContainer : null,
                  child: ListTile(
                    leading: Text(ok ? a.icon : '🔒', style: const TextStyle(fontSize: 26)),
                    title: Text(t('ach.${a.id}.t')),
                    subtitle: Text('${t('ach.${a.id}.d')}  ($v/${a.target})'),
                    trailing: ok
                        ? IconButton(
                            icon: const Icon(Icons.share),
                            tooltip: L('কমিউনিটিতে পোস্ট', 'Post to community'),
                            onPressed: () async {
                              if (!cloud.signedIn) {
                                snack(context, L('পোস্ট করতে আগে Google দিয়ে লগইন করুন (সেটিংসে)', 'Sign in with Google first (in Settings)'));
                                return;
                              }
                              final err = await cloud.createPost(
                                type: 'achievement',
                                text: '${a.icon} ${t('ach.${a.id}.t')}',
                                items: const [],
                                audience: app.prefs.audience,
                              );
                              if (context.mounted) {
                                snack(context, err ?? L('পোস্ট হয়েছে', 'Posted'));
                              }
                            },
                          )
                        : null,
                  ),
                );
              }),
          ],
        );
      },
    );
  }
}
