import 'package:flutter/material.dart';
import 'state.dart';

class RewardsTab extends StatelessWidget {
  const RewardsTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final cs = Theme.of(context).colorScheme;
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              color: cs.primaryContainer,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(children: [
                  Text('লেভেল ${app.level}',
                      style: Theme.of(context).textTheme.headlineMedium),
                  const SizedBox(height: 8),
                  Text('মোট ${app.xp} XP • 🔥 স্ট্রিক ${app.streak} দিন'),
                  const SizedBox(height: 12),
                  LinearProgressIndicator(value: app.xpIntoLevel / 200, minHeight: 10),
                  const SizedBox(height: 6),
                  Text('পরের লেভেলে যেতে আর ${200 - app.xpIntoLevel} XP'),
                ]),
              ),
            ),
            const SizedBox(height: 16),
            Text('অর্জন', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            for (final a in achievementList) _AchievementCard(a: a),
          ],
        );
      },
    );
  }
}

class _AchievementCard extends StatelessWidget {
  final Achievement a;
  const _AchievementCard({required this.a});

  @override
  Widget build(BuildContext context) {
    final v = a.value(app);
    final unlocked = app.unlocked.contains(a.id);
    final shown = v > a.target ? a.target : v;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(children: [
          Opacity(opacity: unlocked ? 1 : 0.35, child: Text(a.icon, style: const TextStyle(fontSize: 36))),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(a.title, style: Theme.of(context).textTheme.titleMedium),
              Text(a.desc, style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 6),
              LinearProgressIndicator(value: shown / a.target),
              const SizedBox(height: 2),
              Text(unlocked ? '✅ সম্পন্ন' : '$shown / ${a.target}',
                  style: Theme.of(context).textTheme.bodySmall),
            ]),
          ),
        ]),
      ),
    );
  }
}
