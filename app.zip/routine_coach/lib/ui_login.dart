import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'cloud.dart';
import 'i18n.dart';
import 'mailo_pet.dart';
import 'notif.dart';
import 'state.dart';
import 'theme.dart';
import 'ui_common.dart';

/// প্রথমবার খুললে এই স্ক্রিন। Google দিয়ে ঢুকলে আগের ডাটা ক্লাউড থেকে ফিরে আসে।
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool busy = false;

  Future<void> _finish() async {
    app.prefs.onboarded = true;
    await app.savePrefs();
    try {
      await notif.requestPermission();
      if (!await Permission.scheduleExactAlarm.isGranted) {
        await Permission.scheduleExactAlarm.request();
      }
    } catch (_) {}
    await app.replan(force: true);
    notif.refreshSoon();
  }

  Future<void> _google() async {
    setState(() => busy = true);
    final err = await cloud.signInWithGoogle();
    if (!mounted) return;
    setState(() => busy = false);
    if (err != null) {
      snack(context, err);
      return;
    }
    await _finish();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final p = Pal.of(context);
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Align(
                alignment: Alignment.centerRight,
                child: SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'bn', label: Text('বাংলা')),
                    ButtonSegment(value: 'en', label: Text('English')),
                  ],
                  selected: {app.prefs.lang},
                  onSelectionChanged: (s) async {
                    app.prefs.lang = s.first;
                    gLang = s.first;
                    await app.savePrefs();
                    if (mounted) setState(() {});
                  },
                ),
              ),
              const Spacer(),
              const Center(child: MailoPet(size: 150)),
              const SizedBox(height: 12),
              Text('Mailo',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: p.tx, fontSize: 32, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text('Plan Today. Live Better.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: p.pri, fontSize: 14, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              Text(
                L('আপনার দিন সাজাবে আপনার সহকারী Mailo।',
                    'Mailo, your assistant, helps you plan your day.'),
                textAlign: TextAlign.center,
                style: TextStyle(color: cs.onSurfaceVariant),
              ),
              const Spacer(),
              if (Cloud.configured)
                FilledButton.icon(
                  onPressed: busy ? null : _google,
                  icon: busy
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.login),
                  label: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: Text(L('Google দিয়ে চালিয়ে যান', 'Continue with Google')),
                  ),
                )
              else
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(
                    L('অনলাইন লগইন এখনো চালু হয়নি। আপাতত শুধু এই ফোনে চলবে।',
                        'Online sign-in is not enabled yet. For now the app works on this phone only.'),
                    textAlign: TextAlign.center,
                    style: TextStyle(color: cs.onSurfaceVariant),
                  ),
                ),
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: busy ? null : _finish,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Text(L('লগইন ছাড়া চালান', 'Continue without signing in')),
                ),
              ),
              const SizedBox(height: 12),
              Text(
                L('লগইন করলে ফোন বদলালেও আপনার কাজ, লক্ষ্য ও সেটিং ফিরে আসবে।',
                    'Sign in and your tasks, goals and settings come back on any phone.'),
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
