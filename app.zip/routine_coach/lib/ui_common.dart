import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'i18n.dart';
import 'models.dart';
import 'theme.dart';

void snack(BuildContext c, String m) {
  ScaffoldMessenger.of(c)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(m)));
}

Future<int?> pickTime(BuildContext c, int initialMin) async {
  final r = await showTimePicker(
    context: c,
    initialTime: TimeOfDay(hour: (initialMin ~/ 60) % 24, minute: initialMin % 60),
  );
  if (r == null) return null;
  return r.hour * 60 + r.minute;
}

// ---------- ফোনের নেভিগেশন বারের জায়গা ----------

/// তালিকার নিচে ফোনের নেভিগেশন বারের জায়গা ছেড়ে দেয়।
EdgeInsets listPad(BuildContext c, {double top = 8, double bottom = 24}) {
  final mq = MediaQuery.of(c);
  return EdgeInsets.fromLTRB(16, top, 16, bottom + mq.viewPadding.bottom);
}

/// নিচ থেকে ওঠা শীট: ওপরে সেফ-এরিয়া, নিচে নেভিগেশন বার/কিবোর্ডের জায়গা।
Future<T?> showMailoSheet<T>(BuildContext context, WidgetBuilder builder) {
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    showDragHandle: true,
    backgroundColor: Pal.of(context).card,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    builder: builder,
  );
}

/// শীটের ভেতরের কনটেন্ট মুড়ে দেয়: স্ক্রল হয়, নিচে কিবোর্ড ও নেভিগেশন বারের জায়গা থাকে।
class SheetBody extends StatelessWidget {
  final Widget child;
  const SheetBody({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final bottom = math.max(mq.viewInsets.bottom, mq.viewPadding.bottom);
    return SingleChildScrollView(
      padding: EdgeInsets.fromLTRB(18, 0, 18, 16 + bottom),
      child: child,
    );
  }
}

// ---------- ডায়ালগ ----------

/// একটা তালিকা থেকে একটি বেছে নেওয়ার ডায়ালগ।
Future<T?> pickOne<T>(BuildContext c, String title, Map<T, String> options, T current) {
  return showDialog<T>(
    context: c,
    builder: (ctx) => SimpleDialog(
      title: Text(title),
      children: [
        for (final e in options.entries)
          SimpleDialogOption(
            onPressed: () => Navigator.pop(ctx, e.key),
            child: Row(children: [
              Expanded(child: Text(e.value)),
              if (e.key == current) Icon(Icons.check, size: 18, color: Pal.of(ctx).pri),
            ]),
          ),
      ],
    ),
  );
}

Future<bool> confirm(BuildContext c, String title, String body, {String? yes}) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(body),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(L('না', 'No'))),
        TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(yes ?? L('হ্যাঁ', 'Yes'))),
      ],
    ),
  );
  return r == true;
}

Future<String?> askText(BuildContext c, String title, String initial, {String? hint, int maxLen = 40}) async {
  final ctl = TextEditingController(text: initial);
  final r = await showDialog<String>(
    context: c,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: ctl,
        autofocus: true,
        maxLength: maxLen,
        decoration: InputDecoration(hintText: hint),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: Text(L('বাতিল', 'Cancel'))),
        TextButton(onPressed: () => Navigator.pop(ctx, ctl.text.trim()), child: Text(L('সংরক্ষণ', 'Save'))),
      ],
    ),
  );
  ctl.dispose();
  return r;
}

// ---------- ছোট উপাদান ----------

/// সাদা কার্ড, পাতলা বর্ডার, রঙিন কার্ড নেই।
class MCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  final Color? color;
  final Color? border;
  final EdgeInsets margin;
  const MCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.onTap,
    this.color,
    this.border,
    this.margin = EdgeInsets.zero,
  });

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final deco = BoxDecoration(
      color: color ?? p.card,
      borderRadius: BorderRadius.circular(18),
      border: Border.all(color: border ?? p.line),
    );
    return Padding(
      padding: margin,
      child: Material(
        color: Colors.transparent,
        child: Ink(
          decoration: deco,
          child: InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: onTap,
            child: Padding(padding: padding, child: child),
          ),
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  final Widget? trailing;
  const SectionTitle(this.text, {super.key, this.trailing});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 16, 4, 6),
      child: Row(children: [
        Expanded(
          child: Text(text, style: TextStyle(color: p.pri, fontSize: 13, fontWeight: FontWeight.w700)),
        ),
        if (trailing != null) trailing!,
      ]),
    );
  }
}

/// সেটিংসের গ্রুপ: কার্ডের ভেতর সারি সারি টাইল।
class SettingGroup extends StatelessWidget {
  final List<Widget> children;
  const SettingGroup({super.key, required this.children});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final rows = <Widget>[];
    for (var i = 0; i < children.length; i++) {
      rows.add(children[i]);
      if (i != children.length - 1) {
        rows.add(Divider(height: 1, thickness: 1, color: p.line, indent: 62));
      }
    }
    return Container(
      decoration: BoxDecoration(
        color: p.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: p.line),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(children: rows),
    );
  }
}

class IconTile extends StatelessWidget {
  final IconData icon;
  final Color? color;
  final Color? bg;
  const IconTile(this.icon, {super.key, this.color, this.bg});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return Container(
      width: 36,
      height: 36,
      decoration: BoxDecoration(color: bg ?? p.priSoft, borderRadius: BorderRadius.circular(11)),
      child: Icon(icon, size: 20, color: color ?? p.pri),
    );
  }
}

/// বাঁদিকে আইকন, ডানে বর্তমান মান বা সুইচ: সাধারণ অ্যাপের সেটিংসের মতো।
class SettingTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final String? value;
  final Widget? trailing;
  final VoidCallback? onTap;
  final bool danger;
  const SettingTile({
    super.key,
    required this.icon,
    required this.title,
    this.subtitle,
    this.value,
    this.trailing,
    this.onTap,
    this.danger = false,
  });

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final tc = danger ? p.bad : p.tx;
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        child: Row(children: [
          IconTile(icon, color: danger ? p.bad : null, bg: danger ? p.badSoft : null),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: TextStyle(color: tc, fontSize: 14.5, fontWeight: FontWeight.w500)),
              if (subtitle != null && subtitle!.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Text(subtitle!, style: TextStyle(color: p.sub, fontSize: 12)),
                ),
            ]),
          ),
          if (value != null)
            Flexible(
              child: Padding(
                padding: const EdgeInsets.only(left: 8),
                child: Text(value!,
                    textAlign: TextAlign.end,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: p.sub, fontSize: 13)),
              ),
            ),
          if (trailing != null) trailing!,
          if (trailing == null && onTap != null && value == null)
            Icon(Icons.chevron_right, color: p.sub, size: 22),
        ]),
      ),
    );
  }
}

class SwitchTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final bool value;
  final ValueChanged<bool>? onChanged;
  const SwitchTile({
    super.key,
    required this.icon,
    required this.title,
    this.subtitle,
    required this.value,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return SettingTile(
      icon: icon,
      title: title,
      subtitle: subtitle,
      onTap: onChanged == null ? null : () => onChanged!(!value),
      trailing: Switch(value: value, onChanged: onChanged),
    );
  }
}

class StatusTag extends StatelessWidget {
  final String text;
  final Color color;
  final Color bg;
  const StatusTag(this.text, {super.key, required this.color, required this.bg});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(10)),
      child: Text(text, style: TextStyle(color: color, fontSize: 11.5, fontWeight: FontWeight.w700)),
    );
  }
}

class Bar extends StatelessWidget {
  final double value;
  final Color? color;
  final double height;
  const Bar(this.value, {super.key, this.color, this.height = 8});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return ClipRRect(
      borderRadius: BorderRadius.circular(height),
      child: LinearProgressIndicator(
        value: value.clamp(0.0, 1.0),
        minHeight: height,
        backgroundColor: p.line,
        valueColor: AlwaysStoppedAnimation<Color>(color ?? p.pri),
      ),
    );
  }
}

/// গোল প্রগ্রেস রিং (মাঝে লেখা)।
class Ring extends StatelessWidget {
  final double value;
  final String label;
  final double size;
  const Ring({super.key, required this.value, required this.label, this.size = 64});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return SizedBox(
      width: size,
      height: size,
      child: Stack(alignment: Alignment.center, children: [
        SizedBox.expand(
          child: CircularProgressIndicator(
            value: value.clamp(0.0, 1.0),
            strokeWidth: 7,
            backgroundColor: p.line,
            valueColor: AlwaysStoppedAnimation<Color>(p.pri),
            strokeCap: StrokeCap.round,
          ),
        ),
        Text(label, style: TextStyle(color: p.tx, fontSize: 14, fontWeight: FontWeight.w700)),
      ]),
    );
  }
}

/// স্ক্রিনের বড় শিরোনাম সারি (AppBar ছাড়া)।
class ScreenHeader extends StatelessWidget {
  final String title;
  final Widget? leading;
  final List<Widget> actions;
  const ScreenHeader(this.title, {super.key, this.leading, this.actions = const []});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 8, 6),
      child: Row(children: [
        if (leading != null) leading!,
        Expanded(
          child: Text(title, style: TextStyle(color: p.tx, fontSize: 22, fontWeight: FontWeight.w700)),
        ),
        ...actions,
      ]),
    );
  }
}

String weekdayName(int d, {bool short = true}) {
  const bn = ['সোম', 'মঙ্গল', 'বুধ', 'বৃহ', 'শুক্র', 'শনি', 'রবি'];
  const en = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  return (gLang == 'en' ? en : bn)[(d - 1) % 7];
}

String alertLabel(String k) {
  switch (k) {
    case 'alarm':
      return L('অ্যালার্ম (সাউন্ড)', 'Alarm (sound)');
    case 'vibrate':
      return L('ভাইব্রেশন', 'Vibration');
    case 'notify':
      return L('শুধু নোটিফিকেশন', 'Notification only');
    default:
      return L('সাধারণ সেটিং', 'Default');
  }
}

String alertShort(String k) {
  switch (k) {
    case 'alarm':
      return L('অ্যালার্ম', 'Alarm');
    case 'vibrate':
      return L('ভাইব্রেশন', 'Vibrate');
    case 'notify':
      return L('নোটিফিকেশন', 'Notify');
    default:
      return L('সাধারণ', 'Default');
  }
}

String alertHint(String k) {
  switch (k) {
    case 'alarm':
      return L('সাউন্ড, ভাইব্রেশন ও লক স্ক্রিনে ফুল-স্ক্রিন', 'Sound, vibration and full screen over the lock screen');
    case 'vibrate':
      return L('নিঃশব্দ, ভাইব্রেশন ও ফুল-স্ক্রিন', 'Silent, vibration and full screen');
    case 'notify':
      return L('নিঃশব্দ, শুধু নোটিফিকেশন', 'Silent, notification only');
    default:
      return '';
  }
}

IconData alertIcon(String k) {
  switch (k) {
    case 'alarm':
      return Icons.alarm;
    case 'vibrate':
      return Icons.vibration;
    case 'notify':
      return Icons.notifications_none;
    default:
      return Icons.tune;
  }
}

String forceLabel(String k) {
  switch (k) {
    case 'soft':
      return L('নরম', 'Soft');
    case 'mid':
      return L('মাঝারি', 'Medium');
    case 'hard':
      return L('কড়া', 'Strict');
    case 'own':
      return L('নিজের মতো', 'Custom');
    default:
      return L('সাধারণ সেটিং', 'Default');
  }
}

String forceHint(String k) {
  switch (k) {
    case 'soft':
      return L('স্নুজ ৫ বার, জরিমানা নেই, যেকোনো সময় শেষ করা যায়', '5 snoozes, no penalty, finish any time');
    case 'mid':
      return L('স্নুজ ২ বার, ৮০% সময় পরে শেষ, XP কাটা', '2 snoozes, finish after 80% time, XP penalty');
    case 'hard':
      return L('স্নুজ নেই, পুরো সময় না কাটলে শেষ করা যায় না', 'No snooze, cannot finish before the full time');
    case 'own':
      return L('প্রতিটা সেটিং নিজে ঠিক করুন', 'Set every option yourself');
    default:
      return '';
  }
}

String moodLabel(String k) {
  switch (k) {
    case 'quiet':
      return L('চুপচাপ', 'Quiet');
    case 'chatty':
      return L('বেশি কথা', 'Chatty');
    case 'coach':
      return L('কড়া কোচ', 'Strict coach');
    default:
      return L('সাধারণ', 'Normal');
  }
}

String partLabel(int p) {
  switch (p) {
    case 1:
      return L('সকাল', 'Morning');
    case 2:
      return L('দুপুর', 'Noon');
    case 3:
      return L('সন্ধ্যা/রাত', 'Evening');
    default:
      return L('যেকোনো সময়', 'Any time');
  }
}

String whenLabel(TaskItem t) {
  final days = t.onDate != null
      ? L('একদিন', 'one day')
      : (t.days.isEmpty ? L('প্রতিদিন', 'every day') : t.days.map(weekdayName).join(', '));
  if (t.fixedMin != null) return '${fmtMin(t.fixedMin!)} • $days';
  return '${L('ফ্রি সময়ে অটো', 'auto in free time')} • $days';
}

String goalStatusLabel(String s) {
  switch (s) {
    case 'done':
      return L('পূরণ হয়েছে', 'Done');
    case 'on':
      return L('ঠিক পথে', 'On track');
    case 'slight':
      return L('একটু পিছিয়ে', 'Slightly behind');
    default:
      return L('পিছিয়ে', 'Behind');
  }
}

Color goalStatusColor(Pal p, String s) {
  switch (s) {
    case 'done':
    case 'on':
      return p.ok;
    case 'slight':
      return p.fire;
    default:
      return p.bad;
  }
}

Color goalStatusBg(Pal p, String s) {
  switch (s) {
    case 'done':
    case 'on':
      return p.okSoft;
    case 'slight':
      return p.fireSoft;
    default:
      return p.badSoft;
  }
}
