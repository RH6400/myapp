import 'package:flutter/material.dart';
import 'i18n.dart';
import 'models.dart';

void snack(BuildContext c, String m) {
  ScaffoldMessenger.of(c)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(m)));
}

Future<int?> pickTime(BuildContext c, int initialMin) async {
  final r = await showTimePicker(
    context: c,
    initialTime: TimeOfDay(hour: (initialMin ~/ 60) % 24, minute: initialMin % 60),
  );
  if (r == null) return null;
  return r.hour * 60 + r.minute;
}

/// একটা তালিকা থেকে একটি বেছে নেওয়ার ডায়ালগ।
Future<T?> pickOne<T>(BuildContext c, String title, Map<T, String> options, T current) {
  return showDialog<T>(
    context: c,
    builder: (ctx) => SimpleDialog(
      title: Text(title),
      children: [
        for (final e in options.entries)
          SimpleDialogOption(
            onPressed: () => Navigator.pop(ctx, e.key),
            child: Row(children: [
              Expanded(child: Text(e.value)),
              if (e.key == current) const Icon(Icons.check, size: 18),
            ]),
          ),
      ],
    ),
  );
}

Future<bool> confirm(BuildContext c, String title, String body, {String? yes}) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(body),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(L('না', 'No'))),
        TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(yes ?? L('হ্যাঁ', 'Yes'))),
      ],
    ),
  );
  return r == true;
}

/// সেটিংসের গ্রুপের শিরোনাম।
Widget groupTitle(BuildContext c, String s) => Padding(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 6),
      child: Text(s,
          style: Theme.of(c)
              .textTheme
              .labelLarge
              ?.copyWith(color: Theme.of(c).colorScheme.primary, fontWeight: FontWeight.w600)),
    );

String weekdayName(int d, {bool short = true}) {
  const bn = ['সোম', 'মঙ্গল', 'বুধ', 'বৃহ', 'শুক্র', 'শনি', 'রবি'];
  const en = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  return (gLang == 'en' ? en : bn)[(d - 1) % 7];
}

String alertLabel(String k) {
  switch (k) {
    case 'alarm':
      return L('অ্যালার্ম (সাউন্ড)', 'Alarm (sound)');
    case 'vibrate':
      return L('ভাইব্রেশন', 'Vibration');
    case 'notify':
      return L('শুধু নোটিফিকেশন', 'Notification only');
    default:
      return L('সাধারণ সেটিং', 'Default');
  }
}

String alertHint(String k) {
  switch (k) {
    case 'alarm':
      return L('সাউন্ড, ভাইব্রেশন ও লক স্ক্রিনে ফুল-স্ক্রিন', 'Sound, vibration and full screen over the lock screen');
    case 'vibrate':
      return L('নিঃশব্দ, ভাইব্রেশন ও ফুল-স্ক্রিন', 'Silent, vibration and full screen');
    case 'notify':
      return L('নিঃশব্দ, শুধু নোটিফিকেশন', 'Silent, notification only');
    default:
      return '';
  }
}

IconData alertIcon(String k) {
  switch (k) {
    case 'alarm':
      return Icons.alarm;
    case 'vibrate':
      return Icons.vibration;
    case 'notify':
      return Icons.notifications_none;
    default:
      return Icons.tune;
  }
}

String forceLabel(String k) {
  switch (k) {
    case 'soft':
      return L('নরম', 'Soft');
    case 'mid':
      return L('মাঝারি', 'Medium');
    case 'hard':
      return L('কড়া', 'Strict');
    case 'own':
      return L('নিজের মতো', 'Custom');
    default:
      return L('সাধারণ সেটিং', 'Default');
  }
}

String forceHint(String k) {
  switch (k) {
    case 'soft':
      return L('স্নুজ ৫ বার, জরিমানা নেই, যেকোনো সময় শেষ করা যায়', '5 snoozes, no penalty, finish any time');
    case 'mid':
      return L('স্নুজ ২ বার, ৮০% সময় পরে শেষ, XP কাটা', '2 snoozes, finish after 80% time, XP penalty');
    case 'hard':
      return L('স্নুজ নেই, পুরো সময় না কাটলে শেষ করা যায় না', 'No snooze, cannot finish before the full time');
    case 'own':
      return L('প্রতিটা সেটিং নিজে ঠিক করুন', 'Set every option yourself');
    default:
      return '';
  }
}

String moodLabel(String k) {
  switch (k) {
    case 'quiet':
      return L('চুপচাপ', 'Quiet');
    case 'chatty':
      return L('বেশি কথা', 'Chatty');
    case 'coach':
      return L('কড়া কোচ', 'Strict coach');
    default:
      return L('সাধারণ', 'Normal');
  }
}

String partLabel(int p) {
  switch (p) {
    case 1:
      return L('সকাল', 'Morning');
    case 2:
      return L('দুপুর', 'Noon');
    case 3:
      return L('সন্ধ্যা/রাত', 'Evening');
    default:
      return L('যেকোনো সময়', 'Any time');
  }
}

String whenLabel(TaskItem t) {
  final days = t.onDate != null
      ? L('একদিন', 'one day')
      : (t.days.isEmpty ? L('প্রতিদিন', 'every day') : t.days.map(weekdayName).join(' '));
  if (t.fixedMin != null) return '${fmtMin(t.fixedMin!)} • $days';
  return '${L('ফ্রি সময়ে অটো', 'auto in free time')} • $days';
}
