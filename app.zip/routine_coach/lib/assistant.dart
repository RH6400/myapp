import 'dart:convert';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'ai.dart';
import 'i18n.dart';
import 'insights.dart';
import 'models.dart';
import 'state.dart';

/// চ্যাটের নিচের বাটন: [cmd] পাঠালে সহকারী সেটা কমান্ড হিসেবে বোঝে।
class ChatChip {
  final String label;
  final String cmd;
  const ChatChip(this.label, this.cmd);
}

class ChatMsg {
  final bool user;
  final String text;
  final List<ChatChip> chips;
  ChatMsg(this.user, this.text, [this.chips = const []]);
}

class _R {
  final String text;
  final List<ChatChip> chips;
  final bool tone;
  const _R(this.text, [this.chips = const [], this.tone = false]);
}

class _P {
  String? title;
  int? minutes;
  int? time; // মধ্যরাত থেকে মিনিট
  bool amb = false;
  int ambHour = 0;
  int ambMin = 0;
  bool daily = false;
  bool once = false;
}

class _Tm {
  final int start, end, hour, minute;
  final int? min;
  final bool amb;
  const _Tm(this.start, this.end, this.hour, this.minute, this.min, this.amb);
}

final assistant = Assistant();

/// Mailo (সহকারী): অফলাইনে সহজ বাক্য বোঝে; AI চালু থাকলে জটিল কথা ও লক্ষ্যের প্ল্যানও বোঝে।
/// ইউজার মেসেজ দিয়ে শেখাতে পারে ("এখন থেকে ...")। শেখানো নিয়মগুলো `prefs.customRules`-এ থাকে।
/// দুই ক্ষেত্রেই কাজ যোগ, সময় বদল ও "আজ করব না" সত্যিই রুটিন বদলায়।
class Assistant extends ChangeNotifier {
  final List<ChatMsg> msgs = [];
  bool busy = false;
  bool _greeted = false;
  final Map<String, Future<_R> Function()> _acts = {};
  int _actSeq = 0;
  _P? _draft;
  bool _awaitTitle = false;

  // ---------- শুরু ----------
  void greet() {
    if (_greeted) return;
    _greeted = true;
    final mood = app.prefs.mood;
    if (!app.prefs.guideDone) {
      msgs.add(ChatMsg(false, t('as.welcome', [name]), [
        ChatChip(t('ch.try'), t('ch.try.text')),
        ChatChip(t('ch.how'), '#help'),
        ChatChip(t('ch.perm'), '#openperm'),
      ]));
    } else {
      final now = DateTime.now();
      final nowMin = now.hour * 60 + now.minute;
      final pend = app.entriesFor(now).where((e) => e.status == 0).toList();
      PlanEntry? next;
      for (final e in pend) {
        if (e.startMin >= nowMin) {
          next = e;
          break;
        }
      }
      var text = next != null
          ? t('as.next', [next.title, fmtMin(next.startMin)])
          : (pend.isEmpty ? t('as.free') : t('as.overdue', [pend.first.title]));
      if (app.prefs.callName.isNotEmpty) text = '${app.prefs.callName}, $text';
      if (mood == 'chatty' || mood == 'coach') text = '$text\n${t('as.checkin')}';
      msgs.add(ChatMsg(false, text, [
        ChatChip(t('ch.plan'), '#plan'),
        ChatChip(t('ch.how'), '#help'),
      ]));
    }
  }

  /// সহকারীর নাম (ইউজার বদলাতে পারে)।
  String get name => app.prefs.assistantName.isEmpty ? 'Mailo' : app.prefs.assistantName;

  String _pick(List<String> keys) => t(keys[Random().nextInt(keys.length)]);

  String _tone(String s) {
    switch (app.prefs.mood) {
      case 'chatty':
        return '$s\n${_pick(['tone.c1', 'tone.c2', 'tone.c3'])}';
      case 'coach':
        return '$s\n${_pick(['tone.k1', 'tone.k2', 'tone.k3'])}';
      default:
        return s;
    }
  }

  // ---------- ইনপুট ----------
  Future<void> send(String text, {String? shown}) async {
    final q = text.trim();
    if (q.isEmpty || busy) return;
    if (q == '#openperm') return; // UI নিজে সামলায়
    msgs.add(ChatMsg(true, shown ?? q));
    busy = true;
    notifyListeners();
    try {
      final r = await _handle(q);
      msgs.add(ChatMsg(false, r.tone ? _tone(r.text) : r.text, r.chips));
    } catch (e) {
      msgs.add(ChatMsg(false, t('as.error')));
    }
    busy = false;
    notifyListeners();
  }

  Future<_R> _handle(String q) async {
    if (q.startsWith('#')) return _command(q);
    if (_awaitTitle && _draft != null) {
      _awaitTitle = false;
      final d = _draft!;
      final title = _parse(_norm(q)).title ?? q.trim();
      d.title = title;
      return _addFlow(d);
    }
    _draft = null;
    final teach = await _teach(q);
    if (teach != null) return teach;
    final local = await _local(q);
    if (local != null) return local;
    if (aiClient.available) return _gemini(q);
    return _fallback();
  }

  // ---------- কমান্ড ----------
  Future<_R> _command(String c) async {
    if (c == '#no') {
      _acts.clear();
      _draft = null;
      return _R(t('as.cancelled'));
    }
    if (c == '#unteach') return _unteach();
    if (c == '#help') return _R(t('as.help'), [ChatChip(t('ch.try'), t('ch.try.text'))]);
    if (c == '#plan') return _R(_planText(), [ChatChip(t('ch.how'), '#help')]);
    if (c.startsWith('#do:')) {
      final f = _acts.remove(c.substring(4));
      if (f == null) return _R(t('as.expired'));
      return f();
    }
    if (c.startsWith('#skip:')) {
      final e = _entryById(c.substring(6));
      if (e == null) return _R(t('as.notfound'));
      return _skipFlow(e);
    }
    if (c.startsWith('#delay:')) {
      final parts = c.split(':');
      final e = parts.length == 3 ? _entryById(parts[1]) : null;
      final m = parts.length == 3 ? int.tryParse(parts[2]) : null;
      if (e == null || m == null) return _R(t('as.notfound'));
      return _opResult(await app.delayEntry(e, m), e, null, delay: m);
    }
    if (c.startsWith('#mv:')) {
      final parts = c.split(':');
      final e = parts.length == 3 ? _entryById(parts[1]) : null;
      final m = parts.length == 3 ? int.tryParse(parts[2]) : null;
      if (e == null || m == null) return _R(t('as.notfound'));
      return _moveFlow(e, m);
    }
    if (c.startsWith('#addt:')) {
      final d = _draft;
      final m = int.tryParse(c.substring(6));
      if (d == null || m == null) return _R(t('as.expired'));
      d.time = m;
      d.amb = false;
      return _addFlow(d);
    }
    if (c.startsWith('#rep:')) {
      final parts = c.split(':');
      if (parts.length != 3) return _R(t('as.expired'));
      for (final x in app.tasks) {
        if (x.id == parts[1]) {
          if (parts[2] == 'once') {
            x.onDate = dateKey(app.nextOccurrence(x) ?? DateTime.now());
            x.days = [];
          } else {
            x.onDate = null;
            x.days = [];
          }
          await app.replan(force: true);
          await app.savePrefs();
          return _R(parts[2] == 'once' ? t('as.rep.once') : t('as.rep.daily'));
        }
      }
      return _R(t('as.notfound'));
    }
    return _R(t('as.unknown'));
  }

  // ---------- অফলাইন বোঝা ----------
  static final _skipRe = RegExp(
      r'(করব না|করবো না|করবনা|করবোনা|করতে পারব না|করতে পারবো না|করতে চাই না|স্কিপ|বাদ দাও|বাদ দিন|skip|not today|won.?t do|cancel today|don.?t want)');
  static final _moveRe = RegExp(
      r'(সময় বদল|সময় পরিবর্তন|সময় বদলা|পিছিয়ে|পিছাও|সরাও|সরিয়ে|পরে করব|পরে করবো|পরে করি|এগিয়ে|later|move|reschedule|delay|postpone|change time|push back)');
  static final _addRe = RegExp(
      r'(যোগ|নতুন কাজ|বসাও|রাখো|রাখুন|মনে করিয়ে|add |add$|new task|schedule|remind|set a|set an|create)');
  static final _helpRe = RegExp(r'(সাহায্য|কীভাবে|কিভাবে|গাইড|কি করতে পারো|কী করতে পারো|^help|how do|how to|what can you)');
  static final _planRe = RegExp(r'(আজকের রুটিন|আজ কী কী|আজ কি কি|আজকের কাজ|today.?s plan|my plan|my schedule|what.?s today)');
  static final _dailyRe = RegExp(r'(প্রতিদিন|রোজ|daily|every ?day|each day)');
  static final _onceRe = RegExp(r'(আজ|আজকে|today|tonight|শুধু আজ|only today)');
  static final _durRe = RegExp(
      r'(\d+(?:\.\d+)?)\s*(মিনিট[েরের]*|minutes?|mins?|ঘ[^\s\d]{1,4}?টা[রে]*|hours?|hrs?|h(?![a-z]))');
  static final _timeRe = RegExp(r'(\d{1,2})(?::(\d{2}))?\s*(am|pm|টায়|টার|টা|বাজে|baje)?');
  static const _stop = {
    'যোগ', 'করো', 'করুন', 'কর', 'করে', 'দাও', 'দিন', 'নতুন', 'কাজ', 'আমার', 'আমাকে', 'রুটিনে',
    'রুটিন', 'রাখো', 'রাখুন', 'বসাও', 'বসান', 'আজ', 'আজকে', 'কাল', 'প্রতিদিন', 'রোজ', 'টাস্ক',
    'একটা', 'একটি', 'এ', 'এর', 'থেকে', 'জন্য', 'দিয়ে', 'সময়', 'সেট', 'চাই', 'চাচ্ছি', 'আছে',
    'কি', 'কী', 'হবে', 'তে', 'মনে', 'করিয়ে', 'আর', 'ও', 'এবং', 'শুধু', 'বসিয়ে',     'add', 'task', 'please', 'new', 'my', 'to', 'a', 'an', 'the', 'at', 'for', 'every', 'day', 'daily',
    'today', 'tomorrow', 'tonight', 'set', 'schedule', 'make', 'put', 'routine', 'in', 'on', 'need',
    'want', 'i', 'me', 'remind', 'only', 'and', 'of', 'create', 'it', 'is',
  };

  String _digits(String s) {
    const bn = '০১২৩৪৫৬৭৮৯';
    var o = s;
    for (var i = 0; i < 10; i++) {
      o = o.replaceAll(bn[i], '$i');
    }
    return o;
  }

  String _norm(String s) => _digits(s).toLowerCase().trim();

  String? _period(String s) {
    if (RegExp(r'ভোর|সকাল|morning').hasMatch(s)) return 'morning';
    if (RegExp(r'দুপুর|noon').hasMatch(s)) return 'noon';
    if (RegExp(r'বিকাল|বিকেল|afternoon').hasMatch(s)) return 'afternoon';
    if (RegExp(r'সন্ধ্যা|evening').hasMatch(s)) return 'evening';
    if (RegExp(r'রাত|night').hasMatch(s)) return 'night';
    return null;
  }

  int _applyPeriod(String p, int h) {
    switch (p) {
      case 'morning':
        return h % 12;
      case 'noon':
        return h == 12 ? 12 : (h <= 4 ? h + 12 : h);
      case 'afternoon':
        return h == 12 ? 12 : (h < 12 ? h + 12 : h);
      case 'evening':
        return h < 12 ? h + 12 : h;
      default: // night
        return h == 12 ? 0 : (h >= 6 && h < 12 ? h + 12 : h);
    }
  }

  _Tm? _findTime(String s) {
    final period = _period(s);
    for (final m in _timeRe.allMatches(s)) {
      final ms = m.group(2);
      final suf = m.group(3);
      if (ms == null && suf == null) continue;
      final h = int.parse(m.group(1)!);
      final mi = ms == null ? 0 : int.parse(ms);
      if (h > 24 || mi > 59) continue;
      int? res;
      var amb = false;
      if (suf == 'am') {
        res = (h % 12) * 60 + mi;
      } else if (suf == 'pm') {
        res = ((h % 12) + 12) * 60 + mi;
      } else if (h >= 13) {
        res = (h % 24) * 60 + mi;
      } else if (period != null) {
        res = _applyPeriod(period, h) * 60 + mi;
      } else if (h == 0) {
        res = mi;
      } else {
        amb = true;
      }
      return _Tm(m.start, m.end, h, mi, res, amb);
    }
    return null;
  }

  _P _parse(String s) {
    final p = _P();
    var r = s;
    final dm = _durRe.firstMatch(r);
    if (dm != null) {
      final n = double.tryParse(dm.group(1)!) ?? 0;
      final unit = dm.group(2)!;
      final isHour = unit.startsWith('ঘ') || unit.startsWith('h');
      p.minutes = isHour ? (n * 60).round() : n.round();
      r = r.replaceRange(dm.start, dm.end, ' ');
    } else if (RegExp(r'আধা ঘ|আধ ঘ|half hour|half an hour').hasMatch(r)) {
      p.minutes = 30;
      r = r.replaceAll(RegExp(r'আধা ঘ[^\s]{1,5}|আধ ঘ[^\s]{1,5}|half an hour|half hour'), ' ');
    } else if (RegExp(r'এক ঘ[^\s]{1,5}|an hour').hasMatch(r)) {
      p.minutes = 60;
      r = r.replaceAll(RegExp(r'এক ঘ[^\s]{1,5}|an hour'), ' ');
    }
    final tm = _findTime(r);
    if (tm != null) {
      if (tm.amb) {
        p.amb = true;
        p.ambHour = tm.hour;
        p.ambMin = tm.minute;
      } else {
        p.time = tm.min;
      }
      r = r.replaceRange(tm.start, tm.end, ' ');
      r = r.replaceAll(
          RegExp(r'সন্ধ্যায়|সন্ধ্যা|রাতে|রাত|সকালে|সকাল|ভোরে|ভোর|দুপুরে|দুপুর|বিকালে|বিকাল|বিকেলে|বিকেল|morning|afternoon|evening|tonight|night|noon'),
          ' ');
    }
    p.daily = _dailyRe.hasMatch(s);
    p.once = !p.daily && _onceRe.hasMatch(s);
    final words = r
        .split(RegExp(r'[\s,।.!?]+'))
        .where((w) => w.isNotEmpty && !_stop.contains(w) && !RegExp(r'^\d+$').hasMatch(w))
        .toList();
    if (words.isNotEmpty) {
      final title = words.join(' ');
      p.title = title.length > 40 ? title.substring(0, 40) : title;
    }
    return p;
  }

  PlanEntry? _entryById(String id) {
    for (final e in app.allEntries) {
      if (e.id == id) return e;
    }
    return null;
  }

  PlanEntry? _findEntry(String s) {
    final list = app.entriesFor(DateTime.now()).where((e) => e.status == 0).toList();
    PlanEntry? best;
    var bl = 0;
    for (final e in list) {
      final tt = _norm(e.title);
      if (tt.isNotEmpty && s.contains(tt) && tt.length > bl) {
        best = e;
        bl = tt.length;
      }
    }
    if (best != null) return best;
    for (final e in list) {
      for (final w in _norm(e.title).split(RegExp(r'\s+'))) {
        if (w.length >= 3 && s.contains(w)) return e;
      }
    }
    return null;
  }

  Future<_R?> _local(String q) async {
    final s = _norm(q);
    if (_helpRe.hasMatch(s)) return _R(t('as.help'), [ChatChip(t('ch.try'), t('ch.try.text'))]);
    if (_planRe.hasMatch(s)) return _R(_planText(), [ChatChip(t('ch.how'), '#help')]);
    final entry = _findEntry(s);
    final hasAdd = _addRe.hasMatch(s);
    if (_skipRe.hasMatch(s) && !hasAdd) {
      if (entry != null) return _skipFlow(entry);
      return _chooseEntry(t('as.which.skip'), '#skip:');
    }
    if (_moveRe.hasMatch(s) && !hasAdd) {
      final mp = _parse(s);
      if (entry == null) return _chooseEntry(t('as.which.move'), '#skip:', moveText: true);
      if (mp.time != null) return _moveFlow(entry, mp.time!);
      if (mp.amb) {
        final am = _applyPeriod('morning', mp.ambHour) * 60 + mp.ambMin;
        final pm = _applyPeriod('evening', mp.ambHour) * 60 + mp.ambMin;
        return _R(t('as.askampm'), [
          ChatChip(t('as.am', [fmtMin(am)]), '#mv:${entry.id}:$am'),
          ChatChip(t('as.pm', [fmtMin(pm)]), '#mv:${entry.id}:$pm'),
        ]);
      }
      return _R(t('as.delay.ask', [entry.title]), [
        ChatChip(t('as.delay.30'), '#delay:${entry.id}:30'),
        ChatChip(t('as.delay.60'), '#delay:${entry.id}:60'),
        ChatChip(t('as.delay.180'), '#delay:${entry.id}:180'),
        ChatChip(t('as.skip.today'), '#skip:${entry.id}'),
      ]);
    }
    if (!aiClient.available && _goalRe.hasMatch(s) && !hasAdd) return _goalOffline(s);
    final p = _parse(s);
    final looksLikeTask = hasAdd || ((p.time != null || p.amb) && p.title != null);
    if (looksLikeTask) {
      if (entry != null && p.title != null && !hasAdd) return null;
      return _addFlow(p);
    }
    return null;
  }

  // ---------- শেখানো (ইউজারের নিজের নিয়ম) ----------
  static final _teachRe = RegExp(
      r'^(এখন থেকে|এখন হতে|মনে রেখো|মনে রাখো|মনে রাখবে|মনে রাখুন|শিখে রাখো|from now on|remember( that)?|keep in mind)');
  static final _neverRe = RegExp(r"^(কখনো|কখনও|never)");
  static final _callBn = RegExp(
      r'''আমাকে\s+["'“‘]?(.+?)["'”’]?\s+(?:বলে|নামে)\s*(?:ডাক|ডেকো|ডাকো)''');
  static final _callEn = RegExp(r'''call me\s+["'“‘]?([^"'”’.!,]+?)["'”’]?\s*(?:[.!,]|$)''',
      caseSensitive: false);

  bool _isTeach(String s) {
    final t0 = s.trim();
    final p = _parse(t0);
    if (p.time != null || p.amb) return false;
    if (_teachRe.hasMatch(t0)) return true;
    if (_neverRe.hasMatch(t0) && (t0.contains('না') || t0.contains('never') || t0.contains("don't"))) return true;
    return false;
  }

  String? _callNameFrom(String q) {
    final m = _callBn.firstMatch(q) ?? _callEn.firstMatch(q);
    if (m == null) return null;
    final n = (m.group(1) ?? '').trim();
    if (n.isEmpty || n.length > 20) return null;
    return n;
  }

  Future<_R?> _teach(String q) async {
    final s = _norm(q);
    if (!_isTeach(s)) return null;
    final rules = app.prefs.customRules;
    if (rules.length >= 20) return _R(t('as.rules.full'));
    var rule = q.trim();
    if (rule.length > 200) rule = rule.substring(0, 200);
    rules.add(rule);
    final cn = _callNameFrom(q);
    if (cn != null) app.prefs.callName = cn;
    await app.savePrefs();
    return _R(t('as.taught', [rule]), [ChatChip(t('as.undo'), '#unteach')]);
  }

  Future<_R> _unteach() async {
    final rules = app.prefs.customRules;
    if (rules.isEmpty) return _R(t('as.rules.none'));
    final last = rules.removeLast();
    if (_callNameFrom(last) != null) app.prefs.callName = '';
    await app.savePrefs();
    return _R(t('as.untaught'));
  }

  // ---------- লক্ষ্য (অফলাইন সহজ রূপ) ----------
  static final _goalRe = RegExp(r'(লক্ষ্য|টার্গেট|goal|target)');
  static final _goalWords = RegExp(
      r'^(লক্ষ্য|টার্গেট|goal|target|সেট|করো|করুন|চাই|চাচ্ছি|set|my|a|the|to|for|in|of|দিনে|দিন|days?|সপ্তাহে|সপ্তাহ|weeks?|মাসে|মাস|months?|\d+)$');

  Future<_R> _goalOffline(String s) async {
    var days = 30;
    final dm = RegExp(r'(\d+)\s*(দিনে|দিন|days?)').firstMatch(s);
    final wm = RegExp(r'(\d+)\s*(সপ্তাহে|সপ্তাহ|weeks?)').firstMatch(s);
    final mm = RegExp(r'(\d+)\s*(মাসে|মাস|months?)').firstMatch(s);
    if (dm != null) {
      days = int.parse(dm.group(1)!);
    } else if (wm != null) {
      days = int.parse(wm.group(1)!) * 7;
    } else if (mm != null) {
      days = int.parse(mm.group(1)!) * 30;
    }
    days = days.clamp(1, 365);
    final words = s
        .replaceAll(RegExp(r'\d+\s*(দিনে|দিন|days?|সপ্তাহে|সপ্তাহ|weeks?|মাসে|মাস|months?)'), ' ')
        .split(RegExp(r'[\s,।.!?:]+'))
        .where((w) => w.isNotEmpty && !_goalWords.hasMatch(w) && !_stop.contains(w))
        .toList();
    if (words.isEmpty) return _R(t('as.goal.ask'));
    final title = words.join(' ');
    final ids = <String>[];
    for (final x in app.tasks) {
      final tt = _norm(x.title);
      if (tt.isNotEmpty && s.contains(tt)) ids.add(x.id);
    }
    if (ids.isEmpty) {
      final task = TaskItem(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        title: title.length > 40 ? title.substring(0, 40) : title,
        category: app.prefs.categories.isNotEmpty ? app.prefs.categories.last : 'অন্যান্য',
        minutes: 30,
        priority: 2,
      );
      await app.addTask(task);
      ids.add(task.id);
    }
    final now = DateTime.now();
    await app.addGoal(Goal(
      id: now.microsecondsSinceEpoch.toString(),
      title: title,
      type: 'days',
      target: days.toDouble(),
      startDate: dateKey(now),
      endDate: dateKey(now.add(Duration(days: days - 1))),
      taskIds: ids,
    ));
    app.prefs.guideDone = true;
    await app.savePrefs();
    return _R(t('as.goal.added', [title, days]), [], true);
  }

  // ---------- লক্ষ্য তৈরি (AI-র প্ল্যান থেকে) ----------
  Future<_R> _createGoal(Map<String, dynamic> spec) async {
    final title = (spec['title'] ?? '').toString().trim();
    if (title.isEmpty) return _R(t('as.goal.ask'));
    final gtype = ['days', 'count', 'number'].contains(spec['goal_type']) ? spec['goal_type'].toString() : 'days';
    final days = ((spec['days'] as num?)?.toInt() ?? 30).clamp(1, 365);
    final target = (spec['target'] as num?)?.toDouble() ?? (gtype == 'number' ? 0 : days.toDouble());
    final startValue = (spec['start_value'] as num?)?.toDouble() ?? 0;
    final ids = <String>[];
    final specs = (spec['tasks'] as List?) ?? const [];
    for (final x in specs.take(6)) {
      if (x is! Map) continue;
      final tt = (x['title'] ?? '').toString().trim();
      if (tt.isEmpty) continue;
      final daily = x['daily'] != false;
      final task = TaskItem(
        id: '${DateTime.now().microsecondsSinceEpoch}${ids.length}',
        title: tt.length > 40 ? tt.substring(0, 40) : tt,
        category: app.prefs.categories.isNotEmpty ? app.prefs.categories.last : 'অন্যান্য',
        minutes: max(5, min(480, (x['minutes'] as num?)?.toInt() ?? 30)),
        priority: 2,
        fixedMin: _hhmm(x['time']),
      );
      if (!daily) {
        final d = app.nextOccurrence(task) ?? DateTime.now();
        task.onDate = dateKey(d);
      }
      final r = await app.addTaskChecked(task);
      if (!r.ok) {
        task.fixedMin = r.suggestion;
        await app.addTask(task);
      }
      ids.add(task.id);
    }
    final now = DateTime.now();
    await app.addGoal(Goal(
      id: now.microsecondsSinceEpoch.toString(),
      title: title,
      type: gtype,
      target: target,
      startValue: startValue,
      current: startValue,
      unit: (spec['unit'] ?? '').toString(),
      startDate: dateKey(now),
      endDate: dateKey(now.add(Duration(days: days - 1))),
      taskIds: ids,
    ));
    app.prefs.guideDone = true;
    await app.savePrefs();
    return _R(t('as.goal.created', [title, ids.length]), [], true);
  }

  String _goalPlanText(Map<String, dynamic> spec) {
    final lines = <String>[];
    lines.add('🎯 ${spec['title']}');
    final days = (spec['days'] as num?)?.toInt() ?? 30;
    final gt = spec['goal_type']?.toString() ?? 'days';
    final tg = spec['target'];
    final unit = (spec['unit'] ?? '').toString();
    if (gt == 'number' && tg != null) {
      lines.add('${t('as.goal.target')}: $tg $unit • $days ${L('দিন', 'days')}');
    } else {
      lines.add('${t('as.goal.target')}: ${tg ?? days} ${gt == 'count' ? L('বার', 'times') : L('দিন', 'days')} • $days ${L('দিন', 'days')}');
    }
    for (final x in ((spec['tasks'] as List?) ?? const []).take(6)) {
      if (x is! Map) continue;
      final tm = _hhmm(x['time']);
      lines.add('• ${x['title']} — ${x['minutes'] ?? 30} ${L('মিনিট', 'min')}'
          '${tm != null ? ' • ${fmtMin(tm)}' : ''}${x['daily'] == false ? '' : ' • ${L('প্রতিদিন', 'daily')}'}');
    }
    return lines.join('\n');
  }

  _R _chooseEntry(String ask, String cmdPrefix, {bool moveText = false}) {
    final pend = app.entriesFor(DateTime.now()).where((e) => e.status == 0).toList();
    if (pend.isEmpty) return _R(t('as.none.pending'));
    return _R(ask, [
      for (final e in pend.take(6))
        ChatChip('${fmtMin(e.startMin)} ${e.title}', moveText ? '#delay:${e.id}:60' : '$cmdPrefix${e.id}'),
    ]);
  }

  // ---------- কাজের ধারা ----------
  Future<_R> _skipFlow(PlanEntry e) async {
    await app.skipToday(e);
    return _R(t('as.skipped', [e.title]), [], true);
  }

  Future<_R> _moveFlow(PlanEntry e, int newStart, {bool force = false}) async {
    final r = await app.moveEntry(e, newStart, force: force);
    return _opResult(r, e, newStart);
  }

  _R _opResult(OpResult r, PlanEntry e, int? wanted, {int? delay}) {
    if (r.ok) {
      return _R(t('as.moved', [e.title, fmtMin(e.startMin)]), [], true);
    }
    if (r.error == 'past') return _R(t('as.err.past'));
    if (r.error == 'range') return _R(t('as.err.range'));
    if (r.error == 'notfound') return _R(t('as.notfound'));
    final names = r.conflicts.map((c) => '${c.title} (${fmtMin(c.startMin)})').join(', ');
    final target = wanted ?? e.startMin;
    final chips = <ChatChip>[];
    if (r.suggestion != null) {
      final sug = r.suggestion!;
      final id = _store(() => _moveFlow(e, sug));
      chips.add(ChatChip(t('as.use.sug', [fmtMin(sug)]), '#do:$id'));
    }
    final id2 = _store(() => _moveFlow(e, target, force: true));
    chips.add(ChatChip(t('as.force.here', [fmtMin(target)]), '#do:$id2'));
    chips.add(ChatChip(t('as.skip.today'), '#skip:${e.id}'));
    chips.add(ChatChip(t('as.cancel'), '#no'));
    return _R(t('as.conflict', [fmtMin(target), names]), chips);
  }

  String _store(Future<_R> Function() f) {
    final id = '${++_actSeq}';
    _acts[id] = f;
    return id;
  }

  Future<_R> _addFlow(_P p) async {
    if (p.title == null || p.title!.trim().isEmpty) {
      _draft = p;
      _awaitTitle = true;
      return _R(t('as.ask.title'));
    }
    if (p.amb && p.time == null) {
      _draft = p;
      final am = _applyPeriod('morning', p.ambHour) * 60 + p.ambMin;
      final pm = _applyPeriod('evening', p.ambHour) * 60 + p.ambMin;
      return _R(t('as.askampm'), [
        ChatChip(t('as.am', [fmtMin(am)]), '#addt:$am'),
        ChatChip(t('as.pm', [fmtMin(pm)]), '#addt:$pm'),
      ]);
    }
    final now = DateTime.now();
    final task = TaskItem(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      title: p.title!.trim(),
      category: app.prefs.categories.isNotEmpty ? app.prefs.categories.last : 'অন্যান্য',
      minutes: max(5, min(480, p.minutes ?? 30)),
      priority: 2,
      fixedMin: p.time,
    );
    if (p.once) {
      final passed = p.time != null && p.time! <= now.hour * 60 + now.minute;
      final d = passed ? DateTime(now.year, now.month, now.day + 1) : now;
      task.onDate = dateKey(d);
    }
    final r = await app.addTaskChecked(task);
    if (r.ok) {
      app.prefs.guideDone = true;
      await app.savePrefs();
      _draft = null;
      final when = task.fixedMin != null ? fmtMin(task.fixedMin!) : t('as.auto');
      final rep = task.onDate != null ? t('as.once') : t('as.every');
      return _R(t('as.added', [task.title, when, task.minutes, rep]), [
        if (task.onDate == null) ChatChip(t('as.only.today'), '#rep:${task.id}:once'),
        if (task.onDate != null) ChatChip(t('as.make.daily'), '#rep:${task.id}:daily'),
      ], true);
    }
    final names = r.conflicts.map((c) => '${c.title} (${fmtMin(c.startMin)})').join(', ');
    final chips = <ChatChip>[];
    if (r.suggestion != null) {
      final sug = r.suggestion!;
      final id = _store(() async {
        final t2 = TaskItem(
          id: DateTime.now().microsecondsSinceEpoch.toString(),
          title: task.title,
          category: task.category,
          minutes: task.minutes,
          priority: 2,
          fixedMin: sug,
          onDate: task.onDate,
        );
        await app.addTask(t2);
        return _R(t('as.added', [t2.title, fmtMin(sug), t2.minutes, t2.onDate != null ? t('as.once') : t('as.every')]), [], true);
      });
      chips.add(ChatChip(t('as.use.sug', [fmtMin(sug)]), '#do:$id'));
    }
    final id2 = _store(() async {
      await app.addTask(task);
      return _R(t('as.added', [task.title, fmtMin(task.fixedMin ?? 0), task.minutes, task.onDate != null ? t('as.once') : t('as.every')]), [], true);
    });
    chips.add(ChatChip(t('as.force.here', [fmtMin(task.fixedMin ?? 0)]), '#do:$id2'));
    chips.add(ChatChip(t('as.cancel'), '#no'));
    return _R(t('as.conflict', [fmtMin(task.fixedMin ?? 0), names]), chips);
  }

  String _planText() {
    final l = app.entriesFor(DateTime.now()).toList();
    if (l.isEmpty) return t('as.plan.empty');
    final lines = l.map((e) {
      final mark = e.status == 1 ? '✅' : (e.status == 2 ? '❌' : (e.status == 3 ? '⏸' : '•'));
      return '$mark ${fmtMin(e.startMin)}  ${e.title} (${e.minutes})';
    }).join('\n');
    return '${t('as.plan.title')}\n$lines';
  }

  _R _fallback() {
    final ins = localInsights(app);
    final text = ins.isEmpty ? t('as.fallback.empty') : ins.join('\n\n');
    return _R('$text\n\n${t('as.fallback.tip')}', [
      ChatChip(t('ch.try'), t('ch.try.text')),
      ChatChip(t('ch.how'), '#help'),
    ]);
  }

  // ---------- AI ----------
  int? _hhmm(dynamic v) {
    if (v == null) return null;
    final m = RegExp(r'^(\d{1,2}):(\d{2})$').firstMatch(v.toString().trim());
    if (m == null) return null;
    final h = int.parse(m.group(1)!);
    final mi = int.parse(m.group(2)!);
    if (h > 23 || mi > 59) return null;
    return h * 60 + mi;
  }

  String _geminiPrompt(String q) {
    final now = DateTime.now();
    final today = app.entriesFor(now)
        .map((e) => {
              'id': e.id,
              'title': e.title,
              'time': fmtMin(e.startMin),
              'minutes': e.minutes,
              'status': e.status == 0 ? 'pending' : (e.status == 1 ? 'done' : 'skipped'),
            })
        .toList();
    final goals = app.goals
        .map((g) => {
              'id': g.id,
              'title': g.title,
              'type': g.type,
              'target': g.target,
              'unit': g.unit,
              'progress_pct': (app.goalFraction(g) * 100).round(),
              'status': app.goalStatus(g),
            })
        .toList();
    final langName = app.lang == 'en' ? 'English' : 'Bangla';
    final rules = app.prefs.customRules;
    final rulesText = rules.isEmpty
        ? ''
        : 'The user taught you these standing instructions. Follow them in "reply" as long as they do not conflict '
            'with the JSON format or with safety: ${jsonEncode(rules)}. ';
    final callName = app.prefs.callName.isEmpty ? '' : 'Call the user "${app.prefs.callName}". ';
    return 'You are $name, a friendly assistant inside a routine, alarm and goal app. '
        'Your job is to help the user reach their targets and do their tasks smartly. '
        'Reply in $langName. Mood: ${app.prefs.mood} '
        '(quiet=very short, normal=friendly, chatty=warm and curious, coach=firm and motivating). '
        '$rulesText$callName'
        'Output ONLY a JSON object: {"reply": string, "actions": [..]}. '
        'Allowed actions: '
        '{"type":"add_task","title":string,"minutes":int,"time":"HH:MM" or null,"daily":bool}, '
        '{"type":"move","id":entryId,"time":"HH:MM"}, '
        '{"type":"skip_today","id":entryId}, '
        '{"type":"delay","id":entryId,"minutes":int}, '
        '{"type":"add_goal","title":string,"goal_type":"days"|"count"|"number","target":number,"unit":string,"start_value":number or null,"days":int,'
        '"tasks":[{"title":string,"minutes":int,"time":"HH:MM" or null,"daily":bool}]} '
        '(use add_goal when the user states a target they want to reach: plan realistic recurring tasks, at most 4, '
        'and keep times outside the user\'s existing entries), '
        '{"type":"update_goal","id":goalId,"value":number} (for number goals, the new current value), '
        '{"type":"add_reward","text":string,"goal_id":goalId or null,"streak_days":int or null} (a reward the user wants to give themselves), '
        '{"type":"teach_rule","rule":string} (when the user tells you how they want you to behave from now on). '
        'Use actions only when the user clearly asks; otherwise leave actions empty. '
        'Never invent entry or goal ids. If a time is unclear, ask in "reply" and leave actions empty. '
        'Keep "reply" under 80 words. '
        'Now: ${dateKey(now)} ${fmtMin(now.hour * 60 + now.minute)} (weekday ${now.weekday}). '
        'Today entries: ${jsonEncode(today)}. '
        'Goals: ${jsonEncode(goals)}. '
        'Streak: ${app.streak}, level: ${app.level}. '
        'User message: $q';
  }

  Future<_R> _gemini(String q) async {
    final res = await aiClient.askJson(_geminiPrompt(q));
    if (!res.ok) {
      if (res.netError) return _R('${t('as.net.err')}\n\n${_fallback().text}');
      return _R(t('as.ai.err', [res.status ?? 0]));
    }
    try {
      final raw = res.text!;
      Map<String, dynamic>? obj;
      try {
        obj = Map<String, dynamic>.from(jsonDecode(raw) as Map);
      } catch (_) {
        obj = null;
      }
      if (obj == null) return _R(raw);
      final lines = <String>[];
      final chips = <ChatChip>[];
      final reply = (obj['reply'] ?? '').toString().trim();
      if (reply.isNotEmpty) lines.add(reply);
      final acts = (obj['actions'] as List?) ?? const [];
      for (final a in acts) {
        if (a is! Map) continue;
        final type = a['type']?.toString();
        _R? r;
        if (type == 'add_task') {
          final p = _P();
          p.title = a['title']?.toString();
          p.minutes = (a['minutes'] as num?)?.toInt() ?? 30;
          p.time = _hhmm(a['time']);
          p.daily = a['daily'] == true;
          p.once = !p.daily;
          if (a['daily'] == null) p.once = false;
          r = await _addFlow(p);
        } else if (type == 'add_goal') {
          final spec = Map<String, dynamic>.from(a);
          final id = _store(() => _createGoal(spec));
          r = _R(_goalPlanText(spec), [
            ChatChip(t('as.goal.add.chip'), '#do:$id'),
            ChatChip(t('as.cancel'), '#no'),
          ]);
        } else if (type == 'update_goal') {
          final g = app.goalById(a['id']?.toString());
          final v = (a['value'] as num?)?.toDouble();
          if (g != null && v != null) {
            g.current = v;
            app.saveGoals();
            r = _R(t('as.goal.updated', [g.title, (app.goalFraction(g) * 100).round()]), [], true);
          }
        } else if (type == 'add_reward') {
          final txt = (a['text'] ?? '').toString().trim();
          if (txt.isNotEmpty) {
            final gid = a['goal_id']?.toString();
            final sd = (a['streak_days'] as num?)?.toInt();
            final rw = Reward(
              id: DateTime.now().microsecondsSinceEpoch.toString(),
              text: txt.length > 80 ? txt.substring(0, 80) : txt,
              cond: app.goalById(gid) != null ? 'goal' : (sd != null ? 'streak' : 'week'),
              goalId: app.goalById(gid) != null ? gid : null,
              value: sd ?? 7,
            );
            await app.addReward(rw);
            r = _R(t('as.reward.added', [rw.text]), [], true);
          }
        } else if (type == 'teach_rule') {
          final rule = (a['rule'] ?? '').toString().trim();
          if (rule.isNotEmpty && app.prefs.customRules.length < 20) {
            app.prefs.customRules.add(rule.length > 200 ? rule.substring(0, 200) : rule);
            await app.savePrefs();
            r = _R(t('as.taught', [rule]), [ChatChip(t('as.undo'), '#unteach')]);
          }
        } else {
          final e = _entryById((a['id'] ?? '').toString());
          if (e == null) continue;
          if (type == 'move') {
            final tm = _hhmm(a['time']);
            if (tm != null) r = await _moveFlow(e, tm);
          } else if (type == 'skip_today') {
            r = await _skipFlow(e);
          } else if (type == 'delay') {
            final m = (a['minutes'] as num?)?.toInt();
            if (m != null) r = _opResult(await app.delayEntry(e, m), e, null, delay: m);
          }
        }
        if (r != null) {
          lines.add(r.text);
          chips.addAll(r.chips);
        }
      }
      if (lines.isEmpty) return _fallback();
      return _R(lines.join('\n\n'), chips);
    } catch (e) {
      return _R('${t('as.net.err')}\n\n${_fallback().text}');
    }
  }
}
