import 'package:flutter/material.dart';
import 'models.dart';
import 'state.dart';
import 'ui_alarm.dart';

class HomeTab extends StatefulWidget {
  const HomeTab({super.key});
  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  int dayOffset = 0;
  bool busy = false;

  DateTime get day => DateTime.now().add(Duration(days: dayOffset));

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final entries = app.entriesFor(day);
        final done = entries.where((e) => e.status == 1).length;
        final cs = Theme.of(context).colorScheme;
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              color: cs.primaryContainer,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Text('লেভেল ${app.level}',
                        style: Theme.of(context).textTheme.titleLarge),
                    const Spacer(),
                    Chip(label: Text('🔥 ${app.streak} দিন')),
                  ]),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(value: app.xpIntoLevel / 200, minHeight: 8),
                  const SizedBox(height: 4),
                  Text('${app.xpIntoLevel}/200 XP • পরের লেভেলের পথে'),
                ]),
              ),
            ),
            const SizedBox(height: 12),
            SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 0, label: Text('আজ')),
                ButtonSegment(value: 1, label: Text('আগামীকাল')),
              ],
              selected: {dayOffset},
              onSelectionChanged: (s) => setState(() => dayOffset = s.first),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: busy
                  ? null
                  : () async {
                      setState(() => busy = true);
                      await app.generate(day);
                      if (!mounted) return;
                      setState(() => busy = false);
                      final msg = app.unplaced.isEmpty
                          ? 'রুটিন তৈরি, অ্যালার্ম সেট হয়েছে ✅'
                          : 'জায়গা হয়নি: ${app.unplaced.map((t) => t.title).join(', ')}';
                      ScaffoldMessenger.of(context)
                          .showSnackBar(SnackBar(content: Text(msg)));
                    },
              icon: const Icon(Icons.auto_awesome),
              label: Text(entries.isEmpty ? 'রুটিন তৈরি করো' : 'আবার সাজাও'),
            ),
            const SizedBox(height: 12),
            if (entries.isNotEmpty)
              Text('অগ্রগতি: $done/${entries.length} কাজ শেষ',
                  style: Theme.of(context).textTheme.titleMedium),
            if (entries.isEmpty)
              const Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  '"কাজ" ট্যাবে আপনার কাজ ও ফ্রি সময় দিন, তারপর রুটিন তৈরি করুন।',
                  textAlign: TextAlign.center,
                ),
              ),
            for (final e in entries) _EntryTile(entry: e),
          ],
        );
      },
    );
  }
}

class _EntryTile extends StatelessWidget {
  final PlanEntry entry;
  const _EntryTile({required this.entry});

  @override
  Widget build(BuildContext context) {
    final e = entry;
    final stars = '⭐' * e.priority;
    Widget trailing;
    if (e.status == 1) {
      trailing = const Icon(Icons.check_circle, color: Colors.green);
    } else if (e.status == 2) {
      trailing = const Icon(Icons.cancel, color: Colors.grey);
    } else {
      trailing = IconButton.filledTonal(
        icon: const Icon(Icons.play_arrow),
        onPressed: () => Navigator.of(context)
            .push(MaterialPageRoute(builder: (_) => FocusScreen(entry: e))),
      );
    }
    return Card(
      child: ListTile(
        leading: Text(fmtMin(e.startMin),
            style: Theme.of(context).textTheme.titleMedium),
        title: Text(e.title,
            style: TextStyle(
                decoration: e.status == 1 ? TextDecoration.lineThrough : null)),
        subtitle: Text('${e.minutes} মিনিট • ${e.category} • $stars'),
        trailing: trailing,
      ),
    );
  }
}
