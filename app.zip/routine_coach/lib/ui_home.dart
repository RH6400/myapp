import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'alarm_service.dart';
import 'i18n.dart';
import 'models.dart';
import 'state.dart';
import 'ui_alarm.dart';
import 'ui_common.dart';
import 'ui_settings.dart';

class HomeTab extends StatefulWidget {
  const HomeTab({super.key});
  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  int dayOffset = 0;

  Future<bool> _permsOk() async {
    try {
      final a = await Permission.notification.isGranted;
      final b = await Permission.scheduleExactAlarm.isGranted;
      final c = await Permission.ignoreBatteryOptimizations.isGranted;
      return a && b && c;
    } catch (_) {
      return true;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final now = DateTime.now();
        final date = DateTime(now.year, now.month, now.day + dayOffset);
        final list = app.entriesFor(date);
        final counted = list.where((e) => e.status != 3).toList();
        final done = counted.where((e) => e.status == 1).length;
        final cs = Theme.of(context).colorScheme;
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            FutureBuilder<bool>(
              future: _permsOk(),
              builder: (c, snap) {
                if (snap.data != false) return const SizedBox.shrink();
                return Card(
                  color: cs.errorContainer,
                  child: ListTile(
                    leading: Icon(Icons.warning_amber, color: cs.onErrorContainer),
                    title: Text(L('অ্যালার্ম সময়মতো বাজতে কিছু পারমিশন বাকি', 'Some permissions are missing for on-time alarms'),
                        style: TextStyle(color: cs.onErrorContainer)),
                    trailing: Icon(Icons.chevron_right, color: cs.onErrorContainer),
                    onTap: () => Navigator.of(context)
                        .push(MaterialPageRoute<void>(builder: (_) => const PermScreen()))
                        .then((_) => setState(() {})),
                  ),
                );
              },
            ),
            Card(
              color: cs.primaryContainer,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Text('${L('লেভেল', 'Level')} ${app.level}',
                        style: Theme.of(context)
                            .textTheme
                            .headlineSmall
                            ?.copyWith(color: cs.onPrimaryContainer, fontWeight: FontWeight.w600)),
                    const Spacer(),
                    Chip(
                      avatar: const Icon(Icons.local_fire_department, size: 18),
                      label: Text('${app.streak} ${L('দিন', 'days')}'),
                    ),
                  ]),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(value: app.xpIntoLevel / 200, minHeight: 8),
                  const SizedBox(height: 6),
                  Text('${app.xpIntoLevel}/200 XP', style: TextStyle(color: cs.onPrimaryContainer)),
                ]),
              ),
            ),
            const SizedBox(height: 12),
            SegmentedButton<int>(
              segments: [
                ButtonSegment(value: 0, label: Text(L('আজ', 'Today'))),
                ButtonSegment(value: 1, label: Text(L('আগামীকাল', 'Tomorrow'))),
              ],
              selected: {dayOffset},
              onSelectionChanged: (s) => setState(() => dayOffset = s.first),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: () async {
                await app.replan(force: true);
                if (context.mounted) snack(context, L('রুটিন নতুন করে সাজানো হয়েছে', 'Routine rearranged'));
              },
              icon: const Icon(Icons.auto_awesome),
              label: Text(L('আবার সাজাও', 'Rearrange')),
            ),
            const SizedBox(height: 12),
            Text('${L('অগ্রগতি', 'Progress')}: $done/${counted.length} ${L('কাজ শেষ', 'done')}',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            if (list.isEmpty)
              Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  L('এই দিনের জন্য কোনো কাজ নেই। “কাজ” ট্যাবে যোগ করুন, বা সহকারীকে বলুন।',
                      'Nothing planned for this day. Add tasks in the Tasks tab, or ask the assistant.'),
                  textAlign: TextAlign.center,
                  style: TextStyle(color: cs.onSurfaceVariant),
                ),
              ),
            for (final e in list) _EntryCard(entry: e, date: date, isToday: dayOffset == 0),
            if (dayOffset == 0 && app.unplaced.isNotEmpty)
              Card(
                color: cs.tertiaryContainer,
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Text(
                    '${L('আজ জায়গা হয়নি', 'No room today')}: ${app.unplaced.map((t) => t.title).join(', ')}',
                    style: TextStyle(color: cs.onTertiaryContainer),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}

class _EntryCard extends StatelessWidget {
  final PlanEntry entry;
  final DateTime date;
  final bool isToday;
  const _EntryCard({required this.entry, required this.date, required this.isToday});

  @override
  Widget build(BuildContext context) {
    final e = entry;
    final cs = Theme.of(context).colorScheme;
    final kind = app.prefs.resolveAlert(e.alert);
    Widget trailing;
    if (e.status == 1) {
      trailing = Icon(Icons.check_circle, color: cs.primary);
    } else if (e.status == 2) {
      trailing = Icon(Icons.cancel, color: cs.error);
    } else if (e.status == 3) {
      trailing = Icon(Icons.pause_circle_outline, color: cs.onSurfaceVariant);
    } else {
      trailing = Row(mainAxisSize: MainAxisSize.min, children: [
        if (isToday)
          IconButton.filledTonal(
            icon: const Icon(Icons.play_arrow),
            onPressed: () async {
              await AlarmService.cancel(e.alarmId);
              if (!context.mounted) return;
              Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => FocusScreen(entry: e)));
            },
          ),
        PopupMenuButton<String>(
          onSelected: (v) async {
            if (v == 'move') {
              final m = await pickTime(context, e.startMin);
              if (m == null || !context.mounted) return;
              final r = await app.moveEntry(e, m);
              if (!context.mounted) return;
              if (!r.ok) {
                if (r.error == 'past') {
                  snack(context, t('as.err.past'));
                } else if (r.error != null) {
                  snack(context, t('as.err.range'));
                } else {
                  final names = r.conflicts.map((c) => '${c.title} (${fmtMin(c.startMin)})').join(', ');
                  final ok = await confirm(
                    context,
                    L('এই সময়ে অন্য কাজ আছে', 'Time is already used'),
                    '$names\n\n${L('তবুও এখানে রাখবেন?', 'Keep it here anyway?')}',
                  );
                  if (ok && context.mounted) await app.moveEntry(e, m, force: true);
                }
              }
            } else if (v == 'skip') {
              await app.skipToday(e);
            }
          },
          itemBuilder: (_) => [
            PopupMenuItem(value: 'move', child: Text(L('সময় বদলান', 'Change time'))),
            PopupMenuItem(value: 'skip', child: Text(L('আজ করব না', 'Skip today'))),
          ],
        ),
      ]);
    }
    return Card(
      child: ListTile(
        leading: Text(fmtMin(e.startMin), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        title: Text(e.title),
        subtitle: Row(children: [
          Text('${e.minutes} ${L('মিনিট', 'min')}'),
          const SizedBox(width: 6),
          if (e.fixed) const Icon(Icons.lock_outline, size: 14),
          const SizedBox(width: 4),
          Icon(alertIcon(kind), size: 14),
          const SizedBox(width: 6),
          Text('★' * e.priority, style: const TextStyle(color: Colors.amber)),
        ]),
        trailing: trailing,
      ),
    );
  }
}
