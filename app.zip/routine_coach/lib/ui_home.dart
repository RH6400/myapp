import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'alarm_service.dart';
import 'cloud.dart';
import 'i18n.dart';
import 'mailo_widgets.dart';
import 'models.dart';
import 'state.dart';
import 'theme.dart';
import 'ui_alarm.dart';
import 'ui_common.dart';
import 'ui_settings.dart';
import 'ui_tasks.dart';

String _t12(int m) => nd('${(m ~/ 60) % 24}:${(m % 60).toString().padLeft(2, '0')}');

class HomeTab extends StatefulWidget {
  const HomeTab({super.key});
  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  DateTime sel = dayOnly(DateTime.now());

  Future<bool> _permsOk() async {
    try {
      final a = await Permission.notification.isGranted;
      final b = await Permission.scheduleExactAlarm.isGranted;
      final c = await Permission.ignoreBatteryOptimizations.isGranted;
      return a && b && c;
    } catch (_) {
      return true;
    }
  }

  // সপ্তাহ শনিবার থেকে শুরু
  DateTime _weekStart(DateTime d) => DateTime(d.year, d.month, d.day - ((d.weekday + 1) % 7));

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([app, cloud]),
      builder: (context, _) {
        final now = DateTime.now();
        final today = dayOnly(now);
        final isToday = sel == today;
        final list = app.entriesFor(sel);
        final counted = list.where((e) => e.status != 3).toList();
        final done = counted.where((e) => e.status == 1).length;
        final left = counted.where((e) => e.status == 0).length;
        final cs = Theme.of(context).colorScheme;
        final tt = Theme.of(context).textTheme;
        final name = cloud.displayName.trim().split(' ').first;
        PlanEntry? next;
        if (isToday) {
          for (final e in list) {
            if (e.status == 0) {
              next = e;
              break;
            }
          }
        }
        final start = _weekStart(today);

        String title;
        if (counted.isEmpty) {
          title = L('আজ কোনো কাজ নেই', 'Nothing planned');
        } else if (left == 0) {
          title = L('সব কাজ শেষ! 🎉', 'All done! 🎉');
        } else if (done * 2 >= counted.length) {
          title = L('আজ ভালো চলছে', 'Going well today');
        } else {
          title = L('চলুন শুরু করি', "Let's get going");
        }

        return Scaffold(
          backgroundColor: Colors.transparent,
          floatingActionButton: FloatingActionButton(
            onPressed: () => showAddTask(context),
            child: const Icon(Icons.add, size: 28),
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 110),
            children: [
              // ---- হেডার ----
              Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${dayFull(today.weekday)}, ${nd(today.day)} ${monthName(today.month)}',
                        style: tt.bodyMedium?.copyWith(color: cs.onSurfaceVariant)),
                    const SizedBox(height: 2),
                    Text(name.isEmpty ? greetingFor(now) : '${greetingFor(now)}, $name',
                        style: tt.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
                  ]),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                  decoration: BoxDecoration(color: kOrange.withAlpha(36), borderRadius: BorderRadius.circular(20)),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.local_fire_department, size: 17, color: kOrange),
                    const SizedBox(width: 4),
                    Text('${nd(app.streak)} ${L('দিন', 'days')}',
                        style: const TextStyle(color: kOrange, fontWeight: FontWeight.w700)),
                  ]),
                ),
                const SizedBox(width: 12),
                GestureDetector(
                  onTap: () => openSettings(context),
                  child: const MailoLogo(height: 34),
                ),
              ]),
              const SizedBox(height: 16),

              // ---- সপ্তাহের দিন ----
              Row(children: [
                for (var i = 0; i < 7; i++)
                  Expanded(
                    child: _DayCell(
                      date: DateTime(start.year, start.month, start.day + i),
                      selected: DateTime(start.year, start.month, start.day + i) == sel,
                      onTap: () => setState(() => sel = DateTime(start.year, start.month, start.day + i)),
                    ),
                  ),
              ]),
              const SizedBox(height: 14),

              FutureBuilder<bool>(
                future: _permsOk(),
                builder: (c, snap) {
                  if (snap.data != false) return const SizedBox.shrink();
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Card(
                      color: cs.errorContainer,
                      margin: EdgeInsets.zero,
                      child: ListTile(
                        leading: Icon(Icons.warning_amber, color: cs.onErrorContainer),
                        title: Text(L('অ্যালার্ম সময়মতো বাজতে কিছু পারমিশন বাকি', 'Some permissions are missing for on-time alarms'),
                            style: TextStyle(color: cs.onErrorContainer)),
                        trailing: Icon(Icons.chevron_right, color: cs.onErrorContainer),
                        onTap: () => Navigator.of(context)
                            .push(MaterialPageRoute<void>(builder: (_) => const PermScreen()))
                            .then((_) => setState(() {})),
                      ),
                    ),
                  );
                },
              ),

              // ---- অগ্রগতি কার্ড ----
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: cs.surfaceContainerLow,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: cs.outlineVariant),
                ),
                child: Row(children: [
                  SizedBox(
                    width: 64,
                    height: 64,
                    child: Stack(alignment: Alignment.center, children: [
                      Positioned.fill(
                        child: CircularProgressIndicator(
                          value: counted.isEmpty ? 0 : done / counted.length,
                          strokeWidth: 7,
                          strokeCap: StrokeCap.round,
                          backgroundColor: cs.primaryContainer,
                        ),
                      ),
                      Text('${nd(done)}/${nd(counted.length)}',
                          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                    ]),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(title, style: tt.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                      const SizedBox(height: 2),
                      Text(
                        left == 0
                            ? L('${nd(done)}টা কাজ শেষ', '${nd(done)} done')
                            : L('আর ${nd(left)}টা কাজ বাকি', '${nd(left)} left'),
                        style: TextStyle(color: cs.onSurfaceVariant),
                      ),
                    ]),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                    decoration: BoxDecoration(color: cs.primaryContainer, borderRadius: BorderRadius.circular(20)),
                    child: Text('${L('লেভেল', 'Level')} ${nd(app.level)}',
                        style: TextStyle(color: cs.primary, fontWeight: FontWeight.w700, fontSize: 13)),
                  ),
                ]),
              ),

              if (isToday && list.isNotEmpty)
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton.icon(
                    onPressed: () async {
                      await app.replan(force: true);
                      if (context.mounted) snack(context, L('রুটিন নতুন করে সাজানো হয়েছে', 'Routine rearranged'));
                    },
                    icon: const Icon(Icons.auto_awesome, size: 16),
                    label: Text(L('আবার সাজাও', 'Rearrange')),
                  ),
                )
              else
                const SizedBox(height: 12),

              if (list.isEmpty)
                Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(
                    L('এই দিনের জন্য কোনো কাজ নেই। + চেপে কাজ যোগ করুন, বা Mailo-কে বলুন।',
                        'Nothing planned for this day. Tap + to add a task, or ask Mailo.'),
                    textAlign: TextAlign.center,
                    style: TextStyle(color: cs.onSurfaceVariant),
                  ),
                ),
              for (final e in list)
                _EntryRow(entry: e, isToday: isToday, highlighted: identical(e, next)),
              if (isToday && app.unplaced.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Card(
                    color: cs.tertiaryContainer,
                    margin: EdgeInsets.zero,
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Text(
                        '${L('আজ জায়গা হয়নি', 'No room today')}: ${app.unplaced.map((t) => t.title).join(', ')}',
                        style: TextStyle(color: cs.onTertiaryContainer),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _DayCell extends StatelessWidget {
  final DateTime date;
  final bool selected;
  final VoidCallback onTap;
  const _DayCell({required this.date, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 2),
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: selected ? cs.primary : Colors.transparent,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(children: [
          Text(weekdayName(date.weekday),
              style: TextStyle(fontSize: 12, color: selected ? cs.onPrimary : cs.onSurfaceVariant)),
          const SizedBox(height: 4),
          Text(nd(date.day),
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: selected ? cs.onPrimary : cs.onSurface)),
        ]),
      ),
    );
  }
}

class _EntryRow extends StatelessWidget {
  final PlanEntry entry;
  final bool isToday;
  final bool highlighted;
  const _EntryRow({required this.entry, required this.isToday, required this.highlighted});

  Future<void> _menu(BuildContext context, String v) async {
    final e = entry;
    if (v == 'move') {
      final m = await pickTime(context, e.startMin);
      if (m == null || !context.mounted) return;
      final r = await app.moveEntry(e, m);
      if (!context.mounted) return;
      if (!r.ok) {
        if (r.error == 'past') {
          snack(context, t('as.err.past'));
        } else if (r.error != null) {
          snack(context, t('as.err.range'));
        } else {
          final names = r.conflicts.map((c) => '${c.title} (${fmtMin(c.startMin)})').join(', ');
          final ok = await confirm(
            context,
            L('এই সময়ে অন্য কাজ আছে', 'Time is already used'),
            '$names\n\n${L('তবুও এখানে রাখবেন?', 'Keep it here anyway?')}',
          );
          if (ok && context.mounted) await app.moveEntry(e, m, force: true);
        }
      }
    } else if (v == 'skip') {
      await app.skipToday(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    final e = entry;
    final cs = Theme.of(context).colorScheme;
    final hl = highlighted;
    final fg = hl ? cs.onPrimary : cs.onSurface;
    final sub = hl ? cs.onPrimary.withAlpha(215) : cs.onSurfaceVariant;
    final kind = app.prefs.resolveAlert(e.alert);
    final bar = e.status == 1
        ? kGreen
        : e.status == 2
            ? cs.error
            : e.status == 3
                ? cs.outline
                : cs.primary;

    Widget trailing;
    if (e.status == 1) {
      trailing = Container(
        width: 30,
        height: 30,
        decoration: const BoxDecoration(color: kGreen, shape: BoxShape.circle),
        child: const Icon(Icons.check, size: 18, color: Colors.white),
      );
    } else if (e.status == 2) {
      trailing = Icon(Icons.cancel, color: cs.error);
    } else if (e.status == 3) {
      trailing = Icon(Icons.pause_circle_outline, color: cs.onSurfaceVariant);
    } else {
      trailing = Row(mainAxisSize: MainAxisSize.min, children: [
        if (isToday)
          GestureDetector(
            onTap: () async {
              await AlarmService.cancel(e.alarmId);
              if (!context.mounted) return;
              Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => FocusScreen(entry: e)));
            },
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: hl ? Colors.white.withAlpha(60) : cs.primaryContainer,
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.play_arrow_rounded, color: hl ? Colors.white : cs.primary, size: 26),
            ),
          ),
        PopupMenuButton<String>(
          icon: Icon(Icons.more_vert, color: sub, size: 20),
          padding: EdgeInsets.zero,
          onSelected: (v) => _menu(context, v),
          itemBuilder: (_) => [
            PopupMenuItem(value: 'move', child: Text(L('সময় বদলান', 'Change time'))),
            PopupMenuItem(value: 'skip', child: Text(L('আজ করব না', 'Skip today'))),
          ],
        ),
      ]);
    }

    final subParts = <Widget>[
      Text('${nd(e.minutes)} ${L('মিনিট', 'min')}', style: TextStyle(color: sub, fontSize: 13)),
      if (e.fixed) ...[const SizedBox(width: 6), Icon(Icons.lock_outline, size: 13, color: sub)],
      const SizedBox(width: 6),
      Icon(alertIcon(kind), size: 14, color: sub),
      if (hl) ...[
        const SizedBox(width: 6),
        Text('• ${L('এখন শুরু করুন', 'Start now')}', style: TextStyle(color: sub, fontSize: 13)),
      ],
      if (e.priority == 3) ...[const SizedBox(width: 6), const Text('★', style: TextStyle(color: Colors.amber, fontSize: 13))],
    ];

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
        SizedBox(
          width: 50,
          child: Text(_t12(e.startMin),
              style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 14,
                  color: hl ? cs.primary : cs.onSurfaceVariant)),
        ),
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              color: hl ? cs.primary : cs.surfaceContainerLow,
              borderRadius: BorderRadius.circular(18),
              border: hl ? null : Border.all(color: cs.outlineVariant),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(18),
              child: IntrinsicHeight(
                child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  if (!hl) Container(width: 5, color: bar),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(14, 12, 8, 12),
                      child: Row(children: [
                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(e.title,
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 16,
                                  color: e.status == 1 ? cs.onSurfaceVariant : fg,
                                  decoration: e.status == 1 ? TextDecoration.lineThrough : null,
                                )),
                            const SizedBox(height: 3),
                            Row(children: subParts),
                          ]),
                        ),
                        trailing,
                      ]),
                    ),
                  ),
                ]),
              ),
            ),
          ),
        ),
      ]),
    );
  }
}
