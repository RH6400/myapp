import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'alarm_service.dart';
import 'cloud.dart';
import 'i18n.dart';
import 'models.dart';
import 'state.dart';
import 'theme.dart';
import 'ui_alarm.dart';
import 'ui_common.dart';
import 'ui_profile.dart';
import 'ui_settings.dart';
import 'ui_tasks.dart';

class HomeTab extends StatefulWidget {
  const HomeTab({super.key});
  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  int dayOffset = 0;

  Future<bool> _permsOk() async {
    try {
      final a = await Permission.notification.isGranted;
      final b = await Permission.scheduleExactAlarm.isGranted;
      final c = await Permission.ignoreBatteryOptimizations.isGranted;
      return a && b && c;
    } catch (_) {
      return true;
    }
  }

  String _greeting() {
    final h = DateTime.now().hour;
    if (h < 5) return L('শুভ রাত্রি', 'Good night');
    if (h < 12) return L('শুভ সকাল', 'Good morning');
    if (h < 17) return L('শুভ অপরাহ্ন', 'Good afternoon');
    if (h < 20) return L('শুভ সন্ধ্যা', 'Good evening');
    return L('শুভ রাত্রি', 'Good night');
  }

  String _who() {
    if (app.prefs.callName.isNotEmpty) return app.prefs.callName;
    final n = cloud.displayName.trim();
    if (n.isNotEmpty) return n.split(' ').first;
    return '';
  }

  String _dateLabel(DateTime d) {
    const bnDays = ['সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার', 'রবিবার'];
    const enDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const bnMon = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
    const enMon = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    final wd = (gLang == 'en' ? enDays : bnDays)[d.weekday - 1];
    final mo = (gLang == 'en' ? enMon : bnMon)[d.month - 1];
    return '$wd, ${d.day} $mo';
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([app, cloud]),
      builder: (context, _) {
        final p = Pal.of(context);
        final now = DateTime.now();
        final today = DateTime(now.year, now.month, now.day);
        final date = DateTime(now.year, now.month, now.day + dayOffset);
        final list = app.entriesFor(date);
        final counted = list.where((e) => e.status != 3).toList();
        final done = counted.where((e) => e.status == 1).length;
        final left = counted.where((e) => e.status == 0).length;
        final nowMin = now.hour * 60 + now.minute;
        PlanEntry? current;
        if (dayOffset == 0) {
          for (final e in list) {
            if (e.status == 0 && e.startMin + e.minutes > nowMin) {
              current = e;
              break;
            }
          }
        }
        final who = _who();
        final pct = counted.isEmpty ? 0.0 : done / counted.length;
        final headline = counted.isEmpty
            ? L('আজ কোনো কাজ নেই', 'Nothing planned')
            : (done == counted.length
                ? L('দারুণ! সব শেষ', 'Great! All done')
                : (pct >= 0.5 ? L('আজ ভালো চলছে', 'Going well') : L('চলুন শুরু করি', 'Let\'s get going')));
        return Scaffold(
          backgroundColor: Colors.transparent,
          floatingActionButton: FloatingActionButton(
            tooltip: L('নতুন কাজ', 'New task'),
            onPressed: () => showMailoSheet<void>(context, (_) => const AddTaskSheet()),
            child: const Icon(Icons.add, size: 28),
          ),
          body: ListView(
            padding: listPad(context, top: 4, bottom: 96),
            children: [
              // ---------- হেডার ----------
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(_dateLabel(today), style: TextStyle(color: p.sub, fontSize: 13)),
                      const SizedBox(height: 2),
                      Text(who.isEmpty ? _greeting() : '${_greeting()}, $who',
                          style: TextStyle(color: p.tx, fontSize: 22, fontWeight: FontWeight.w700)),
                    ]),
                  ),
                  if (app.streak > 0)
                    Container(
                      margin: const EdgeInsets.only(right: 8, top: 2),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(color: p.fireSoft, borderRadius: BorderRadius.circular(16)),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.local_fire_department, size: 16, color: p.fire),
                        const SizedBox(width: 3),
                        Text('${app.streak} ${L('দিন', 'd')}',
                            style: TextStyle(color: p.fire, fontWeight: FontWeight.w700, fontSize: 12.5)),
                      ]),
                    ),
                  InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: () => Navigator.of(context)
                        .push(MaterialPageRoute<void>(builder: (_) => const ProfileScreen())),
                    child: Padding(
                      padding: const EdgeInsets.all(4),
                      child: Image.asset('assets/mailo_mark.png', height: 30),
                    ),
                  ),
                  PopupMenuButton<String>(
                    icon: Icon(Icons.more_vert, color: p.sub),
                    onSelected: (v) async {
                      if (v == 'rearr') {
                        await app.replan(force: true);
                        if (context.mounted) snack(context, L('রুটিন নতুন করে সাজানো হয়েছে', 'Routine rearranged'));
                      } else if (v == 'profile') {
                        Navigator.of(context)
                            .push(MaterialPageRoute<void>(builder: (_) => const ProfileScreen()));
                      }
                    },
                    itemBuilder: (_) => [
                      PopupMenuItem(value: 'rearr', child: Text(L('রুটিন আবার সাজাও', 'Rearrange routine'))),
                      PopupMenuItem(value: 'profile', child: Text(L('প্রোফাইল ও সেটিংস', 'Profile and settings'))),
                    ],
                  ),
                ]),
              ),
              // ---------- সপ্তাহের স্ট্রিপ ----------
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  for (var i = -2; i <= 4; i++) _dayChip(context, p, today, i),
                ]),
              ),
              // ---------- পারমিশন সতর্কতা ----------
              FutureBuilder<bool>(
                future: _permsOk(),
                builder: (c, snap) {
                  if (snap.data != false) return const SizedBox.shrink();
                  return MCard(
                    margin: const EdgeInsets.only(bottom: 12),
                    color: p.badSoft,
                    border: p.badSoft,
                    onTap: () => Navigator.of(context)
                        .push(MaterialPageRoute<void>(builder: (_) => const PermScreen()))
                        .then((_) => setState(() {})),
                    child: Row(children: [
                      Icon(Icons.warning_amber_rounded, color: p.bad),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          L('অ্যালার্ম সময়মতো বাজতে কিছু পারমিশন বাকি', 'Some permissions are missing for on-time alarms'),
                          style: TextStyle(color: p.bad, fontWeight: FontWeight.w600, fontSize: 13.5),
                        ),
                      ),
                      Icon(Icons.chevron_right, color: p.bad),
                    ]),
                  );
                },
              ),
              // ---------- অগ্রগতি ----------
              MCard(
                child: Row(children: [
                  Ring(value: pct, label: '$done/${counted.length}'),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(headline, style: TextStyle(color: p.tx, fontWeight: FontWeight.w700, fontSize: 15.5)),
                      const SizedBox(height: 2),
                      Text(
                        left == 0
                            ? L('আর কোনো কাজ বাকি নেই', 'Nothing left')
                            : L('আর $left টা কাজ বাকি', '$left task(s) left'),
                        style: TextStyle(color: p.sub, fontSize: 13),
                      ),
                    ]),
                  ),
                  if (app.prefs.useAppRewards)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(color: p.priSoft, borderRadius: BorderRadius.circular(14)),
                      child: Text('${L('লেভেল', 'Lv')} ${app.level}',
                          style: TextStyle(color: p.pri, fontWeight: FontWeight.w700, fontSize: 12.5)),
                    ),
                ]),
              ),
              const SizedBox(height: 14),
              if (list.isEmpty)
                Padding(
                  padding: const EdgeInsets.all(28),
                  child: Text(
                    L('এই দিনের জন্য কোনো কাজ নেই। নিচের “+” বাটনে কাজ যোগ করুন, বা সহকারীকে বলুন।',
                        'Nothing planned for this day. Tap “+” to add a task, or ask the assistant.'),
                    textAlign: TextAlign.center,
                    style: TextStyle(color: p.sub),
                  ),
                ),
              for (final e in list)
                _EntryRow(entry: e, date: date, isToday: dayOffset == 0, highlight: identical(e, current)),
              if (dayOffset == 0 && app.unplaced.isNotEmpty)
                MCard(
                  margin: const EdgeInsets.only(top: 4),
                  color: p.fireSoft,
                  border: p.fireSoft,
                  child: Text(
                    '${L('আজ জায়গা হয়নি', 'No room today')}: ${app.unplaced.map((t) => t.title).join(', ')}',
                    style: TextStyle(color: p.fire, fontWeight: FontWeight.w600, fontSize: 13),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  Widget _dayChip(BuildContext context, Pal p, DateTime today, int i) {
    final d = DateTime(today.year, today.month, today.day + i);
    final sel = i == dayOffset;
    return GestureDetector(
      onTap: () {
        if (i < -2 || i > 6) return;
        setState(() => dayOffset = i);
      },
      child: Container(
        width: 43,
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: sel ? p.pri : Colors.transparent,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(children: [
          Text(weekdayName(d.weekday),
              style: TextStyle(fontSize: 11, color: sel ? p.onPri : p.sub)),
          const SizedBox(height: 3),
          Text('${d.day}',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: sel ? p.onPri : p.tx)),
        ]),
      ),
    );
  }
}

class _EntryRow extends StatelessWidget {
  final PlanEntry entry;
  final DateTime date;
  final bool isToday;
  final bool highlight;
  const _EntryRow({required this.entry, required this.date, required this.isToday, required this.highlight});

  Future<void> _menu(BuildContext context, String v) async {
    final e = entry;
    if (v == 'move') {
      final m = await pickTime(context, e.startMin);
      if (m == null || !context.mounted) return;
      final r = await app.moveEntry(e, m);
      if (!context.mounted) return;
      if (!r.ok) {
        if (r.error == 'past') {
          snack(context, t('as.err.past'));
        } else if (r.error != null) {
          snack(context, t('as.err.range'));
        } else {
          final names = r.conflicts.map((c) => '${c.title} (${fmtMin(c.startMin)})').join(', ');
          final ok = await confirm(
            context,
            L('এই সময়ে অন্য কাজ আছে', 'Time is already used'),
            '$names\n\n${L('তবুও এখানে রাখবেন?', 'Keep it here anyway?')}',
          );
          if (ok && context.mounted) await app.moveEntry(e, m, force: true);
        }
      }
    } else if (v == 'skip') {
      await app.skipToday(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    final e = entry;
    final p = Pal.of(context);
    final kind = app.prefs.resolveAlert(e.alert);
    final done = e.status == 1;
    final skipped = e.status == 2 || e.status == 3;
    final fg = highlight ? p.onPri : p.tx;
    final fgSub = highlight ? p.onPri.withAlpha(210) : p.sub;
    final accent = done ? p.ok : (skipped ? p.line : (highlight ? p.onPri : p.pri));

    Widget trailing;
    if (done) {
      trailing = Container(
        width: 26,
        height: 26,
        decoration: BoxDecoration(color: p.ok, shape: BoxShape.circle),
        child: const Icon(Icons.check, size: 16, color: Colors.white),
      );
    } else if (skipped) {
      trailing = Icon(Icons.pause_circle_outline, color: p.sub, size: 24);
    } else if (date.isBefore(DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day))) {
      trailing = Icon(Icons.history, color: p.sub, size: 22);
    } else {
      trailing = Row(mainAxisSize: MainAxisSize.min, children: [
        if (isToday)
          InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: () async {
              await AlarmService.cancel(e.alarmId);
              if (!context.mounted) return;
              Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => FocusScreen(entry: e)));
            },
            child: Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: highlight ? p.onPri.withAlpha(40) : p.priSoft,
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.play_arrow_rounded, color: highlight ? p.onPri : p.pri),
            ),
          ),
        PopupMenuButton<String>(
          icon: Icon(Icons.more_vert, size: 20, color: fgSub),
          onSelected: (v) => _menu(context, v),
          itemBuilder: (_) => [
            PopupMenuItem(value: 'move', child: Text(L('সময় বদলান', 'Change time'))),
            PopupMenuItem(value: 'skip', child: Text(L('আজ করব না', 'Skip today'))),
          ],
        ),
      ]);
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(
          width: 50,
          child: Padding(
            padding: const EdgeInsets.only(top: 15, right: 8),
            child: Text(fmtMin(e.startMin),
                textAlign: TextAlign.right,
                style: TextStyle(
                    color: highlight ? p.pri : p.sub, fontSize: 12.5, fontWeight: FontWeight.w600)),
          ),
        ),
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              color: highlight ? p.pri : p.card,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: highlight ? p.pri : p.line),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: IntrinsicHeight(
                child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  Container(width: 4, color: accent),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(12, 10, 6, 10),
                      child: Row(children: [
                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(
                              e.title,
                              style: TextStyle(
                                color: done || skipped ? p.sub : fg,
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                                decoration: done ? TextDecoration.lineThrough : null,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Row(children: [
                              Text('${e.minutes} ${L('মিনিট', 'min')}', style: TextStyle(color: fgSub, fontSize: 12)),
                              const SizedBox(width: 8),
                              Icon(alertIcon(kind), size: 13, color: fgSub),
                              if (e.fixed) ...[
                                const SizedBox(width: 6),
                                Icon(Icons.lock_outline, size: 13, color: fgSub),
                              ],
                            ]),
                          ]),
                        ),
                        trailing,
                      ]),
                    ),
                  ),
                ]),
              ),
            ),
          ),
        ),
      ]),
    );
  }
}
