import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'i18n.dart';
import 'mailo_pet.dart';
import 'models.dart';
import 'state.dart';
import 'theme.dart';
import 'ui_common.dart';

String goalProgressText(Goal g) {
  switch (g.type) {
    case 'days':
      return '${g.doneDays.length}/${g.target.round()} ${L('দিন', 'days')}';
    case 'count':
      return '${g.doneCount}/${g.target.round()} ${L('বার', 'times')}';
    default:
      return '${_n(g.current)} → ${_n(g.target)} ${g.unit}';
  }
}

String _n(double v) => v == v.roundToDouble() ? v.round().toString() : v.toStringAsFixed(1);

/// সারাংশ: কতটা কাজ হলো, কোন লক্ষ্য কতদূর, আর Mailo-র পরামর্শ।
class SummaryTab extends StatefulWidget {
  const SummaryTab({super.key});
  @override
  State<SummaryTab> createState() => _SummaryTabState();
}

class _SummaryTabState extends State<SummaryTab> {
  int days = 7;

  String _periodLabel(int d) {
    if (d == 7) return L('এই সপ্তাহ', 'This week');
    if (d == 30) return L('এই মাস', 'This month');
    return L('সব সময়', 'All time');
  }

  String _insight(PeriodStats st) {
    // কোন কাজ বারবার বাদ পড়ছে
    TaskItem? worst;
    var worstSkips = 1;
    for (final t in app.tasks) {
      final s = app.periodStats(days, taskId: t.id);
      if (s.skipped > worstSkips) {
        worstSkips = s.skipped;
        worst = t;
      }
    }
    if (worst != null) {
      return L('“${worst.title}” $worstSkips বার বাদ গেছে। সময়টা বদলে সকালে বা ছোট করে রাখলে কেমন হয়?',
          '“${worst.title}” was missed $worstSkips times. Maybe move it earlier or make it shorter?');
    }
    Goal? behind;
    for (final g in app.goals) {
      if (app.goalStatus(g) == 'behind') behind = g;
    }
    if (behind != null) {
      return L('“${behind.title}” লক্ষ্য একটু পিছিয়ে। এই সপ্তাহে আরও একটা সেশন যোগ করবেন?',
          'Your goal “${behind.title}” is behind. Add one more session this week?');
    }
    final counted = st.done + st.left + st.skipped;
    if (counted == 0) {
      return L('কয়েকটা কাজ যোগ করুন, তারপর আমি আপনার অগ্রগতি দেখে পরামর্শ দেব।',
          'Add a few tasks and I will advise you based on your progress.');
    }
    final pct = (st.done * 100 / counted).round();
    if (pct >= 80) return L('দারুণ! $pct% কাজ শেষ। এভাবেই চালিয়ে যান।', 'Great! $pct% of tasks done. Keep going.');
    if (pct >= 50) return L('ভালো চলছে ($pct%)। বাকি কাজগুলো এই সপ্তাহেই শেষ করে ফেলুন।', 'Going well ($pct%). Finish the rest this week.');
    return L('এখন $pct% কাজ শেষ। ছোট কাজ দিয়ে আবার শুরু করুন, আমি সময় সাজাতে সাহায্য করব।',
        'Only $pct% done so far. Restart with a small task and I will help arrange your time.');
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final p = Pal.of(context);
        final st = app.periodStats(days);
        final counted = st.done + st.left + st.skipped;
        final pct = counted == 0 ? 0.0 : st.done / counted;
        final hrs = st.minutes ~/ 60;
        final mins = st.minutes % 60;
        return ListView(
          padding: listPad(context, top: 0, bottom: 24),
          children: [
            ScreenHeader(
              L('সারাংশ', 'Summary'),
              actions: [
                PopupMenuButton<int>(
                  onSelected: (v) => setState(() => days = v),
                  itemBuilder: (_) => [
                    for (final d in const [7, 30, 60])
                      PopupMenuItem(value: d, child: Text(_periodLabel(d))),
                  ],
                  child: Container(
                    margin: const EdgeInsets.only(right: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(color: p.priSoft, borderRadius: BorderRadius.circular(16)),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Text(_periodLabel(days), style: TextStyle(color: p.pri, fontWeight: FontWeight.w600, fontSize: 13)),
                      Icon(Icons.arrow_drop_down, color: p.pri, size: 20),
                    ]),
                  ),
                ),
              ],
            ),
            // ---------- মোট হিসাব ----------
            MCard(
              child: Column(children: [
                Row(children: [
                  Ring(value: pct, label: '${(pct * 100).round()}%', size: 70),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(
                        L('$counted টা কাজের মধ্যে ${st.done}টা শেষ', '${st.done} of $counted tasks done'),
                        style: TextStyle(color: p.tx, fontWeight: FontWeight.w700, fontSize: 15.5),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '${L('ফোকাস', 'Focus')}: $hrs${L(' ঘণ্টা ', ' h ')}$mins${L(' মিনিট', ' min')}',
                        style: TextStyle(color: p.sub, fontSize: 13),
                      ),
                    ]),
                  ),
                ]),
                const SizedBox(height: 14),
                Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                  _stat('${st.done}', L('শেষ', 'Done'), p.ok, p),
                  _stat('${st.left}', L('বাকি', 'Left'), p.pri, p),
                  _stat('${st.skipped}', L('ছাড়া', 'Skipped'), p.bad, p),
                  _stat('${app.streak}', L('দিন স্ট্রিক', 'Day streak'), p.fire, p),
                ]),
              ]),
            ),
            // ---------- Mailo বলছে ----------
            MCard(
              margin: const EdgeInsets.only(top: 12),
              color: p.priSoft,
              border: p.priSoft,
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const MailoPet(size: 64, blinkOnly: true),
                const SizedBox(width: 6),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: RichText(
                      text: TextSpan(
                        style: TextStyle(color: p.tx, fontSize: 13.5, height: 1.5),
                        children: [
                          TextSpan(
                              text: '${app.prefs.assistantName} ${L('বলছে', 'says')}: ',
                              style: const TextStyle(fontWeight: FontWeight.w700)),
                          TextSpan(text: _insight(st)),
                        ],
                      ),
                    ),
                  ),
                ),
              ]),
            ),
            // ---------- লক্ষ্য ----------
            SectionTitle(
              L('আমার লক্ষ্য', 'My goals'),
              trailing: TextButton.icon(
                onPressed: () => showMailoSheet<void>(context, (_) => const GoalSheet()),
                icon: const Icon(Icons.add, size: 18),
                label: Text(L('নতুন', 'New')),
              ),
            ),
            if (app.goals.isEmpty)
              MCard(
                child: Text(
                  L('এখনো কোনো লক্ষ্য নেই। “নতুন” চাপুন, অথবা ${app.prefs.assistantName}-কে বলুন, যেমন: “২ মাসে ৫ কেজি কমাতে চাই”।',
                      'No goals yet. Tap “New”, or tell ${app.prefs.assistantName}, e.g. “I want to lose 5 kg in 2 months”.'),
                  style: TextStyle(color: p.sub, fontSize: 13.5),
                ),
              ),
            for (final g in app.goals) _goalCard(context, p, g),
            // ---------- কাজ অনুযায়ী ----------
            SectionTitle(L('কাজ অনুযায়ী', 'By task')),
            if (app.tasks.isEmpty)
              MCard(child: Text(L('কোনো কাজ নেই।', 'No tasks.'), style: TextStyle(color: p.sub))),
            if (app.tasks.isNotEmpty)
              SettingGroup(children: [
                for (final t in app.tasks) _taskLine(p, t),
              ]),
          ],
        );
      },
    );
  }

  Widget _stat(String v, String label, Color c, Pal p) {
    return Column(children: [
      Text(v, style: TextStyle(color: c, fontSize: 19, fontWeight: FontWeight.w800)),
      Text(label, style: TextStyle(color: p.sub, fontSize: 11.5)),
    ]);
  }

  Widget _goalCard(BuildContext context, Pal p, Goal g) {
    final f = app.goalFraction(g);
    final status = app.goalStatus(g);
    final c = goalStatusColor(p, status);
    return MCard(
      margin: const EdgeInsets.only(bottom: 9),
      onTap: () => showMailoSheet<void>(context, (_) => GoalSheet(goal: g)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(
            child: Text(g.title, style: TextStyle(color: p.tx, fontWeight: FontWeight.w700, fontSize: 14.5)),
          ),
          StatusTag(goalStatusLabel(status), color: c, bg: goalStatusBg(p, status)),
        ]),
        const SizedBox(height: 3),
        Row(children: [
          Text(goalProgressText(g), style: TextStyle(color: p.sub, fontSize: 12.5)),
          const Spacer(),
          Text(
            app.goalDaysLeft(g) >= 0
                ? L('${app.goalDaysLeft(g)} দিন বাকি', '${app.goalDaysLeft(g)} days left')
                : L('সময় শেষ', 'Ended'),
            style: TextStyle(color: p.sub, fontSize: 12),
          ),
        ]),
        const SizedBox(height: 8),
        Bar(f, color: c),
      ]),
    );
  }

  Widget _taskLine(Pal p, TaskItem t) {
    final s = app.periodStats(days, taskId: t.id);
    final total = s.done + s.left + s.skipped;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Row(children: [
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t.title, style: TextStyle(color: t.enabled ? p.tx : p.sub, fontWeight: FontWeight.w600, fontSize: 14)),
            const SizedBox(height: 4),
            Bar(total == 0 ? 0 : s.done / total, color: p.ok, height: 6),
          ]),
        ),
        const SizedBox(width: 12),
        Text(
          total == 0
              ? '—'
              : '${s.done}/$total${s.skipped > 0 ? '  • ${L('ছাড়া', 'missed')} ${s.skipped}' : ''}',
          style: TextStyle(color: p.sub, fontSize: 12.5),
        ),
      ]),
    );
  }
}

/// লক্ষ্য তৈরি বা বদলানোর শীট।
class GoalSheet extends StatefulWidget {
  final Goal? goal;
  const GoalSheet({super.key, this.goal});
  @override
  State<GoalSheet> createState() => _GoalSheetState();
}

class _GoalSheetState extends State<GoalSheet> {
  late final title = TextEditingController(text: widget.goal?.title ?? '');
  late final target = TextEditingController(
      text: widget.goal == null ? '30' : _n(widget.goal!.target));
  late final unit = TextEditingController(text: widget.goal?.unit ?? '');
  late final startVal = TextEditingController(text: _n(widget.goal?.startValue ?? 0));
  late final curVal = TextEditingController(text: _n(widget.goal?.current ?? 0));
  late final dur = TextEditingController(text: _initialDays().toString());
  late String type = widget.goal?.type ?? 'days';
  late Set<String> linked = {...?widget.goal?.taskIds};
  String? err;

  bool get editing => widget.goal != null;

  int _initialDays() {
    final g = widget.goal;
    if (g == null) return 30;
    try {
      return DateTime.parse(g.endDate).difference(DateTime.parse(g.startDate)).inDays + 1;
    } catch (_) {
      return 30;
    }
  }

  @override
  void dispose() {
    title.dispose();
    target.dispose();
    unit.dispose();
    startVal.dispose();
    curVal.dispose();
    dur.dispose();
    super.dispose();
  }

  double _d(TextEditingController c, double def) =>
      double.tryParse(c.text.trim().replaceAll(',', '.')) ?? def;

  Future<void> _save() async {
    final name = title.text.trim();
    if (name.isEmpty) {
      setState(() => err = L('লক্ষ্যের নাম লিখুন', 'Enter a goal name'));
      return;
    }
    final tg = _d(target, 0);
    if (tg <= 0 && type != 'number') {
      setState(() => err = L('লক্ষ্যমাত্রা ০-র বেশি হতে হবে', 'Target must be above 0'));
      return;
    }
    final d = _d(dur, 30).round().clamp(1, 730);
    final now = DateTime.now();
    if (editing) {
      final g = widget.goal!;
      g.title = name;
      g.type = type;
      g.target = tg;
      g.unit = unit.text.trim();
      if (type == 'number') {
        g.startValue = _d(startVal, g.startValue);
        g.current = _d(curVal, g.current);
      }
      g.taskIds = linked.toList();
      try {
        g.endDate = dateKey(DateTime.parse(g.startDate).add(Duration(days: d - 1)));
      } catch (_) {}
      app.saveGoals();
    } else {
      await app.addGoal(Goal(
        id: now.microsecondsSinceEpoch.toString(),
        title: name,
        type: type,
        target: tg,
        startValue: type == 'number' ? _d(startVal, 0) : 0,
        current: type == 'number' ? _d(startVal, 0) : 0,
        unit: unit.text.trim(),
        startDate: dateKey(now),
        endDate: dateKey(now.add(Duration(days: d - 1))),
        taskIds: linked.toList(),
      ));
    }
    if (mounted) Navigator.pop(context);
  }

  Future<void> _delete() async {
    final ok = await confirm(context, L('লক্ষ্যটা মুছবেন?', 'Delete this goal?'),
        L('এর সাথে যুক্ত পুরস্কারও মুছে যাবে। কাজগুলো থাকবে।', 'Linked rewards will be removed too. Your tasks stay.'),
        yes: L('মুছুন', 'Delete'));
    if (!ok || !mounted) return;
    await app.removeGoal(widget.goal!.id);
    if (mounted) Navigator.pop(context);
  }

  InputDecoration _dec(String label, {String? hint}) => InputDecoration(
        labelText: label,
        hintText: hint,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      );

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final mq = MediaQuery.of(context);
    final bottom = math.max(mq.viewInsets.bottom, mq.viewPadding.bottom);
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Flexible(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(18, 0, 18, 8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(
                child: Text(editing ? L('লক্ষ্য বদলান', 'Edit goal') : L('নতুন লক্ষ্য', 'New goal'),
                    style: TextStyle(color: p.tx, fontSize: 18, fontWeight: FontWeight.w700)),
              ),
              if (editing)
                IconButton(icon: Icon(Icons.delete_outline, color: p.bad), onPressed: _delete),
            ]),
            const SizedBox(height: 6),
            TextField(
              controller: title,
              decoration: _dec(L('লক্ষ্যের নাম', 'Goal name'), hint: L('যেমন: ৫ কেজি কমানো', 'e.g. Lose 5 kg')).copyWith(errorText: err),
              onChanged: (_) {
                if (err != null) setState(() => err = null);
              },
            ),
            const SizedBox(height: 12),
            SegmentedButton<String>(
              segments: [
                ButtonSegment(value: 'days', label: Text(L('দিন গোনা', 'Days'))),
                ButtonSegment(value: 'count', label: Text(L('বার গোনা', 'Times'))),
                ButtonSegment(value: 'number', label: Text(L('সংখ্যা', 'Number'))),
              ],
              selected: {type},
              onSelectionChanged: (s) => setState(() => type = s.first),
            ),
            const SizedBox(height: 4),
            Text(
              type == 'days'
                  ? L('যত দিন কাজ করবেন তত দিন গোনা হবে।', 'Counts each day you finish a linked task.')
                  : (type == 'count'
                      ? L('প্রতিবার কাজ শেষ করলে গোনা হবে।', 'Counts every time you finish a linked task.')
                      : L('ওজন, টাকা, পাতা ইত্যাদি: নিজে হালনাগাদ করবেন।', 'Weight, money, pages etc.: you update it yourself.')),
              style: TextStyle(color: p.sub, fontSize: 12),
            ),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: TextField(
                  controller: target,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: _dec(L('লক্ষ্যমাত্রা', 'Target')),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: dur,
                  keyboardType: TextInputType.number,
                  decoration: _dec(L('কত দিনে', 'Within days')),
                ),
              ),
            ]),
            if (type == 'number') ...[
              const SizedBox(height: 10),
              Row(children: [
                Expanded(
                  child: TextField(
                    controller: startVal,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
                    decoration: _dec(L('শুরুর মান', 'Start value')),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: unit,
                    decoration: _dec(L('একক', 'Unit'), hint: 'kg'),
                  ),
                ),
              ]),
              if (editing) ...[
                const SizedBox(height: 10),
                TextField(
                  controller: curVal,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
                  decoration: _dec(L('এখনকার মান (হালনাগাদ)', 'Current value (update)')),
                ),
              ],
            ],
            if (type != 'number') ...[
              SectionTitle(L('কোন কাজ গোনা হবে', 'Which tasks count')),
              if (app.tasks.isEmpty)
                Text(L('আগে কাজ যোগ করুন।', 'Add tasks first.'), style: TextStyle(color: p.sub)),
              Wrap(spacing: 8, runSpacing: 6, children: [
                for (final t in app.tasks)
                  FilterChip(
                    label: Text(t.title),
                    selected: linked.contains(t.id),
                    onSelected: (v) => setState(() => v ? linked.add(t.id) : linked.remove(t.id)),
                  ),
              ]),
            ],
            const SizedBox(height: 8),
          ]),
        ),
      ),
      Padding(
        padding: EdgeInsets.fromLTRB(18, 8, 18, 12 + bottom),
        child: SizedBox(
          width: double.infinity,
          child: FilledButton(
            onPressed: _save,
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Text(editing ? L('সেভ করুন', 'Save') : L('লক্ষ্য যোগ করুন', 'Add goal'),
                  style: const TextStyle(fontSize: 15)),
            ),
          ),
        ),
      ),
    ]);
  }
}
