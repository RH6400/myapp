// এই ফাইল setup.sh নিজে নতুন করে লেখে (google-services.json থেকে)।
// google-services.json না থাকলে অ্যাপ লগইন ছাড়াই (শুধু ফোনে) চলে।
const String kFirebaseApiKey = '';
const String kFirebaseAppId = '';
const String kFirebaseSenderId = '';
const String kFirebaseProjectId = '';
const String kWebClientId = '';
