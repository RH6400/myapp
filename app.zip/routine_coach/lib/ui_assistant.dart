import 'package:flutter/material.dart';
import 'insights.dart';
import 'state.dart';

class AssistantTab extends StatefulWidget {
  const AssistantTab({super.key});
  @override
  State<AssistantTab> createState() => _AssistantTabState();
}

class _Msg {
  final bool user;
  final String text;
  _Msg(this.user, this.text);
}

class _AssistantTabState extends State<AssistantTab> {
  final msgs = <_Msg>[];
  final input = TextEditingController();
  bool loading = false;

  Future<void> send(String q) async {
    if (q.trim().isEmpty || loading) return;
    setState(() {
      msgs.add(_Msg(true, q.trim()));
      loading = true;
      input.clear();
    });
    final r = await askAssistant(app, q.trim());
    if (!mounted) return;
    setState(() {
      msgs.add(_Msg(false, r));
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final insights = localInsights(app);
        return Column(children: [
          ListTile(
            title: const Text('স্মার্ট সহকারী'),
            subtitle: Text(app.geminiKey.isEmpty ? 'অফলাইন মোড' : 'AI চালু (${app.geminiModel})'),
            trailing: IconButton(
              icon: const Icon(Icons.settings),
              onPressed: () => _settings(context),
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                for (final i in insights)
                  Card(child: Padding(padding: const EdgeInsets.all(12), child: Text(i))),
                const SizedBox(height: 8),
                Wrap(spacing: 8, children: [
                  for (final q in const [
                    'আজ কোন কাজ আগে করব?',
                    'আমার রুটিন আরও ভালো করো',
                    'কেন কাজ মিস হচ্ছে?',
                  ])
                    ActionChip(label: Text(q), onPressed: () => send(q)),
                ]),
                const SizedBox(height: 8),
                for (final m in msgs)
                  Align(
                    alignment: m.user ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      padding: const EdgeInsets.all(12),
                      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.85),
                      decoration: BoxDecoration(
                        color: m.user
                            ? Theme.of(context).colorScheme.primaryContainer
                            : Theme.of(context).colorScheme.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Text(m.text),
                    ),
                  ),
                if (loading)
                  const Padding(padding: EdgeInsets.all(12), child: LinearProgressIndicator()),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: input,
                  onSubmitted: send,
                  decoration: const InputDecoration(
                    hintText: 'সহকারীকে জিজ্ঞেস করুন…',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(onPressed: () => send(input.text), icon: const Icon(Icons.send)),
            ]),
          ),
        ]);
      },
    );
  }

  Future<void> _settings(BuildContext context) async {
    final key = TextEditingController(text: app.geminiKey);
    final model = TextEditingController(text: app.geminiModel);
    await showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('AI সেটিংস'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Google AI Studio থেকে ফ্রি Gemini API কী নিয়ে বসান।',
              style: TextStyle(fontSize: 12)),
          TextField(controller: key, decoration: const InputDecoration(labelText: 'API কী'), obscureText: true),
          TextField(controller: model, decoration: const InputDecoration(labelText: 'মডেলের নাম')),
        ]),
        actions: [
          TextButton(
            onPressed: () {
              app.setApiSettings(key.text, model.text);
              Navigator.pop(c);
            },
            child: const Text('সংরক্ষণ'),
          ),
        ],
      ),
    );
  }
}
