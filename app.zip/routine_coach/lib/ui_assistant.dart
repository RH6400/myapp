import 'package:flutter/material.dart';
import 'ai.dart';
import 'assistant.dart';
import 'i18n.dart';
import 'mailo_pet.dart';
import 'state.dart';
import 'theme.dart';
import 'ui_common.dart';
import 'ui_settings.dart';

class AssistantTab extends StatefulWidget {
  const AssistantTab({super.key});
  @override
  State<AssistantTab> createState() => _AssistantTabState();
}

class _AssistantTabState extends State<AssistantTab> {
  final input = TextEditingController();
  final scroll = ScrollController();

  @override
  void initState() {
    super.initState();
    assistant.greet();
  }

  @override
  void dispose() {
    input.dispose();
    scroll.dispose();
    super.dispose();
  }

  void _toBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scroll.hasClients) {
        scroll.animateTo(scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
      }
    });
  }

  void _send(String text, {String? shown}) {
    if (text.trim().isEmpty) return;
    input.clear();
    assistant.send(text, shown: shown);
  }

  void _chip(ChatChip c) {
    if (c.cmd == '#openperm') {
      Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const PermScreen()));
      return;
    }
    _send(c.cmd, shown: c.label);
  }

  void _prefill(String s) {
    input.text = s;
    input.selection = TextSelection.collapsed(offset: s.length);
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return ListenableBuilder(
      listenable: Listenable.merge([assistant, app]),
      builder: (context, _) {
        _toBottom();
        final msgs = assistant.msgs;
        return Column(children: [
          // ---------- হেডার ----------
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 6, 4, 2),
            child: Row(children: [
              const MailoPet(size: 76),
              const SizedBox(width: 6),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(app.prefs.assistantName,
                      style: TextStyle(color: p.tx, fontSize: 19, fontWeight: FontWeight.w700)),
                  Text(
                    aiClient.available ? aiClient.label : L('অফলাইন মোড', 'Offline mode'),
                    style: TextStyle(color: p.sub, fontSize: 12.5),
                  ),
                ]),
              ),
              PopupMenuButton<String>(
                icon: Icon(Icons.more_vert, color: p.sub),
                onSelected: (v) {
                  if (v == 'taught') {
                    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const TaughtScreen()));
                  } else if (v.startsWith('mood:')) {
                    app.prefs.mood = v.substring(5);
                    app.savePrefs();
                  }
                },
                itemBuilder: (_) => [
                  PopupMenuItem(
                      value: 'taught',
                      child: Text(L('যা শিখিয়েছি', 'What I taught ${app.prefs.assistantName}'))),
                  for (final m in const ['quiet', 'normal', 'chatty', 'coach'])
                    PopupMenuItem(
                      value: 'mood:$m',
                      child: Row(children: [
                        Icon(app.prefs.mood == m ? Icons.check : null, size: 18, color: p.pri),
                        const SizedBox(width: 8),
                        Text('${L('মুড', 'Mood')}: ${moodLabel(m)}'),
                      ]),
                    ),
                ],
              ),
            ]),
          ),
          // ---------- মেসেজ ----------
          Expanded(
            child: ListView.builder(
              controller: scroll,
              padding: const EdgeInsets.fromLTRB(14, 6, 14, 6),
              itemCount: msgs.length + (assistant.busy ? 1 : 0),
              itemBuilder: (context, i) {
                if (i >= msgs.length) {
                  return Padding(
                    padding: const EdgeInsets.all(12),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: SizedBox(width: 60, child: LinearProgressIndicator(borderRadius: BorderRadius.circular(4))),
                    ),
                  );
                }
                final m = msgs[i];
                final isLast = i == msgs.length - 1;
                return Column(
                  crossAxisAlignment: m.user ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.82),
                      decoration: BoxDecoration(
                        color: m.user ? p.pri : p.card,
                        border: m.user ? null : Border.all(color: p.line),
                        borderRadius: BorderRadius.only(
                          topLeft: const Radius.circular(18),
                          topRight: const Radius.circular(18),
                          bottomLeft: Radius.circular(m.user ? 18 : 5),
                          bottomRight: Radius.circular(m.user ? 5 : 18),
                        ),
                      ),
                      child: Text(m.text,
                          style: TextStyle(color: m.user ? p.onPri : p.tx, fontSize: 14.5, height: 1.45)),
                    ),
                    if (!m.user && isLast && m.chips.isNotEmpty && !assistant.busy)
                      Wrap(spacing: 8, runSpacing: 6, children: [
                        for (final c in m.chips)
                          ActionChip(
                            label: Text(c.label, style: TextStyle(color: p.pri, fontWeight: FontWeight.w600)),
                            backgroundColor: p.priSoft,
                            side: BorderSide.none,
                            onPressed: () => _chip(c),
                          ),
                      ]),
                  ],
                );
              },
            ),
          ),
          // ---------- দ্রুত বাটন ----------
          SizedBox(
            height: 40,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: [
                _quick(L('আজ কী বাকি?', 'What is left today?'), () => _send('#plan', shown: L('আজ কী বাকি?', 'What is left today?'))),
                _quick(L('লক্ষ্য ঠিক করি', 'Set a goal'),
                    () => _prefill(L('লক্ষ্য ৩০ দিন ', 'goal 30 days '))),
                _quick(L('আমাকে শেখান', 'Teach me'),
                    () => _prefill(L('এখন থেকে ', 'From now on '))),
                _quick(L('কীভাবে ব্যবহার করব?', 'How to use?'), () => _send('#help', shown: L('কীভাবে ব্যবহার করব?', 'How to use?'))),
              ],
            ),
          ),
          // ---------- ইনপুট ----------
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 10),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: input,
                  onSubmitted: _send,
                  textInputAction: TextInputAction.send,
                  decoration: InputDecoration(
                    hintText: L('${app.prefs.assistantName}-কে লিখুন…', 'Message ${app.prefs.assistantName}…'),
                    filled: true,
                    fillColor: p.card,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(26),
                      borderSide: BorderSide(color: p.line),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(26),
                      borderSide: BorderSide(color: p.line),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(onPressed: () => _send(input.text), icon: const Icon(Icons.send_rounded)),
            ]),
          ),
        ]);
      },
    );
  }

  Widget _quick(String label, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ActionChip(label: Text(label), onPressed: onTap),
    );
  }
}
