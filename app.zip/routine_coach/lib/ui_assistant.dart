import 'package:flutter/material.dart';
import 'assistant.dart';
import 'i18n.dart';
import 'state.dart';
import 'ui_common.dart';
import 'ui_settings.dart';

class AssistantTab extends StatefulWidget {
  const AssistantTab({super.key});
  @override
  State<AssistantTab> createState() => _AssistantTabState();
}

class _AssistantTabState extends State<AssistantTab> {
  final input = TextEditingController();
  final scroll = ScrollController();

  @override
  void initState() {
    super.initState();
    assistant.greet();
  }

  @override
  void dispose() {
    input.dispose();
    scroll.dispose();
    super.dispose();
  }

  void _toBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scroll.hasClients) {
        scroll.animateTo(scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
      }
    });
  }

  void _send(String text, {String? shown}) {
    if (text.trim().isEmpty) return;
    input.clear();
    assistant.send(text, shown: shown);
  }

  void _chip(ChatChip c) {
    if (c.cmd == '#openperm') {
      Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const PermScreen()));
      return;
    }
    _send(c.cmd, shown: c.label);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return ListenableBuilder(
      listenable: Listenable.merge([assistant, app]),
      builder: (context, _) {
        _toBottom();
        final msgs = assistant.msgs;
        return Column(children: [
          ListTile(
            title: Text(L('স্মার্ট সহকারী', 'Smart assistant')),
            subtitle: Text(app.prefs.geminiKey.isEmpty
                ? L('অফলাইন মোড', 'Offline mode')
                : 'AI (${app.prefs.geminiModel})'),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(children: [
              Text('${L('মুড', 'Mood')}: ', style: TextStyle(color: cs.onSurfaceVariant)),
              for (final m in const ['quiet', 'normal', 'chatty', 'coach'])
                Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: ChoiceChip(
                    label: Text(moodLabel(m)),
                    selected: app.prefs.mood == m,
                    onSelected: (_) {
                      app.prefs.mood = m;
                      app.savePrefs();
                    },
                  ),
                ),
            ]),
          ),
          Expanded(
            child: ListView.builder(
              controller: scroll,
              padding: const EdgeInsets.all(12),
              itemCount: msgs.length + (assistant.busy ? 1 : 0),
              itemBuilder: (context, i) {
                if (i >= msgs.length) {
                  return const Padding(padding: EdgeInsets.all(12), child: LinearProgressIndicator());
                }
                final m = msgs[i];
                final isLast = i == msgs.length - 1;
                return Column(
                  crossAxisAlignment: m.user ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      padding: const EdgeInsets.all(12),
                      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.85),
                      decoration: BoxDecoration(
                        color: m.user ? cs.primaryContainer : cs.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Text(m.text),
                    ),
                    if (!m.user && isLast && m.chips.isNotEmpty && !assistant.busy)
                      Wrap(spacing: 8, runSpacing: 4, children: [
                        for (final c in m.chips) ActionChip(label: Text(c.label), onPressed: () => _chip(c)),
                      ]),
                  ],
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: input,
                  onSubmitted: _send,
                  decoration: InputDecoration(
                    hintText: L('সহকারীকে লিখুন…', 'Message the assistant…'),
                    border: const OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(onPressed: () => _send(input.text), icon: const Icon(Icons.send)),
            ]),
          ),
        ]);
      },
    );
  }
}
