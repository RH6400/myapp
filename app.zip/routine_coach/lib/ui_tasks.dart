import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'i18n.dart';
import 'models.dart';
import 'state.dart';
import 'theme.dart';
import 'ui_common.dart';

class TasksTab extends StatefulWidget {
  const TasksTab({super.key});
  @override
  State<TasksTab> createState() => _TasksTabState();
}

class _TasksTabState extends State<TasksTab> {
  int filter = 0; // 0 সব, 1 প্রতিদিন, 2 নির্দিষ্ট দিন, 3 একদিন
  bool searching = false;
  final q = TextEditingController();

  @override
  void dispose() {
    q.dispose();
    super.dispose();
  }

  Future<void> _addWindow(BuildContext context) async {
    final s = await pickTime(context, 18 * 60);
    if (s == null || !context.mounted) return;
    final e = await pickTime(context, (s + 120) % (24 * 60));
    if (e == null || !context.mounted) return;
    if (e <= s) {
      snack(context, L('শেষের সময় শুরুর পরে হতে হবে', 'End time must be after start time'));
      return;
    }
    await app.setWindows([...app.windows, TimeWindow(s, e)]);
  }

  bool _match(TaskItem t) {
    if (filter == 1 && !(t.onDate == null && t.days.isEmpty)) return false;
    if (filter == 2 && !(t.onDate == null && t.days.isNotEmpty)) return false;
    if (filter == 3 && t.onDate == null) return false;
    final s = q.text.trim().toLowerCase();
    if (s.isNotEmpty && !t.title.toLowerCase().contains(s)) return false;
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final p = Pal.of(context);
        final list = app.tasks.where(_match).toList();
        return Scaffold(
          backgroundColor: Colors.transparent,
          floatingActionButton: FloatingActionButton(
            tooltip: L('নতুন কাজ', 'New task'),
            onPressed: () => showMailoSheet<void>(context, (_) => const AddTaskSheet()),
            child: const Icon(Icons.add, size: 28),
          ),
          body: ListView(
            padding: listPad(context, top: 0, bottom: 96),
            children: [
              ScreenHeader(
                L('আমার কাজ', 'My tasks'),
                actions: [
                  IconButton(
                    icon: Icon(searching ? Icons.close : Icons.search, color: p.tx),
                    onPressed: () => setState(() {
                      searching = !searching;
                      if (!searching) q.clear();
                    }),
                  ),
                ],
              ),
              if (searching)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: TextField(
                    controller: q,
                    autofocus: true,
                    onChanged: (_) => setState(() {}),
                    decoration: InputDecoration(
                      hintText: L('কাজ খুঁজুন…', 'Search tasks…'),
                      prefixIcon: const Icon(Icons.search),
                      filled: true,
                      fillColor: p.card,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: BorderSide(color: p.line),
                      ),
                    ),
                  ),
                ),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(children: [
                  for (final e in [
                    MapEntry(0, L('সব', 'All')),
                    MapEntry(1, L('প্রতিদিন', 'Daily')),
                    MapEntry(2, L('নির্দিষ্ট দিন', 'Specific days')),
                    MapEntry(3, L('একদিন', 'One day')),
                  ])
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(e.value),
                        selected: filter == e.key,
                        onSelected: (_) => setState(() => filter = e.key),
                      ),
                    ),
                ]),
              ),
              const SizedBox(height: 12),
              if (list.isEmpty)
                Padding(
                  padding: const EdgeInsets.all(28),
                  child: Text(
                    app.tasks.isEmpty
                        ? L('এখনো কোনো কাজ নেই। নিচের “+” বাটনে চাপুন।', 'No tasks yet. Tap “+” below.')
                        : L('এই ফিল্টারে কোনো কাজ নেই।', 'No tasks match this filter.'),
                    textAlign: TextAlign.center,
                    style: TextStyle(color: p.sub),
                  ),
                ),
              for (final t in list) _TaskCard(task: t),
              SectionTitle(L('ফ্রি সময়', 'Free time')),
              MCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(
                    L('অটো কাজগুলো এই সময়ের মধ্যে বসবে।', 'Auto tasks are placed inside these windows.'),
                    style: TextStyle(color: p.sub, fontSize: 12.5),
                  ),
                  const SizedBox(height: 10),
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    for (var i = 0; i < app.windows.length; i++)
                      InputChip(
                        label: Text('${fmtMin(app.windows[i].start)} – ${fmtMin(app.windows[i].end)}'),
                        onDeleted: app.windows.length > 1
                            ? () {
                                final l = [...app.windows]..removeAt(i);
                                app.setWindows(l);
                              }
                            : null,
                      ),
                    ActionChip(
                      avatar: Icon(Icons.add, size: 18, color: p.pri),
                      label: Text(L('সময় যোগ', 'Add time')),
                      onPressed: () => _addWindow(context),
                    ),
                  ]),
                ]),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _TaskCard extends StatelessWidget {
  final TaskItem task;
  const _TaskCard({required this.task});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final t = task;
    final kind = app.prefs.resolveAlert(t.alert);
    return MCard(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.fromLTRB(14, 11, 8, 11),
      onTap: () => showMailoSheet<void>(context, (_) => AddTaskSheet(task: t)),
      child: Row(children: [
        IconTile(alertIcon(kind), color: t.enabled ? p.pri : p.sub, bg: t.enabled ? p.priSoft : p.line),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t.title,
                style: TextStyle(
                    color: t.enabled ? p.tx : p.sub, fontSize: 14.5, fontWeight: FontWeight.w600)),
            const SizedBox(height: 2),
            Text('${whenLabel(t)} • ${t.minutes} ${L('মিনিট', 'min')}',
                style: TextStyle(color: p.sub, fontSize: 12)),
          ]),
        ),
        Switch(value: t.enabled, onChanged: (v) => app.setTaskEnabled(t.id, v)),
      ]),
    );
  }
}

/// নতুন কাজ যোগ বা পুরোনো কাজ বদলানোর শীট। "সেভ" বাটন নিচে আটকানো, নেভিগেশন বারের জায়গা ছেড়ে।
class AddTaskSheet extends StatefulWidget {
  final TaskItem? task;
  const AddTaskSheet({super.key, this.task});
  @override
  State<AddTaskSheet> createState() => _AddTaskSheetState();
}

class _AddTaskSheetState extends State<AddTaskSheet> {
  late final TextEditingController name = TextEditingController(text: widget.task?.title ?? '');
  late String category = widget.task?.category ??
      (app.prefs.categories.isNotEmpty ? app.prefs.categories.first : 'অন্যান্য');
  late double minutes = (widget.task?.minutes ?? 30).toDouble().clamp(5.0, 180.0).toDouble();
  late bool fixed = widget.task?.fixedMin != null;
  late int time = widget.task?.fixedMin ?? 6 * 60;
  late Set<int> days = {...?widget.task?.days};
  late int priority = widget.task?.priority ?? 2;
  late int part = widget.task?.part ?? 0;
  late String alert = widget.task?.alert ?? 'default';
  late String force = widget.task?.force ?? 'default';
  late bool oneDay = widget.task?.onDate != null;
  String? err;

  bool get editing => widget.task != null;

  @override
  void dispose() {
    name.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final title = name.text.trim();
    if (title.isEmpty) {
      setState(() => err = L('কাজের নাম লিখুন', 'Enter a task name'));
      return;
    }
    final now = DateTime.now();
    if (editing) {
      final t = widget.task!;
      t.title = title;
      t.category = category;
      t.minutes = minutes.round();
      t.priority = priority;
      t.part = fixed ? 0 : part;
      t.fixedMin = fixed ? time : null;
      t.days = oneDay ? <int>[] : days.toList();
      t.alert = alert;
      t.force = force;
      if (oneDay) {
        if (t.onDate == null) {
          var d = now;
          if (fixed && time <= now.hour * 60 + now.minute) d = DateTime(now.year, now.month, now.day + 1);
          t.onDate = dateKey(d);
        }
      } else {
        t.onDate = null;
      }
      await app.updateTask(t);
      if (mounted) Navigator.pop(context);
      return;
    }
    final item = TaskItem(
      id: now.microsecondsSinceEpoch.toString(),
      title: title,
      category: category,
      minutes: minutes.round(),
      priority: priority,
      part: fixed ? 0 : part,
      fixedMin: fixed ? time : null,
      days: days.toList(),
      alert: alert,
      force: force,
    );
    if (oneDay) {
      var d = now;
      if (fixed && time <= now.hour * 60 + now.minute) d = DateTime(now.year, now.month, now.day + 1);
      item.onDate = dateKey(d);
      item.days = [];
    }
    final r = await app.addTaskChecked(item);
    if (!mounted) return;
    if (r.ok) {
      Navigator.pop(context);
      return;
    }
    final names = r.conflicts.map((c) => '${c.title} (${fmtMin(c.startMin)})').join(', ');
    final choice = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(L('ওই সময়ে অন্য কাজ আছে', 'That time is already used')),
        content: Text('${fmtMin(time)}: $names'),
        actions: [
          if (r.suggestion != null)
            TextButton(
              onPressed: () => Navigator.pop(ctx, 'sug'),
              child: Text(L('${fmtMin(r.suggestion!)}-এ রাখুন', 'Use ${fmtMin(r.suggestion!)}')),
            ),
          TextButton(onPressed: () => Navigator.pop(ctx, 'force'), child: Text(L('তবুও রাখুন', 'Keep anyway'))),
          TextButton(onPressed: () => Navigator.pop(ctx, 'no'), child: Text(L('বাতিল', 'Cancel'))),
        ],
      ),
    );
    if (!mounted) return;
    if (choice == 'sug' && r.suggestion != null) {
      item.fixedMin = r.suggestion;
      await app.addTask(item);
      if (mounted) Navigator.pop(context);
    } else if (choice == 'force') {
      await app.addTask(item);
      if (mounted) Navigator.pop(context);
    }
  }

  Future<void> _delete() async {
    final ok = await confirm(context, L('কাজটা মুছবেন?', 'Delete this task?'),
        L('এই কাজের সব আগামী অ্যালার্ম বাদ যাবে।', 'All upcoming alarms for it will be removed.'),
        yes: L('মুছুন', 'Delete'));
    if (!ok || !mounted) return;
    await app.removeTask(widget.task!.id);
    if (mounted) Navigator.pop(context);
  }

  Widget _label(String s) => Padding(
        padding: const EdgeInsets.only(top: 14, bottom: 6),
        child: Text(s, style: TextStyle(color: Pal.of(context).sub, fontSize: 12.5, fontWeight: FontWeight.w600)),
      );

  Widget _alertCard(String k, Pal p) {
    final sel = alert == k;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => alert = k),
        child: Container(
          margin: const EdgeInsets.only(right: 6),
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 2),
          decoration: BoxDecoration(
            color: sel ? p.priSoft : p.card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: sel ? p.pri : p.line, width: sel ? 1.5 : 1),
          ),
          child: Column(children: [
            Icon(alertIcon(k), size: 20, color: sel ? p.pri : p.sub),
            const SizedBox(height: 3),
            Text(k == 'default' ? L('সাধারণ', 'Default') : alertShort(k),
                style: TextStyle(
                    fontSize: 12, color: sel ? p.pri : p.sub, fontWeight: sel ? FontWeight.w700 : FontWeight.w500)),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final mq = MediaQuery.of(context);
    final bottom = math.max(mq.viewInsets.bottom, mq.viewPadding.bottom);
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Flexible(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(18, 0, 18, 8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(
                child: Text(editing ? L('কাজ বদলান', 'Edit task') : L('নতুন কাজ', 'New task'),
                    style: TextStyle(color: p.tx, fontSize: 18, fontWeight: FontWeight.w700)),
              ),
              if (editing)
                IconButton(
                  tooltip: L('মুছুন', 'Delete'),
                  icon: Icon(Icons.delete_outline, color: p.bad),
                  onPressed: _delete,
                ),
            ]),
            const SizedBox(height: 6),
            TextField(
              controller: name,
              decoration: InputDecoration(
                labelText: L('কাজের নাম', 'Task name'),
                errorText: err,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
              ),
              onChanged: (_) {
                if (err != null) setState(() => err = null);
              },
            ),
            _label(L('ক্যাটাগরি', 'Category')),
            Wrap(spacing: 8, runSpacing: 4, children: [
              for (final c in app.prefs.categories)
                ChoiceChip(label: Text(c), selected: category == c, onSelected: (_) => setState(() => category = c)),
            ]),
            _label('${L('সময়কাল', 'Duration')}: ${minutes.round()} ${L('মিনিট', 'min')}'),
            Slider(
              value: minutes,
              min: 5,
              max: 180,
              divisions: 35,
              onChanged: (v) => setState(() => minutes = v),
            ),
            _label(L('কখন করবেন', 'When')),
            SegmentedButton<bool>(
              segments: [
                ButtonSegment(value: false, label: Text(L('ফ্রি সময়ে অটো', 'Auto in free time'))),
                ButtonSegment(value: true, label: Text(L('নির্দিষ্ট সময়', 'Fixed time'))),
              ],
              selected: {fixed},
              onSelectionChanged: (s) => setState(() => fixed = s.first),
            ),
            if (fixed) ...[
              const SizedBox(height: 8),
              OutlinedButton.icon(
                icon: const Icon(Icons.schedule),
                label: Text(fmtMin(time)),
                onPressed: () async {
                  final m = await pickTime(context, time);
                  if (m != null) setState(() => time = m);
                },
              ),
            ] else ...[
              _label(L('পছন্দের সময়', 'Preferred part of day')),
              Wrap(spacing: 8, children: [
                for (final x in [0, 1, 2, 3])
                  ChoiceChip(label: Text(partLabel(x)), selected: part == x, onSelected: (_) => setState(() => part = x)),
              ]),
            ],
            _label(L('কোন কোন দিন (কিছু না বাছলে প্রতিদিন)', 'Which days (none = every day)')),
            Wrap(spacing: 6, runSpacing: 4, children: [
              for (var d = 1; d <= 7; d++)
                FilterChip(
                  label: Text(weekdayName(d)),
                  selected: days.contains(d) && !oneDay,
                  onSelected: oneDay ? null : (v) => setState(() => v ? days.add(d) : days.remove(d)),
                ),
            ]),
            Row(children: [
              Expanded(child: Text(L('শুধু একদিনের কাজ', 'One day only'), style: TextStyle(color: p.tx))),
              Switch(value: oneDay, onChanged: (v) => setState(() => oneDay = v)),
            ]),
            _label(L('অগ্রাধিকার', 'Priority')),
            SegmentedButton<int>(
              segments: [
                ButtonSegment(value: 1, label: Text(L('কম', 'Low'))),
                ButtonSegment(value: 2, label: Text(L('মাঝারি', 'Medium'))),
                ButtonSegment(value: 3, label: Text(L('উচ্চ', 'High'))),
              ],
              selected: {priority},
              onSelectionChanged: (s) => setState(() => priority = s.first),
            ),
            _label(L('কীভাবে মনে করাবে', 'How to alert you')),
            Row(children: [for (final k in alertKinds) _alertCard(k, p)]),
            if (alertHint(alert).isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(alertHint(alert), style: TextStyle(fontSize: 12, color: p.sub)),
              ),
            _label(L('কতটা কড়াকড়ি', 'How strict')),
            Wrap(spacing: 8, runSpacing: 4, children: [
              for (final k in forceKinds)
                ChoiceChip(label: Text(forceLabel(k)), selected: force == k, onSelected: (_) => setState(() => force = k)),
            ]),
            if (forceHint(force).isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(forceHint(force), style: TextStyle(fontSize: 12, color: p.sub)),
              ),
            const SizedBox(height: 8),
          ]),
        ),
      ),
      Padding(
        padding: EdgeInsets.fromLTRB(18, 8, 18, 12 + bottom),
        child: SizedBox(
          width: double.infinity,
          child: FilledButton(
            onPressed: _save,
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Text(editing ? L('সেভ করুন', 'Save') : L('যোগ করুন', 'Add'), style: const TextStyle(fontSize: 15)),
            ),
          ),
        ),
      ),
    ]);
  }
}
