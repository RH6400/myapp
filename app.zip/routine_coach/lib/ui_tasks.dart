import 'package:flutter/material.dart';
import 'i18n.dart';
import 'mailo_widgets.dart';
import 'models.dart';
import 'state.dart';
import 'ui_common.dart';

void showAddTask(BuildContext context) => showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => const AddTaskSheet(),
    );

class TasksTab extends StatefulWidget {
  const TasksTab({super.key});
  @override
  State<TasksTab> createState() => _TasksTabState();
}

class _TasksTabState extends State<TasksTab> {
  int filter = 0; // 0 সব, 1 প্রতিদিন, 2 নির্দিষ্ট দিন, 3 একদিন
  bool searching = false;
  String q = '';

  Future<void> _addWindow(BuildContext context) async {
    final s = await pickTime(context, 18 * 60);
    if (s == null || !context.mounted) return;
    final e = await pickTime(context, (s + 120) % (24 * 60));
    if (e == null || !context.mounted) return;
    if (e <= s) {
      snack(context, L('শেষের সময় শুরুর পরে হতে হবে', 'End time must be after start time'));
      return;
    }
    await app.setWindows([...app.windows, TimeWindow(s, e)]);
  }

  bool _match(TaskItem t) {
    if (q.trim().isNotEmpty && !t.title.toLowerCase().contains(q.trim().toLowerCase())) return false;
    switch (filter) {
      case 1:
        return t.onDate == null && t.days.isEmpty;
      case 2:
        return t.onDate == null && t.days.isNotEmpty;
      case 3:
        return t.onDate != null;
      default:
        return true;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final cs = Theme.of(context).colorScheme;
        final shown = app.tasks.where(_match).toList();
        final filters = [
          L('সব', 'All'),
          L('প্রতিদিন', 'Daily'),
          L('নির্দিষ্ট দিন', 'Set days'),
          L('একদিন', 'One day'),
        ];
        return Scaffold(
          backgroundColor: Colors.transparent,
          floatingActionButton: FloatingActionButton(
            onPressed: () => showAddTask(context),
            child: const Icon(Icons.add, size: 28),
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 110),
            children: [
              TabHeader(
                title: L('আমার কাজ', 'My tasks'),
                actions: [
                  IconButton(
                    onPressed: () => setState(() {
                      searching = !searching;
                      if (!searching) q = '';
                    }),
                    icon: Icon(searching ? Icons.close : Icons.search, color: cs.onSurface),
                  ),
                ],
              ),
              if (searching)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: TextField(
                    autofocus: true,
                    onChanged: (v) => setState(() => q = v),
                    decoration: InputDecoration(
                      hintText: L('কাজ খুঁজুন…', 'Search tasks…'),
                      prefixIcon: const Icon(Icons.search),
                      filled: true,
                      fillColor: cs.surfaceContainerLow,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none),
                    ),
                  ),
                ),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(children: [
                  for (var i = 0; i < filters.length; i++)
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(filters[i]),
                        selected: filter == i,
                        onSelected: (_) => setState(() => filter = i),
                        showCheckmark: false,
                        selectedColor: cs.primaryContainer,
                        labelStyle: TextStyle(
                          color: filter == i ? cs.primary : cs.onSurfaceVariant,
                          fontWeight: filter == i ? FontWeight.w700 : FontWeight.w500,
                        ),
                      ),
                    ),
                ]),
              ),
              const SizedBox(height: 14),
              if (shown.isEmpty)
                Padding(
                  padding: const EdgeInsets.all(28),
                  child: Text(
                    L('কোনো কাজ নেই। + চেপে নতুন কাজ যোগ করুন।', 'No tasks yet. Tap + to add one.'),
                    textAlign: TextAlign.center,
                    style: TextStyle(color: cs.onSurfaceVariant),
                  ),
                ),
              for (final t in shown)
                Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.fromLTRB(14, 12, 6, 12),
                  decoration: BoxDecoration(
                    color: cs.surfaceContainerLow,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: cs.outlineVariant),
                  ),
                  child: Row(children: [
                    Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(color: cs.primaryContainer, borderRadius: BorderRadius.circular(14)),
                      child: Icon(t.fixedMin != null ? Icons.alarm : Icons.notifications_none, color: cs.primary),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Opacity(
                        opacity: t.enabled ? 1 : 0.55,
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(t.title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                          const SizedBox(height: 2),
                          Text(nd(whenLabel(t)), style: TextStyle(color: cs.onSurfaceVariant, fontSize: 13)),
                          Text('${nd(t.minutes)} ${L('মিনিট', 'min')} • ${t.category}',
                              style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
                        ]),
                      ),
                    ),
                    Switch(value: t.enabled, onChanged: (v) => app.setTaskEnabled(t, v)),
                    PopupMenuButton<String>(
                      icon: Icon(Icons.more_vert, color: cs.onSurfaceVariant, size: 20),
                      padding: EdgeInsets.zero,
                      onSelected: (v) async {
                        if (v == 'delete') {
                          final ok = await confirm(
                            context,
                            L('কাজ মুছবেন?', 'Delete task?'),
                            t.title,
                          );
                          if (ok) await app.removeTask(t.id);
                        }
                      },
                      itemBuilder: (_) => [
                        PopupMenuItem(value: 'delete', child: Text(L('মুছুন', 'Delete'))),
                      ],
                    ),
                  ]),
                ),
              const SizedBox(height: 14),
              Text(L('ফ্রি সময়', 'Free time'),
                  style: TextStyle(color: cs.primary, fontWeight: FontWeight.w800, fontSize: 14)),
              const SizedBox(height: 4),
              Text(
                L('অটো কাজগুলো এই সময়ের মধ্যে বসবে।', 'Auto tasks are placed inside these windows.'),
                style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: cs.surfaceContainerLow,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: cs.outlineVariant),
                ),
                child: Wrap(spacing: 8, runSpacing: 8, children: [
                  for (var i = 0; i < app.windows.length; i++)
                    InputChip(
                      label: Text(nd('${fmtMin(app.windows[i].start)} – ${fmtMin(app.windows[i].end)}')),
                      onDeleted: app.windows.length > 1
                          ? () {
                              final l = [...app.windows]..removeAt(i);
                              app.setWindows(l);
                            }
                          : null,
                    ),
                  ActionChip(
                    avatar: const Icon(Icons.add, size: 18),
                    label: Text(L('সময় যোগ', 'Add time')),
                    onPressed: () => _addWindow(context),
                  ),
                ]),
              ),
            ],
          ),
        );
      },
    );
  }
}

class AddTaskSheet extends StatefulWidget {
  const AddTaskSheet({super.key});
  @override
  State<AddTaskSheet> createState() => _AddTaskSheetState();
}

class _AddTaskSheetState extends State<AddTaskSheet> {
  final name = TextEditingController();
  late String category = app.prefs.categories.isNotEmpty ? app.prefs.categories.first : 'অন্যান্য';
  double minutes = 30;
  bool fixed = false;
  int time = 6 * 60;
  Set<int> days = {};
  int priority = 2;
  int part = 0;
  String alert = 'default';
  String force = 'default';
  bool oneDay = false;
  String? err;

  @override
  void dispose() {
    name.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final title = name.text.trim();
    if (title.isEmpty) {
      setState(() => err = L('কাজের নাম লিখুন', 'Enter a task name'));
      return;
    }
    final now = DateTime.now();
    final item = TaskItem(
      id: now.microsecondsSinceEpoch.toString(),
      title: title,
      category: category,
      minutes: minutes.round(),
      priority: priority,
      part: fixed ? 0 : part,
      fixedMin: fixed ? time : null,
      days: days.toList(),
      alert: alert,
      force: force,
    );
    if (oneDay) {
      var d = now;
      if (fixed && time <= now.hour * 60 + now.minute) d = DateTime(now.year, now.month, now.day + 1);
      item.onDate = dateKey(d);
      item.days = [];
    }
    final r = await app.addTaskChecked(item);
    if (!mounted) return;
    if (r.ok) {
      Navigator.pop(context);
      return;
    }
    final names = r.conflicts.map((c) => '${c.title} (${fmtMin(c.startMin)})').join(', ');
    final choice = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(L('ওই সময়ে অন্য কাজ আছে', 'That time is already used')),
        content: Text('${fmtMin(time)}: $names'),
        actions: [
          if (r.suggestion != null)
            TextButton(
              onPressed: () => Navigator.pop(ctx, 'sug'),
              child: Text(L('${fmtMin(r.suggestion!)}-এ রাখুন', 'Use ${fmtMin(r.suggestion!)}')),
            ),
          TextButton(onPressed: () => Navigator.pop(ctx, 'force'), child: Text(L('তবুও রাখুন', 'Keep anyway'))),
          TextButton(onPressed: () => Navigator.pop(ctx, 'no'), child: Text(L('বাতিল', 'Cancel'))),
        ],
      ),
    );
    if (!mounted) return;
    if (choice == 'sug' && r.suggestion != null) {
      item.fixedMin = r.suggestion;
      await app.addTask(item);
      if (mounted) Navigator.pop(context);
    } else if (choice == 'force') {
      await app.addTask(item);
      if (mounted) Navigator.pop(context);
    }
  }

  Widget _label(String s) => Padding(
        padding: const EdgeInsets.only(top: 14, bottom: 6),
        child: Text(s, style: Theme.of(context).textTheme.labelLarge),
      );

  @override
  Widget build(BuildContext context) {
    final kinds = alertKinds;
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(L('নতুন কাজ', 'New task'), style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          TextField(
            controller: name,
            decoration: InputDecoration(labelText: L('কাজের নাম', 'Task name'), errorText: err),
            onChanged: (_) {
              if (err != null) setState(() => err = null);
            },
          ),
          _label(L('ক্যাটাগরি', 'Category')),
          Wrap(spacing: 8, runSpacing: 4, children: [
            for (final c in app.prefs.categories)
              ChoiceChip(label: Text(c), selected: category == c, onSelected: (_) => setState(() => category = c)),
          ]),
          _label('${L('সময়কাল', 'Duration')}: ${minutes.round()} ${L('মিনিট', 'min')}'),
          Slider(
            value: minutes,
            min: 5,
            max: 180,
            divisions: 35,
            onChanged: (v) => setState(() => minutes = v),
          ),
          _label(L('কখন করবেন', 'When')),
          SegmentedButton<bool>(
            segments: [
              ButtonSegment(value: false, label: Text(L('ফ্রি সময়ে অটো', 'Auto in free time'))),
              ButtonSegment(value: true, label: Text(L('নির্দিষ্ট সময়', 'Fixed time'))),
            ],
            selected: {fixed},
            onSelectionChanged: (s) => setState(() => fixed = s.first),
          ),
          if (fixed) ...[
            const SizedBox(height: 8),
            OutlinedButton.icon(
              icon: const Icon(Icons.schedule),
              label: Text(fmtMin(time)),
              onPressed: () async {
                final m = await pickTime(context, time);
                if (m != null) setState(() => time = m);
              },
            ),
          ] else ...[
            _label(L('পছন্দের সময়', 'Preferred part of day')),
            Wrap(spacing: 8, children: [
              for (final p in [0, 1, 2, 3])
                ChoiceChip(label: Text(partLabel(p)), selected: part == p, onSelected: (_) => setState(() => part = p)),
            ]),
          ],
          _label(L('কোন কোন দিন (কিছু না বাছলে প্রতিদিন)', 'Which days (none = every day)')),
          Wrap(spacing: 6, runSpacing: 4, children: [
            for (var d = 1; d <= 7; d++)
              FilterChip(
                label: Text(weekdayName(d)),
                selected: days.contains(d) && !oneDay,
                onSelected: oneDay
                    ? null
                    : (v) => setState(() => v ? days.add(d) : days.remove(d)),
              ),
          ]),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(L('শুধু একদিনের কাজ', 'One day only')),
            value: oneDay,
            onChanged: (v) => setState(() => oneDay = v),
          ),
          _label(L('অগ্রাধিকার', 'Priority')),
          SegmentedButton<int>(
            segments: [
              ButtonSegment(value: 1, label: Text(L('কম', 'Low'))),
              ButtonSegment(value: 2, label: Text(L('মাঝারি', 'Medium'))),
              ButtonSegment(value: 3, label: Text(L('উচ্চ', 'High'))),
            ],
            selected: {priority},
            onSelectionChanged: (s) => setState(() => priority = s.first),
          ),
          _label(L('কীভাবে মনে করাবে', 'How to alert you')),
          Wrap(spacing: 8, runSpacing: 4, children: [
            for (final k in kinds)
              ChoiceChip(
                avatar: Icon(alertIcon(k), size: 16),
                label: Text(k == 'default' ? '${alertLabel(k)} (${alertLabel(app.prefs.alert)})' : alertLabel(k)),
                selected: alert == k,
                onSelected: (_) => setState(() => alert = k),
              ),
          ]),
          if (alertHint(alert).isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(alertHint(alert), style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
            ),
          _label(L('কতটা কড়াকড়ি', 'How strict')),
          Wrap(spacing: 8, runSpacing: 4, children: [
            for (final k in forceKinds)
              ChoiceChip(label: Text(forceLabel(k)), selected: force == k, onSelected: (_) => setState(() => force = k)),
          ]),
          if (forceHint(force).isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(forceHint(force), style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
            ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: _save,
              child: Padding(padding: const EdgeInsets.all(10), child: Text(L('যোগ করুন', 'Add'))),
            ),
          ),
        ]),
      ),
    );
  }
}
