import 'package:flutter/material.dart';
import 'models.dart';
import 'planner.dart';
import 'state.dart';

class TasksTab extends StatelessWidget {
  const TasksTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        return Scaffold(
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => _addTask(context),
            icon: const Icon(Icons.add),
            label: const Text('নতুন কাজ'),
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
            children: [
              Text('আমার ফ্রি সময়', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              Wrap(spacing: 8, children: [
                for (var i = 0; i < app.windows.length; i++)
                  InputChip(
                    label: Text('${fmtMin(app.windows[i].start)} – ${fmtMin(app.windows[i].end)}'),
                    onDeleted: app.windows.length > 1
                        ? () => app.setWindows([...app.windows]..removeAt(i))
                        : null,
                  ),
                ActionChip(
                  avatar: const Icon(Icons.add, size: 18),
                  label: const Text('সময় যোগ'),
                  onPressed: () => _addWindow(context),
                ),
              ]),
              const SizedBox(height: 24),
              Text('আমার কাজ (${app.tasks.length})',
                  style: Theme.of(context).textTheme.titleMedium),
              for (final t in app.tasks)
                Card(
                  child: ListTile(
                    title: Text(t.title),
                    subtitle: Text('${t.minutes} মিনিট • ${t.category} • ${'⭐' * t.priority}'
                        ' • ${partNames[t.part]}'),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () => app.removeTask(t.id),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _addWindow(BuildContext context) async {
    final s = await showTimePicker(
        context: context,
        helpText: 'শুরুর সময়',
        initialTime: const TimeOfDay(hour: 18, minute: 0));
    if (s == null || !context.mounted) return;
    final e = await showTimePicker(
        context: context,
        helpText: 'শেষের সময়',
        initialTime: TimeOfDay(hour: (s.hour + 2) % 24, minute: s.minute));
    if (e == null) return;
    final a = s.hour * 60 + s.minute;
    final b = e.hour * 60 + e.minute;
    if (b <= a) return; // মধ্যরাত পার করা জানালা ডেমোতে নেই
    app.setWindows([...app.windows, TimeWindow(a, b)]);
  }

  Future<void> _addTask(BuildContext context) async {
    final title = TextEditingController();
    var cat = categories.first;
    var minutes = 30.0;
    var prio = 2;
    var part = 0;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (c) => StatefulBuilder(
        builder: (c, setS) => Padding(
          padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(c).viewInsets.bottom + 16),
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              TextField(
                controller: title,
                decoration: const InputDecoration(labelText: 'কাজের নাম'),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: cat,
                decoration: const InputDecoration(labelText: 'ক্যাটাগরি'),
                items: [for (final x in categories) DropdownMenuItem(value: x, child: Text(x))],
                onChanged: (v) => setS(() => cat = v ?? cat),
              ),
              const SizedBox(height: 12),
              Text('সময়: ${minutes.round()} মিনিট'),
              Slider(
                value: minutes,
                min: 5,
                max: 180,
                divisions: 35,
                onChanged: (v) => setS(() => minutes = v),
              ),
              const Text('অগ্রাধিকার'),
              SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 1, label: Text('কম')),
                  ButtonSegment(value: 2, label: Text('মাঝারি')),
                  ButtonSegment(value: 3, label: Text('উচ্চ')),
                ],
                selected: {prio},
                onSelectionChanged: (s) => setS(() => prio = s.first),
              ),
              const SizedBox(height: 12),
              const Text('পছন্দের সময়'),
              Wrap(spacing: 8, children: [
                for (final e in partNames.entries)
                  ChoiceChip(
                    label: Text(e.value),
                    selected: part == e.key,
                    onSelected: (_) => setS(() => part = e.key),
                  ),
              ]),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () {
                    if (title.text.trim().isEmpty) return;
                    app.addTask(TaskItem(
                      id: DateTime.now().microsecondsSinceEpoch.toString(),
                      title: title.text.trim(),
                      category: cat,
                      minutes: minutes.round(),
                      priority: prio,
                      part: part,
                    ));
                    Navigator.pop(c);
                  },
                  child: const Text('যোগ করুন'),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
