import 'package:flutter/material.dart';
import 'i18n.dart';
import 'models.dart';
import 'state.dart';
import 'ui_common.dart';

class TasksTab extends StatelessWidget {
  const TasksTab({super.key});

  Future<void> _addWindow(BuildContext context) async {
    final s = await pickTime(context, 18 * 60);
    if (s == null || !context.mounted) return;
    final e = await pickTime(context, (s + 120) % (24 * 60));
    if (e == null || !context.mounted) return;
    if (e <= s) {
      snack(context, L('শেষের সময় শুরুর পরে হতে হবে', 'End time must be after start time'));
      return;
    }
    await app.setWindows([...app.windows, TimeWindow(s, e)]);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final cs = Theme.of(context).colorScheme;
        return Scaffold(
          backgroundColor: Colors.transparent,
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => showModalBottomSheet<void>(
              context: context,
              isScrollControlled: true,
              showDragHandle: true,
              builder: (_) => const AddTaskSheet(),
            ),
            icon: const Icon(Icons.add),
            label: Text(L('নতুন কাজ', 'New task')),
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
            children: [
              Text(L('আমার ফ্রি সময়', 'My free time'), style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 4),
              Text(
                L('অটো কাজগুলো এই সময়ের মধ্যে বসবে।', 'Auto tasks are placed inside these windows.'),
                style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12),
              ),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (var i = 0; i < app.windows.length; i++)
                  InputChip(
                    label: Text('${fmtMin(app.windows[i].start)} – ${fmtMin(app.windows[i].end)}'),
                    onDeleted: app.windows.length > 1
                        ? () {
                            final l = [...app.windows]..removeAt(i);
                            app.setWindows(l);
                          }
                        : null,
                  ),
                ActionChip(
                  avatar: const Icon(Icons.add, size: 18),
                  label: Text(L('সময় যোগ', 'Add time')),
                  onPressed: () => _addWindow(context),
                ),
              ]),
              const SizedBox(height: 20),
              Text('${L('আমার কাজ', 'My tasks')} (${app.tasks.length})',
                  style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              for (final t in app.tasks)
                Card(
                  child: ListTile(
                    title: Text(t.title),
                    subtitle: Text(
                      '${t.minutes} ${L('মিনিট', 'min')} • ${t.category} • ${'★' * t.priority}\n${whenLabel(t)}',
                    ),
                    isThreeLine: true,
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(alertIcon(app.prefs.resolveAlert(t.alert)), size: 18),
                      IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () => app.removeTask(t.id),
                      ),
                    ]),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class AddTaskSheet extends StatefulWidget {
  const AddTaskSheet({super.key});
  @override
  State<AddTaskSheet> createState() => _AddTaskSheetState();
}

class _AddTaskSheetState extends State<AddTaskSheet> {
  final name = TextEditingController();
  late String category = app.prefs.categories.isNotEmpty ? app.prefs.categories.first : 'অন্যান্য';
  double minutes = 30;
  bool fixed = false;
  int time = 6 * 60;
  Set<int> days = {};
  int priority = 2;
  int part = 0;
  String alert = 'default';
  String force = 'default';
  bool oneDay = false;
  String? err;

  @override
  void dispose() {
    name.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final title = name.text.trim();
    if (title.isEmpty) {
      setState(() => err = L('কাজের নাম লিখুন', 'Enter a task name'));
      return;
    }
    final now = DateTime.now();
    final item = TaskItem(
      id: now.microsecondsSinceEpoch.toString(),
      title: title,
      category: category,
      minutes: minutes.round(),
      priority: priority,
      part: fixed ? 0 : part,
      fixedMin: fixed ? time : null,
      days: days.toList(),
      alert: alert,
      force: force,
    );
    if (oneDay) {
      var d = now;
      if (fixed && time <= now.hour * 60 + now.minute) d = DateTime(now.year, now.month, now.day + 1);
      item.onDate = dateKey(d);
      item.days = [];
    }
    final r = await app.addTaskChecked(item);
    if (!mounted) return;
    if (r.ok) {
      Navigator.pop(context);
      return;
    }
    final names = r.conflicts.map((c) => '${c.title} (${fmtMin(c.startMin)})').join(', ');
    final choice = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(L('ওই সময়ে অন্য কাজ আছে', 'That time is already used')),
        content: Text('${fmtMin(time)}: $names'),
        actions: [
          if (r.suggestion != null)
            TextButton(
              onPressed: () => Navigator.pop(ctx, 'sug'),
              child: Text(L('${fmtMin(r.suggestion!)}-এ রাখুন', 'Use ${fmtMin(r.suggestion!)}')),
            ),
          TextButton(onPressed: () => Navigator.pop(ctx, 'force'), child: Text(L('তবুও রাখুন', 'Keep anyway'))),
          TextButton(onPressed: () => Navigator.pop(ctx, 'no'), child: Text(L('বাতিল', 'Cancel'))),
        ],
      ),
    );
    if (!mounted) return;
    if (choice == 'sug' && r.suggestion != null) {
      item.fixedMin = r.suggestion;
      await app.addTask(item);
      if (mounted) Navigator.pop(context);
    } else if (choice == 'force') {
      await app.addTask(item);
      if (mounted) Navigator.pop(context);
    }
  }

  Widget _label(String s) => Padding(
        padding: const EdgeInsets.only(top: 14, bottom: 6),
        child: Text(s, style: Theme.of(context).textTheme.labelLarge),
      );

  @override
  Widget build(BuildContext context) {
    final kinds = alertKinds;
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(L('নতুন কাজ', 'New task'), style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          TextField(
            controller: name,
            decoration: InputDecoration(labelText: L('কাজের নাম', 'Task name'), errorText: err),
            onChanged: (_) {
              if (err != null) setState(() => err = null);
            },
          ),
          _label(L('ক্যাটাগরি', 'Category')),
          Wrap(spacing: 8, runSpacing: 4, children: [
            for (final c in app.prefs.categories)
              ChoiceChip(label: Text(c), selected: category == c, onSelected: (_) => setState(() => category = c)),
          ]),
          _label('${L('সময়কাল', 'Duration')}: ${minutes.round()} ${L('মিনিট', 'min')}'),
          Slider(
            value: minutes,
            min: 5,
            max: 180,
            divisions: 35,
            onChanged: (v) => setState(() => minutes = v),
          ),
          _label(L('কখন করবেন', 'When')),
          SegmentedButton<bool>(
            segments: [
              ButtonSegment(value: false, label: Text(L('ফ্রি সময়ে অটো', 'Auto in free time'))),
              ButtonSegment(value: true, label: Text(L('নির্দিষ্ট সময়', 'Fixed time'))),
            ],
            selected: {fixed},
            onSelectionChanged: (s) => setState(() => fixed = s.first),
          ),
          if (fixed) ...[
            const SizedBox(height: 8),
            OutlinedButton.icon(
              icon: const Icon(Icons.schedule),
              label: Text(fmtMin(time)),
              onPressed: () async {
                final m = await pickTime(context, time);
                if (m != null) setState(() => time = m);
              },
            ),
          ] else ...[
            _label(L('পছন্দের সময়', 'Preferred part of day')),
            Wrap(spacing: 8, children: [
              for (final p in [0, 1, 2, 3])
                ChoiceChip(label: Text(partLabel(p)), selected: part == p, onSelected: (_) => setState(() => part = p)),
            ]),
          ],
          _label(L('কোন কোন দিন (কিছু না বাছলে প্রতিদিন)', 'Which days (none = every day)')),
          Wrap(spacing: 6, runSpacing: 4, children: [
            for (var d = 1; d <= 7; d++)
              FilterChip(
                label: Text(weekdayName(d)),
                selected: days.contains(d) && !oneDay,
                onSelected: oneDay
                    ? null
                    : (v) => setState(() => v ? days.add(d) : days.remove(d)),
              ),
          ]),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(L('শুধু একদিনের কাজ', 'One day only')),
            value: oneDay,
            onChanged: (v) => setState(() => oneDay = v),
          ),
          _label(L('অগ্রাধিকার', 'Priority')),
          SegmentedButton<int>(
            segments: [
              ButtonSegment(value: 1, label: Text(L('কম', 'Low'))),
              ButtonSegment(value: 2, label: Text(L('মাঝারি', 'Medium'))),
              ButtonSegment(value: 3, label: Text(L('উচ্চ', 'High'))),
            ],
            selected: {priority},
            onSelectionChanged: (s) => setState(() => priority = s.first),
          ),
          _label(L('কীভাবে মনে করাবে', 'How to alert you')),
          Wrap(spacing: 8, runSpacing: 4, children: [
            for (final k in kinds)
              ChoiceChip(
                avatar: Icon(alertIcon(k), size: 16),
                label: Text(k == 'default' ? '${alertLabel(k)} (${alertLabel(app.prefs.alert)})' : alertLabel(k)),
                selected: alert == k,
                onSelected: (_) => setState(() => alert = k),
              ),
          ]),
          if (alertHint(alert).isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(alertHint(alert), style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
            ),
          _label(L('কতটা কড়াকড়ি', 'How strict')),
          Wrap(spacing: 8, runSpacing: 4, children: [
            for (final k in forceKinds)
              ChoiceChip(label: Text(forceLabel(k)), selected: force == k, onSelected: (_) => setState(() => force = k)),
          ]),
          if (forceHint(force).isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(forceHint(force), style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
            ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: _save,
              child: Padding(padding: const EdgeInsets.all(10), child: Text(L('যোগ করুন', 'Add'))),
            ),
          ),
        ]),
      ),
    );
  }
}
