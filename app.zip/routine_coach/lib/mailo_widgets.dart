import 'package:flutter/material.dart';
import 'i18n.dart';
import 'ui_settings.dart';

/// অ্যাপের লোগো (M চিহ্ন)।
class MailoLogo extends StatelessWidget {
  final double height;
  const MailoLogo({super.key, this.height = 32});
  @override
  Widget build(BuildContext context) =>
      Image.asset('assets/mailo_logo.png', height: height, filterQuality: FilterQuality.medium);
}

enum MailoPose {
  still, // স্থির (ছোট জায়গা: ট্যাব আইকন, কার্ড, নোটিফিকেশন)
  attention, // লাফ + চোখ মিটমিট, ৪ সেকেন্ড (অ্যালার্ম স্ক্রিন, উদযাপন)
  idle, // ১০ সেকেন্ড: চারপাশে তাকানো, মিটমিট, লাফ, ঝিমানো (সহকারী স্ক্রিন)
}

/// AI সহকারীর আইকন (চোখওয়ালা M মাসকট)। AI যেখানেই আসবে, এটাই বসবে।
class MailoAi extends StatelessWidget {
  final double width;
  final MailoPose pose;
  const MailoAi({super.key, this.width = 40, this.pose = MailoPose.still});
  @override
  Widget build(BuildContext context) {
    final path = switch (pose) {
      MailoPose.still => 'assets/mailo_ai_still.png',
      MailoPose.attention => 'assets/mailo_ai.webp',
      MailoPose.idle => 'assets/mailo_ai_idle.webp',
    };
    return Image.asset(path, width: width, gaplessPlayback: true, filterQuality: FilterQuality.medium);
  }
}

/// গোল ব্যাজের ভেতর মাসকট (চ্যাট হেডার, কার্ড ইত্যাদির জন্য)।
class MailoAiBadge extends StatelessWidget {
  final double size;
  const MailoAiBadge({super.key, this.size = 44});
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      width: size,
      height: size,
      padding: EdgeInsets.all(size * 0.16),
      decoration: BoxDecoration(
        color: cs.surfaceContainerLow,
        borderRadius: BorderRadius.circular(size * 0.32),
        border: Border.all(color: cs.outlineVariant),
      ),
      child: Image.asset('assets/mailo_ai_still.png', fit: BoxFit.contain),
    );
  }
}

void openSettings(BuildContext c) =>
    Navigator.of(c).push(MaterialPageRoute<void>(builder: (_) => const SettingsScreen()));

/// প্রতিটা ট্যাবের উপরের শিরোনাম।
class TabHeader extends StatelessWidget {
  final String title;
  final Widget? leading;
  final List<Widget> actions;
  final bool settings;
  const TabHeader({super.key, required this.title, this.leading, this.actions = const [], this.settings = true});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 12, 6),
      child: Row(children: [
        if (leading != null) ...[leading!, const SizedBox(width: 12)],
        Expanded(
          child: Text(title,
              style: Theme.of(context)
                  .textTheme
                  .headlineSmall
                  ?.copyWith(fontWeight: FontWeight.w800, color: cs.onSurface)),
        ),
        ...actions,
        if (settings)
          IconButton(
            tooltip: L('সেটিংস', 'Settings'),
            onPressed: () => openSettings(context),
            icon: Icon(Icons.settings_outlined, color: cs.onSurfaceVariant),
          ),
      ]),
    );
  }
}

String dayFull(int weekday) {
  const bn = ['সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার', 'রবিবার'];
  const en = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  return (gLang == 'en' ? en : bn)[(weekday - 1) % 7];
}

String monthName(int m) {
  const bn = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
  const en = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  return (gLang == 'en' ? en : bn)[(m - 1) % 12];
}

String greetingFor(DateTime now) {
  final h = now.hour;
  if (h >= 5 && h < 12) return L('শুভ সকাল', 'Good morning');
  if (h >= 12 && h < 15) return L('শুভ দুপুর', 'Good afternoon');
  if (h >= 15 && h < 18) return L('শুভ বিকেল', 'Good afternoon');
  if (h >= 18 && h < 21) return L('শুভ সন্ধ্যা', 'Good evening');
  return L('শুভ রাত্রি', 'Good night');
}
