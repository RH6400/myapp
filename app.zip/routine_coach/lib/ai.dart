import 'dart:convert';
import 'package:http/http.dart' as http;
import 'state.dart';

/// AI-র সংযোগ একটাই জায়গায়, যাতে পরে নিজের সার্ভারে সরানো সহজ হয়।
/// এখন: ইউজারের নিজের Gemini কী দিয়ে সরাসরি। পরে: নিজের সার্ভার (লগইন টোকেনসহ)।
class AiResult {
  final String? text;
  final int? status; // HTTP কোড, ব্যর্থ হলে
  final bool netError;
  const AiResult({this.text, this.status, this.netError = false});
  bool get ok => text != null;
}

abstract class AiClient {
  bool get available;
  String get label;
  Future<AiResult> askJson(String prompt);
}

class GeminiDirect implements AiClient {
  @override
  bool get available => app.prefs.geminiKey.isNotEmpty;

  @override
  String get label => 'AI (${app.prefs.geminiModel})';

  @override
  Future<AiResult> askJson(String prompt) async {
    try {
      final uri = Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/'
          '${app.prefs.geminiModel}:generateContent?key=${app.prefs.geminiKey}');
      final resp = await http
          .post(uri,
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({
                'contents': [
                  {
                    'role': 'user',
                    'parts': [
                      {'text': prompt}
                    ]
                  }
                ],
                'generationConfig': {'responseMimeType': 'application/json', 'temperature': 0.4},
              }))
          .timeout(const Duration(seconds: 30));
      if (resp.statusCode != 200) return AiResult(status: resp.statusCode);
      final j = jsonDecode(utf8.decode(resp.bodyBytes));
      final raw = (j['candidates'][0]['content']['parts'][0]['text'] as String).trim();
      return AiResult(text: raw);
    } catch (_) {
      return const AiResult(netError: true);
    }
  }
}

/// অ্যাপের সব জায়গা এটাই ব্যবহার করবে। সার্ভার তৈরি হলে এখানে বদলে দিলেই হবে।
AiClient aiClient = GeminiDirect();
