import 'dart:async';
import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'firebase_config.dart';
import 'i18n.dart';
import 'state.dart';

/// Firebase: Google লগইন, ক্লাউড ব্যাকআপ, পাবলিক পোস্ট, Support, রিপোর্ট, ব্লক।
final cloud = Cloud();

class Cloud extends ChangeNotifier {
  bool ready = false;
  User? user;
  String? initError;
  Set<String> blocked = {};
  DateTime? lastSync;
  Timer? _debounce;

  static bool get configured =>
      kFirebaseApiKey.isNotEmpty && kFirebaseAppId.isNotEmpty && kFirebaseProjectId.isNotEmpty;

  bool get signedIn => ready && user != null;
  String get uid => user?.uid ?? '';
  String get displayName => user?.displayName ?? '';
  String get photoUrl => user?.photoURL ?? '';
  String get email => user?.email ?? '';

  FirebaseFirestore get _db => FirebaseFirestore.instance;
  CollectionReference<Map<String, dynamic>> get _posts => _db.collection('posts');
  DocumentReference<Map<String, dynamic>> get _me => _db.collection('users').doc(uid);

  Future<void> init() async {
    if (!configured) return;
    try {
      await Firebase.initializeApp(
        options: const FirebaseOptions(
          apiKey: kFirebaseApiKey,
          appId: kFirebaseAppId,
          messagingSenderId: kFirebaseSenderId,
          projectId: kFirebaseProjectId,
        ),
      );
      ready = true;
      user = FirebaseAuth.instance.currentUser;
      FirebaseAuth.instance.authStateChanges().listen((u) {
        user = u;
        notifyListeners();
      });
      if (user != null) {
        unawaited(_loadBlocked());
      }
    } catch (e) {
      initError = '$e';
    }
  }

  // ---------- লগইন ----------
  Future<String?> signInWithGoogle() async {
    if (!ready) return t('err.nocloud');
    try {
      final gs = GoogleSignIn(serverClientId: kWebClientId.isEmpty ? null : kWebClientId);
      final acc = await gs.signIn();
      if (acc == null) return t('err.cancelled');
      final auth = await acc.authentication;
      final cred = GoogleAuthProvider.credential(
        accessToken: auth.accessToken,
        idToken: auth.idToken,
      );
      final res = await FirebaseAuth.instance.signInWithCredential(cred);
      user = res.user;
      await _afterLogin();
      notifyListeners();
      return null;
    } catch (e) {
      return '$e';
    }
  }

  Future<void> _afterLogin() async {
    final u = user;
    if (u == null) return;
    await _me.set({
      'name': u.displayName ?? '',
      'photo': u.photoURL ?? '',
      'lastLogin': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
    await _loadBlocked();
    final snap = await _me.collection('data').doc('state').get();
    final data = snap.data();
    if (snap.exists && data != null && data['json'] is String) {
      final cloudAt = (data['updatedAt'] as num?)?.toInt() ?? 0;
      if (cloudAt >= app.updatedAt) {
        app.importJson(jsonDecode(data['json'] as String) as Map<String, dynamic>,
            fromCloud: true);
        await app.replan(force: true);
        app.touchUi();
        lastSync = DateTime.now();
        return;
      }
    }
    await pushNow();
  }

  Future<void> signOut() async {
    try {
      await pushNow();
    } catch (_) {}
    try {
      await GoogleSignIn().signOut();
    } catch (_) {}
    if (ready) {
      await FirebaseAuth.instance.signOut();
    }
    user = null;
    blocked = {};
    await app.resetLocal();
    notifyListeners();
  }

  // ---------- ক্লাউড ব্যাকআপ ----------
  void pushSoon() {
    if (!signedIn || !app.prefs.cloudBackup) return;
    _debounce?.cancel();
    _debounce = Timer(const Duration(seconds: 3), () {
      pushNow();
    });
  }

  Future<void> pushNow() async {
    if (!signedIn || !app.prefs.cloudBackup) return;
    try {
      final js = jsonEncode(app.exportJson(forCloud: true));
      await _me.collection('data').doc('state').set({
        'json': js,
        'updatedAt': app.updatedAt,
        'saved': FieldValue.serverTimestamp(),
      });
      lastSync = DateTime.now();
      notifyListeners();
    } catch (_) {}
  }

  // ---------- পোস্ট ----------
  Stream<QuerySnapshot<Map<String, dynamic>>> feed() =>
      _posts.orderBy('createdAt', descending: true).limit(50).snapshots();

  Future<String?> createPost({
    required String type,
    required String text,
    required List<Map<String, dynamic>> items,
    required String audience,
  }) async {
    if (!signedIn) return t('err.login');
    try {
      final data = <String, dynamic>{
        'uid': uid,
        'name': displayName.isEmpty ? t('user.default') : displayName,
        'photo': photoUrl,
        'type': type,
        'text': text,
        'items': items,
        'createdAt': FieldValue.serverTimestamp(),
        'supportCount': 0,
      };
      if (audience == 'me') {
        await _me.collection('mine').add(data);
      } else {
        await _posts.add(data);
      }
      return null;
    } catch (e) {
      return '$e';
    }
  }

  Stream<bool> supported(String postId) {
    if (!signedIn) return Stream<bool>.value(false);
    return _posts
        .doc(postId)
        .collection('supports')
        .doc(uid)
        .snapshots()
        .map((s) => s.exists);
  }

  Future<void> toggleSupport(String postId) async {
    if (!signedIn) return;
    final pref = _posts.doc(postId);
    final sref = pref.collection('supports').doc(uid);
    await _db.runTransaction((tx) async {
      final s = await tx.get(sref);
      if (s.exists) {
        tx.delete(sref);
        tx.update(pref, {'supportCount': FieldValue.increment(-1)});
      } else {
        tx.set(sref, {'at': FieldValue.serverTimestamp()});
        tx.update(pref, {'supportCount': FieldValue.increment(1)});
      }
    });
  }

  Future<void> deletePost(String postId) async {
    try {
      await _posts.doc(postId).delete();
    } catch (_) {}
  }

  Future<void> report(String postId, String postUid, String reason) async {
    if (!signedIn) return;
    try {
      await _db.collection('reports').add({
        'postId': postId,
        'postUid': postUid,
        'by': uid,
        'reason': reason,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (_) {}
  }

  // ---------- ব্লক ----------
  Future<void> _loadBlocked() async {
    try {
      final q = await _me.collection('blocked').get();
      blocked = q.docs.map((d) => d.id).toSet();
    } catch (_) {}
  }

  Future<void> block(String otherUid, String name) async {
    if (!signedIn) return;
    blocked.add(otherUid);
    notifyListeners();
    try {
      await _me.collection('blocked').doc(otherUid).set({
        'name': name,
        'at': FieldValue.serverTimestamp(),
      });
    } catch (_) {}
  }

  Future<void> unblock(String otherUid) async {
    blocked.remove(otherUid);
    notifyListeners();
    try {
      await _me.collection('blocked').doc(otherUid).delete();
    } catch (_) {}
  }

  Future<List<Map<String, dynamic>>> blockedList() async {
    if (!signedIn) return [];
    try {
      final q = await _me.collection('blocked').get();
      return q.docs.map((d) => {'uid': d.id, 'name': (d.data()['name'] ?? '').toString()}).toList();
    } catch (_) {
      return [];
    }
  }

  // ---------- অ্যাকাউন্ট মুছে ফেলা ----------
  Future<void> _deleteCollection(CollectionReference<Map<String, dynamic>> c) async {
    final q = await c.get();
    for (final d in q.docs) {
      await d.reference.delete();
    }
  }

  Future<String?> deleteAccount() async {
    final u = user;
    if (!signedIn || u == null) return t('err.login');
    try {
      final mine = await _posts.where('uid', isEqualTo: uid).get();
      for (final d in mine.docs) {
        await d.reference.delete();
      }
      await _deleteCollection(_me.collection('mine'));
      await _deleteCollection(_me.collection('blocked'));
      await _deleteCollection(_me.collection('data'));
      await _me.delete();
      try {
        await u.delete();
      } on FirebaseAuthException catch (e) {
        if (e.code == 'requires-recent-login') {
          final gs = GoogleSignIn(serverClientId: kWebClientId.isEmpty ? null : kWebClientId);
          final acc = await gs.signIn();
          if (acc == null) return t('err.cancelled');
          final auth = await acc.authentication;
          final cred = GoogleAuthProvider.credential(
              accessToken: auth.accessToken, idToken: auth.idToken);
          await u.reauthenticateWithCredential(cred);
          await u.delete();
        } else {
          return e.message ?? e.code;
        }
      }
      try {
        await GoogleSignIn().signOut();
      } catch (_) {}
      user = null;
      blocked = {};
      await app.resetLocal();
      notifyListeners();
      return null;
    } catch (e) {
      return '$e';
    }
  }
}
