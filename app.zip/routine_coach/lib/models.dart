const categories = ['পড়াশোনা', 'ব্যায়াম', 'কাজ', 'স্বাস্থ্য', 'দক্ষতা', 'অন্যান্য'];

String fmtMin(int m) {
  final h = (m ~/ 60) % 24;
  final mm = m % 60;
  return '${h.toString().padLeft(2, '0')}:${mm.toString().padLeft(2, '0')}';
}

String dateKey(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

int dateInt(DateTime d) => d.year * 10000 + d.month * 100 + d.day;

class TaskItem {
  final String id;
  String title;
  String category;
  int minutes;
  int priority; // 1 কম, 2 মাঝারি, 3 উচ্চ
  int part; // 0 যেকোনো, 1 সকাল, 2 দুপুর, 3 সন্ধ্যা/রাত

  TaskItem({
    required this.id,
    required this.title,
    required this.category,
    required this.minutes,
    required this.priority,
    required this.part,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'category': category,
        'minutes': minutes,
        'priority': priority,
        'part': part,
      };

  factory TaskItem.fromJson(Map<String, dynamic> j) => TaskItem(
        id: j['id'] as String,
        title: j['title'] as String,
        category: j['category'] as String,
        minutes: j['minutes'] as int,
        priority: j['priority'] as int,
        part: j['part'] as int,
      );
}

class TimeWindow {
  int start; // মিনিট (মধ্যরাত থেকে)
  int end;
  TimeWindow(this.start, this.end);

  Map<String, dynamic> toJson() => {'s': start, 'e': end};
  factory TimeWindow.fromJson(Map<String, dynamic> j) =>
      TimeWindow(j['s'] as int, j['e'] as int);
}

class PlanEntry {
  final String id;
  final String taskId;
  final String title;
  final String category;
  final int priority;
  final int startMin;
  final int minutes;
  int status; // 0 বাকি, 1 শেষ, 2 স্কিপ
  int snoozes;
  int alarmId;

  PlanEntry({
    required this.id,
    required this.taskId,
    required this.title,
    required this.category,
    required this.priority,
    required this.startMin,
    required this.minutes,
    this.status = 0,
    this.snoozes = 0,
    this.alarmId = 0,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'taskId': taskId,
        'title': title,
        'category': category,
        'priority': priority,
        'startMin': startMin,
        'minutes': minutes,
        'status': status,
        'snoozes': snoozes,
        'alarmId': alarmId,
      };

  factory PlanEntry.fromJson(Map<String, dynamic> j) => PlanEntry(
        id: j['id'] as String,
        taskId: j['taskId'] as String,
        title: j['title'] as String,
        category: j['category'] as String,
        priority: j['priority'] as int,
        startMin: j['startMin'] as int,
        minutes: j['minutes'] as int,
        status: j['status'] as int,
        snoozes: j['snoozes'] as int,
        alarmId: j['alarmId'] as int,
      );
}
