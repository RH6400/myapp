// মডেল: কাজ, ফ্রি সময়, রুটিন-এন্ট্রি ও ইউজারের সেটিংস।

String fmtMin(int m) {
  final h = (m ~/ 60) % 24;
  final mm = m % 60;
  return '${h.toString().padLeft(2, '0')}:${mm.toString().padLeft(2, '0')}';
}

String dateKey(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

int dateInt(DateTime d) => d.year * 10000 + d.month * 100 + d.day;

DateTime dayOnly(DateTime d) => DateTime(d.year, d.month, d.day);

const defaultCategories = ['পড়াশোনা', 'ব্যায়াম', 'কাজ', 'স্বাস্থ্য', 'দক্ষতা', 'অন্যান্য'];

/// অ্যালার্টের ধরন: alarm = সাউন্ড+ভাইব্রেশন+ফুল-স্ক্রিন, vibrate = নিঃশব্দ+ভাইব্রেশন+ফুল-স্ক্রিন,
/// notify = শুধু নোটিফিকেশন। 'default' মানে সেটিংসের ডিফল্ট।
const alertKinds = ['default', 'alarm', 'vibrate', 'notify'];
const forceKinds = ['default', 'soft', 'mid', 'hard'];

class TaskItem {
  final String id;
  String title;
  String category;
  int minutes;
  int priority; // 1 কম, 2 মাঝারি, 3 উচ্চ
  int part; // 0 যেকোনো, 1 সকাল, 2 দুপুর, 3 সন্ধ্যা/রাত
  int? fixedMin; // নির্দিষ্ট সময় (মধ্যরাত থেকে মিনিট); null = ফ্রি সময়ে অটো
  List<int> days; // 1=সোম ... 7=রবি; খালি = প্রতিদিন
  String? onDate; // এক দিনের কাজ হলে তারিখ (yyyy-MM-dd)
  String alert;
  String force;

  TaskItem({
    required this.id,
    required this.title,
    required this.category,
    required this.minutes,
    required this.priority,
    this.part = 0,
    this.fixedMin,
    List<int>? days,
    this.onDate,
    this.alert = 'default',
    this.force = 'default',
  }) : days = days ?? <int>[];

  bool activeOn(DateTime d) {
    if (onDate != null) return onDate == dateKey(d);
    return days.isEmpty || days.contains(d.weekday);
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'category': category,
        'minutes': minutes,
        'priority': priority,
        'part': part,
        'fixedMin': fixedMin,
        'days': days,
        'onDate': onDate,
        'alert': alert,
        'force': force,
      };

  factory TaskItem.fromJson(Map<String, dynamic> j) => TaskItem(
        id: j['id'] as String,
        title: j['title'] as String,
        category: (j['category'] as String?) ?? 'অন্যান্য',
        minutes: (j['minutes'] as num?)?.toInt() ?? 30,
        priority: (j['priority'] as num?)?.toInt() ?? 2,
        part: (j['part'] as num?)?.toInt() ?? 0,
        fixedMin: (j['fixedMin'] as num?)?.toInt(),
        days: ((j['days'] as List?) ?? const []).map((e) => (e as num).toInt()).toList(),
        onDate: j['onDate'] as String?,
        alert: (j['alert'] as String?) ?? 'default',
        force: (j['force'] as String?) ?? 'default',
      );
}

class TimeWindow {
  int start; // মিনিট (মধ্যরাত থেকে)
  int end;
  TimeWindow(this.start, this.end);

  Map<String, dynamic> toJson() => {'s': start, 'e': end};
  factory TimeWindow.fromJson(Map<String, dynamic> j) =>
      TimeWindow((j['s'] as num).toInt(), (j['e'] as num).toInt());
}

class PlanEntry {
  final String id;
  final String taskId;
  final String title;
  final String category;
  final int priority;
  int startMin;
  final int minutes;
  int status; // 0 বাকি, 1 শেষ, 2 স্কিপ (জরিমানা), 3 আজ করব না (জরিমানা ছাড়া)
  int snoozes;
  int alarmId;
  bool pinned; // হাতে বা সহকারী দিয়ে সরানো; অটো-সাজানোয় নড়বে না
  bool fixed;
  String alert;
  String force;

  PlanEntry({
    required this.id,
    required this.taskId,
    required this.title,
    required this.category,
    required this.priority,
    required this.startMin,
    required this.minutes,
    this.status = 0,
    this.snoozes = 0,
    this.alarmId = 0,
    this.pinned = false,
    this.fixed = false,
    this.alert = 'default',
    this.force = 'default',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'taskId': taskId,
        'title': title,
        'category': category,
        'priority': priority,
        'startMin': startMin,
        'minutes': minutes,
        'status': status,
        'snoozes': snoozes,
        'alarmId': alarmId,
        'pinned': pinned,
        'fixed': fixed,
        'alert': alert,
        'force': force,
      };

  factory PlanEntry.fromJson(Map<String, dynamic> j) => PlanEntry(
        id: j['id'] as String,
        taskId: j['taskId'] as String,
        title: j['title'] as String,
        category: (j['category'] as String?) ?? 'অন্যান্য',
        priority: (j['priority'] as num?)?.toInt() ?? 2,
        startMin: (j['startMin'] as num).toInt(),
        minutes: (j['minutes'] as num).toInt(),
        status: (j['status'] as num?)?.toInt() ?? 0,
        snoozes: (j['snoozes'] as num?)?.toInt() ?? 0,
        alarmId: (j['alarmId'] as num?)?.toInt() ?? 0,
        pinned: (j['pinned'] as bool?) ?? false,
        fixed: (j['fixed'] as bool?) ?? false,
        alert: (j['alert'] as String?) ?? 'default',
        force: (j['force'] as String?) ?? 'default',
      );
}

/// ফোর্সের চূড়ান্ত মান (লেভেল ধরে হিসাব করা)।
class ForceConfig {
  final int snoozeMax;
  final int snoozeMin;
  final int lockPct;
  final bool blockBack;
  final bool xpPenalty;
  const ForceConfig({
    required this.snoozeMax,
    required this.snoozeMin,
    required this.lockPct,
    required this.blockBack,
    required this.xpPenalty,
  });
}

class Prefs {
  String lang = 'bn';
  String theme = 'system'; // system | light | dark
  String force = 'mid'; // soft | mid | hard | own
  int snoozeMax = 2;
  int snoozeMin = 10;
  int lockPct = 80;
  bool blockBack = true;
  bool xpPenalty = true;
  String alert = 'alarm'; // ডিফল্ট অ্যালার্টের ধরন
  String mood = 'normal'; // quiet | normal | chatty | coach
  int offDay = 0; // 0 = নেই, নাহলে weekday (যেমন 5 = শুক্রবার)
  bool cloudBackup = true;
  String audience = 'public'; // public | me
  List<String> categories = List<String>.from(defaultCategories);
  String geminiKey = '';
  String geminiModel = 'gemini-2.0-flash';
  bool onboarded = false;
  bool guideDone = false;
  bool persistent = true; // সবসময়-থাকা নোটিফিকেশন
  int nudges = 2; // দিনে কতবার সহকারী খোঁজ নেবে (0 = নেই)

  Map<String, dynamic> toJson() => {
        'lang': lang,
        'theme': theme,
        'force': force,
        'snoozeMax': snoozeMax,
        'snoozeMin': snoozeMin,
        'lockPct': lockPct,
        'blockBack': blockBack,
        'xpPenalty': xpPenalty,
        'alert': alert,
        'mood': mood,
        'offDay': offDay,
        'cloudBackup': cloudBackup,
        'audience': audience,
        'categories': categories,
        'geminiKey': geminiKey,
        'geminiModel': geminiModel,
        'onboarded': onboarded,
        'guideDone': guideDone,
        'persistent': persistent,
        'nudges': nudges,
      };

  void loadJson(Map<String, dynamic> j) {
    lang = (j['lang'] as String?) ?? lang;
    theme = (j['theme'] as String?) ?? theme;
    force = (j['force'] as String?) ?? force;
    snoozeMax = (j['snoozeMax'] as num?)?.toInt() ?? snoozeMax;
    snoozeMin = (j['snoozeMin'] as num?)?.toInt() ?? snoozeMin;
    lockPct = (j['lockPct'] as num?)?.toInt() ?? lockPct;
    blockBack = (j['blockBack'] as bool?) ?? blockBack;
    xpPenalty = (j['xpPenalty'] as bool?) ?? xpPenalty;
    alert = (j['alert'] as String?) ?? alert;
    mood = (j['mood'] as String?) ?? mood;
    offDay = (j['offDay'] as num?)?.toInt() ?? offDay;
    cloudBackup = (j['cloudBackup'] as bool?) ?? cloudBackup;
    audience = (j['audience'] as String?) ?? audience;
    final cats = j['categories'] as List?;
    if (cats != null && cats.isNotEmpty) {
      categories = cats.map((e) => e.toString()).toList();
    }
    geminiKey = (j['geminiKey'] as String?) ?? geminiKey;
    geminiModel = (j['geminiModel'] as String?) ?? geminiModel;
    onboarded = (j['onboarded'] as bool?) ?? onboarded;
    guideDone = (j['guideDone'] as bool?) ?? guideDone;
    persistent = (j['persistent'] as bool?) ?? persistent;
    nudges = (j['nudges'] as num?)?.toInt() ?? nudges;
  }

  ForceConfig forceFor(String level) {
    switch (level) {
      case 'soft':
        return const ForceConfig(
            snoozeMax: 5, snoozeMin: 10, lockPct: 0, blockBack: false, xpPenalty: false);
      case 'mid':
        return const ForceConfig(
            snoozeMax: 2, snoozeMin: 10, lockPct: 80, blockBack: true, xpPenalty: true);
      case 'hard':
        return const ForceConfig(
            snoozeMax: 0, snoozeMin: 5, lockPct: 100, blockBack: true, xpPenalty: true);
      default:
        return ForceConfig(
            snoozeMax: snoozeMax,
            snoozeMin: snoozeMin,
            lockPct: lockPct,
            blockBack: blockBack,
            xpPenalty: xpPenalty);
    }
  }

  /// কাজের নিজস্ব ফোর্স থাকলে সেটা, নাহলে সেটিংসের।
  ForceConfig resolveForce(String taskForce) =>
      forceFor(taskForce == 'default' ? force : taskForce);

  String resolveAlert(String taskAlert) => taskAlert == 'default' ? alert : taskAlert;
}
