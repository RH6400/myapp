import 'dart:convert';
import 'package:http/http.dart' as http;
import 'models.dart';
import 'planner.dart';
import 'state.dart';

/// অফলাইন, নিয়ম-ভিত্তিক বিশ্লেষণ — ইন্টারনেট/API ছাড়াই চলে।
List<String> localInsights(AppState s) {
  final out = <String>[];
  final hist = s.allEntries.where((e) => e.status != 0).toList();

  if (s.streak > 0) {
    out.add('🔥 আপনার স্ট্রিক ${s.streak} দিন। আজ ৭০%+ কাজ শেষ করলে স্ট্রিক বাঁচবে।');
  }

  if (hist.length < 4) {
    out.add('📊 কয়েকটা কাজ শেষ বা স্কিপ হলে আপনার সেরা সময় ও দুর্বল জায়গা বিশ্লেষণ শুরু হবে।');
  } else {
    final byPart = <int, List<int>>{};
    final byCat = <String, List<int>>{};
    for (final e in hist) {
      final p = byPart.putIfAbsent(partOf(e.startMin), () => [0, 0]);
      p[1]++;
      final c = byCat.putIfAbsent(e.category, () => [0, 0]);
      c[1]++;
      if (e.status == 1) {
        p[0]++;
      } else {
        c[0]++; // স্কিপ গণনা
      }
    }

    int? bestPart;
    var bestRate = -1.0;
    byPart.forEach((p, v) {
      if (v[1] >= 2 && v[0] / v[1] > bestRate) {
        bestRate = v[0] / v[1];
        bestPart = p;
      }
    });
    if (bestPart != null) {
      out.add('⏰ ${partNames[bestPart]} সময়ে আপনার সফলতার হার সবচেয়ে বেশি '
          '(${(bestRate * 100).round()}%)। কঠিন কাজ এই সময়ে রাখুন।');
    }

    String? worstCat;
    var worstRate = 0.4;
    byCat.forEach((c, v) {
      if (v[1] >= 2 && v[0] / v[1] > worstRate) {
        worstRate = v[0] / v[1];
        worstCat = c;
      }
    });
    if (worstCat != null) {
      out.add('⚠️ "$worstCat" ক্যাটাগরির ${(worstRate * 100).round()}% কাজ স্কিপ হচ্ছে। '
          'সময় কমিয়ে ছোট ছোট সেশনে ভাগ করে দেখুন।');
    }
  }

  final today = s.entriesFor(DateTime.now());
  final late = today.where((e) => e.status == 0 && e.priority == 3 && e.startMin >= 21 * 60);
  if (late.isNotEmpty) {
    out.add('🌙 "${late.first.title}" গুরুত্বপূর্ণ কাজ, কিন্তু রাত ৯টার পরে পড়েছে। '
        'আগের সময়ে ফ্রি স্লট যোগ করলে সফল হওয়ার সম্ভাবনা বাড়বে।');
  }

  final capacity = s.windows.fold(0, (a, w) => a + (w.end - w.start));
  final planned = s.tasks.fold(0, (a, t) => a + t.minutes);
  if (planned > capacity) {
    out.add('📦 আপনার কাজ মোট $planned মিনিট, কিন্তু ফ্রি সময় $capacity মিনিট। '
        'কম অগ্রাধিকারের কাজ কমান বা ফ্রি সময় বাড়ান।');
  }
  if (s.unplaced.isNotEmpty) {
    out.add('🧩 জায়গা হয়নি: ${s.unplaced.map((t) => t.title).join(', ')}।');
  }
  return out;
}

String _summary(AppState s) {
  final hist = s.allEntries.where((e) => e.status != 0).toList();
  final last = hist.length > 60 ? hist.sublist(hist.length - 60) : hist;
  return jsonEncode({
    'ফ্রি_সময়': s.windows.map((w) => '${fmtMin(w.start)}-${fmtMin(w.end)}').toList(),
    'কাজ': s.tasks
        .map((t) => {
              'নাম': t.title,
              'ক্যাটাগরি': t.category,
              'মিনিট': t.minutes,
              'অগ্রাধিকার': t.priority,
              'পছন্দের_সময়': partNames[t.part],
            })
        .toList(),
    'স্ট্রিক': s.streak,
    'লেভেল': s.level,
    'ইতিহাস': last
        .map((e) => {
              'কাজ': e.title,
              'সময়': fmtMin(e.startMin),
              'ফল': e.status == 1 ? 'শেষ' : 'স্কিপ',
              'স্নুজ': e.snoozes,
            })
        .toList(),
  });
}

/// Gemini (ফ্রি টিয়ার) দিয়ে উত্তর; কী না থাকলে অফলাইন বিশ্লেষণ।
Future<String> askAssistant(AppState s, String question) async {
  if (s.geminiKey.isEmpty) {
    return '${localInsights(s).join('\n\n')}\n\n'
        '(আরও স্মার্ট উত্তরের জন্য সহকারী পাতার ⚙️ থেকে ফ্রি Gemini API কী যোগ করুন।)';
  }
  final prompt = 'তুমি একজন বন্ধুসুলভ প্রোডাক্টিভিটি কোচ। বাংলায়, সংক্ষেপে (সর্বোচ্চ ১৫০ শব্দ), '
      'বাস্তবসম্মত ও নির্দিষ্ট পরামর্শ দাও। কখন, কীভাবে করলে ভালো এবং বিকল্প কী — তা বলো। '
      'নিচের ডেটার বাইরে কিছু বানিয়ে বলবে না।\n\nব্যবহারকারীর ডেটা: ${_summary(s)}\n\nপ্রশ্ন: $question';
  try {
    final uri = Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/'
        '${s.geminiModel}:generateContent?key=${s.geminiKey}');
    final r = await http
        .post(uri,
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'contents': [
                {
                  'parts': [
                    {'text': prompt}
                  ]
                }
              ]
            }))
        .timeout(const Duration(seconds: 30));
    if (r.statusCode != 200) {
      return 'AI সংযোগে সমস্যা (কোড ${r.statusCode})। API কী ও মডেলের নাম ঠিক আছে কি না দেখুন।';
    }
    final j = jsonDecode(utf8.decode(r.bodyBytes));
    return (j['candidates'][0]['content']['parts'][0]['text'] as String).trim();
  } catch (e) {
    return 'ইন্টারনেট বা AI সংযোগে সমস্যা হয়েছে। অফলাইন বিশ্লেষণ:\n\n${localInsights(s).join('\n\n')}';
  }
}
