import 'i18n.dart';
import 'models.dart';
import 'planner.dart';
import 'state.dart';

String partName(int p) {
  switch (p) {
    case 1:
      return L('সকাল', 'Morning');
    case 2:
      return L('দুপুর', 'Noon');
    case 3:
      return L('সন্ধ্যা/রাত', 'Evening/Night');
    default:
      return L('যেকোনো সময়', 'Any time');
  }
}

/// অফলাইন, নিয়ম-ভিত্তিক বিশ্লেষণ: ইন্টারনেট/API ছাড়াই চলে।
List<String> localInsights(AppState s) {
  final out = <String>[];
  final hist = s.allEntries.where((e) => e.status == 1 || e.status == 2).toList();

  if (s.streak > 0) {
    out.add(L('আপনার স্ট্রিক ${s.streak} দিন। আজ ৭০%+ কাজ শেষ করলে স্ট্রিক বাঁচবে।',
        'Your streak is ${s.streak} days. Finish 70%+ today to keep it.'));
  }

  if (hist.length < 4) {
    out.add(L('কয়েকটা কাজ শেষ বা স্কিপ হলে আপনার সেরা সময় ও দুর্বল জায়গা বিশ্লেষণ শুরু হবে।',
        'After a few finished or skipped tasks I will start analysing your best time and weak spots.'));
  } else {
    final byPart = <int, List<int>>{};
    final byCat = <String, List<int>>{};
    for (final e in hist) {
      final p = byPart.putIfAbsent(partOf(e.startMin), () => [0, 0]);
      p[1]++;
      final c = byCat.putIfAbsent(e.category, () => [0, 0]);
      c[1]++;
      if (e.status == 1) {
        p[0]++;
      } else {
        c[0]++;
      }
    }
    int? bestPart;
    var bestRate = -1.0;
    byPart.forEach((p, v) {
      if (v[1] >= 2 && v[0] / v[1] > bestRate) {
        bestRate = v[0] / v[1];
        bestPart = p;
      }
    });
    if (bestPart != null) {
      final pct = (bestRate * 100).round();
      out.add(L('${partName(bestPart!)} সময়ে আপনার সফলতার হার সবচেয়ে বেশি ($pct%)। কঠিন কাজ এই সময়ে রাখুন।',
          'Your success rate is highest in the ${partName(bestPart!)} ($pct%). Put hard tasks there.'));
    }
    String? worstCat;
    var worstRate = 0.4;
    byCat.forEach((c, v) {
      if (v[1] >= 2 && v[0] / v[1] > worstRate) {
        worstRate = v[0] / v[1];
        worstCat = c;
      }
    });
    if (worstCat != null) {
      final pct = (worstRate * 100).round();
      out.add(L('“$worstCat” ক্যাটাগরির $pct% কাজ স্কিপ হচ্ছে। সময় কমিয়ে ছোট সেশনে ভাগ করে দেখুন।',
          '$pct% of your “$worstCat” tasks get skipped. Try shorter sessions.'));
    }
  }

  final capacity = s.windows.fold<int>(0, (a, w) => a + (w.end - w.start));
  final planned = s.tasks.where((t) => t.fixedMin == null).fold<int>(0, (a, t) => a + t.minutes);
  if (planned > capacity) {
    out.add(L('আপনার অটো-কাজ মোট $planned মিনিট, কিন্তু ফ্রি সময় $capacity মিনিট। কম অগ্রাধিকারের কাজ কমান বা ফ্রি সময় বাড়ান।',
        'Your auto tasks total $planned min but free time is $capacity min. Trim low-priority tasks or add free time.'));
  }
  if (s.unplaced.isNotEmpty) {
    final names = s.unplaced.map((t) => t.title).join(', ');
    out.add(L('জায়গা হয়নি: $names।', 'No room for: $names.'));
  }
  return out;
}
