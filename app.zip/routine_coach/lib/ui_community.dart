import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'cloud.dart';
import 'i18n.dart';
import 'models.dart';
import 'state.dart';
import 'ui_common.dart';

/// কমিউনিটি: পাবলিক ফিড, পোস্ট, Support। গ্রুপ ও পেজ পরে আসবে।
class SocialTab extends StatefulWidget {
  const SocialTab({super.key});
  @override
  State<SocialTab> createState() => _SocialTabState();
}

class _SocialTabState extends State<SocialTab> {
  int seg = 0;
  Stream<QuerySnapshot<Map<String, dynamic>>>? _feed;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: cloud,
      builder: (context, _) {
        return Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: SegmentedButton<int>(
              segments: [
                ButtonSegment(value: 0, label: Text(L('ফিড', 'Feed'))),
                ButtonSegment(value: 1, label: Text(L('গ্রুপ', 'Groups'))),
                ButtonSegment(value: 2, label: Text(L('পেজ', 'Pages'))),
              ],
              selected: {seg},
              onSelectionChanged: (s) => setState(() => seg = s.first),
            ),
          ),
          Expanded(child: seg == 0 ? _feedView(context) : _soon(context)),
        ]);
      },
    );
  }

  Widget _soon(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.hourglass_empty, size: 36),
          const SizedBox(height: 8),
          Text(L('শীঘ্রই আসছে', 'Coming soon'), style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          Text(
            seg == 1
                ? L('গ্রুপ খুলে একসাথে লক্ষ্য ঠিক করতে পারবেন।', 'You will be able to create groups and set goals together.')
                : L('নিজের পেজ খুলে অন্যদের সাথে যুক্ত হতে পারবেন।', 'You will be able to create your own page.'),
            textAlign: TextAlign.center,
          ),
        ]),
      ),
    );
  }

  Widget _feedView(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    if (!Cloud.configured || !cloud.ready) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(
            L('কমিউনিটি চালু হলে এখানে অন্যদের রুটিন ও অর্জন দেখবেন।', 'Others\' routines and achievements will appear here once the community is on.'),
            textAlign: TextAlign.center,
            style: TextStyle(color: cs.onSurfaceVariant),
          ),
        ),
      );
    }
    if (!cloud.signedIn) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(L('অন্যদের পোস্ট দেখতে ও নিজের পোস্ট করতে Google দিয়ে লগইন করুন।', 'Sign in with Google to see and share posts.'),
                textAlign: TextAlign.center),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () async {
                final err = await cloud.signInWithGoogle();
                if (err != null && context.mounted) snack(context, err);
              },
              child: Text(L('লগইন', 'Sign in')),
            ),
          ]),
        ),
      );
    }
    _feed ??= cloud.feed();
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: _feed,
      builder: (context, snap) {
        if (snap.hasError) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Text(L('ফিড লোড হয়নি। ইন্টারনেট বা Firestore নিয়ম দেখুন।\n${snap.error}', 'Could not load the feed. Check internet or Firestore rules.\n${snap.error}'),
                  textAlign: TextAlign.center, style: TextStyle(color: cs.error)),
            ),
          );
        }
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final docs = snap.data!.docs.where((d) => !cloud.blocked.contains(d.data()['uid'])).toList();
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.edit_outlined)),
                title: Text(L('আপনার অর্জন বা রুটিন শেয়ার করুন…', 'Share your achievement or routine…')),
                onTap: () => showModalBottomSheet<void>(
                  context: context,
                  isScrollControlled: true,
                  showDragHandle: true,
                  builder: (_) => const _NewPostSheet(),
                ),
              ),
            ),
            if (docs.isEmpty)
              Padding(
                padding: const EdgeInsets.all(24),
                child: Text(L('এখনো কোনো পোস্ট নেই। প্রথম পোস্টটা আপনার হোক!', 'No posts yet. Be the first!'),
                    textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant)),
              ),
            for (final d in docs) _PostCard(key: ValueKey(d.id), doc: d),
          ],
        );
      },
    );
  }
}

String _ago(dynamic ts) {
  if (ts is! Timestamp) return L('এখন', 'now');
  final diff = DateTime.now().difference(ts.toDate());
  if (diff.inMinutes < 1) return L('এখন', 'now');
  if (diff.inMinutes < 60) return L('${diff.inMinutes} মিনিট আগে', '${diff.inMinutes} min ago');
  if (diff.inHours < 24) return L('${diff.inHours} ঘণ্টা আগে', '${diff.inHours} h ago');
  return L('${diff.inDays} দিন আগে', '${diff.inDays} d ago');
}

class _PostCard extends StatefulWidget {
  final QueryDocumentSnapshot<Map<String, dynamic>> doc;
  const _PostCard({super.key, required this.doc});
  @override
  State<_PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<_PostCard> {
  late final Stream<bool> supported = cloud.supported(widget.doc.id);

  @override
  Widget build(BuildContext context) {
    final d = widget.doc.data();
    final cs = Theme.of(context).colorScheme;
    final uid = (d['uid'] ?? '').toString();
    final name = (d['name'] ?? '').toString();
    final photo = (d['photo'] ?? '').toString();
    final text = (d['text'] ?? '').toString();
    final items = ((d['items'] as List?) ?? const []).whereType<Map>().toList();
    final count = (d['supportCount'] as num?)?.toInt() ?? 0;
    final own = uid == cloud.uid;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            CircleAvatar(
              backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null,
              child: photo.isEmpty ? Text(name.isEmpty ? 'U' : name.substring(0, 1)) : null,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(name.isEmpty ? t('user.default') : name, style: const TextStyle(fontWeight: FontWeight.w600)),
                Text(_ago(d['createdAt']), style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
              ]),
            ),
            PopupMenuButton<String>(
              onSelected: (v) => _menu(v, uid, name),
              itemBuilder: (_) => own
                  ? [PopupMenuItem(value: 'delete', child: Text(L('মুছুন', 'Delete')))]
                  : [
                      PopupMenuItem(value: 'report', child: Text(L('রিপোর্ট করুন', 'Report'))),
                      PopupMenuItem(value: 'block', child: Text(L('ইউজারকে ব্লক করুন', 'Block user'))),
                    ],
            ),
          ]),
          if (text.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: Text(text)),
          if (items.isNotEmpty) const SizedBox(height: 8),
          for (final it in items)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: Row(children: [
                Expanded(child: Text('• ${it['title']} — ${it['minutes']} ${L('মিনিট', 'min')}')),
                TextButton(
                  onPressed: () => _addToMine(it),
                  child: Text(L('+ আমার রুটিনে', '+ Add to mine')),
                ),
              ]),
            ),
          const SizedBox(height: 4),
          StreamBuilder<bool>(
            stream: supported,
            builder: (context, snap) {
              final on = snap.data == true;
              return Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                  onPressed: () => cloud.toggleSupport(widget.doc.id),
                  icon: Icon(on ? Icons.favorite : Icons.favorite_border, color: on ? Colors.redAccent : null),
                  label: Text('${L('সাপোর্ট', 'Support')} $count'),
                ),
              );
            },
          ),
        ]),
      ),
    );
  }

  Future<void> _addToMine(Map it) async {
    final minutes = (it['minutes'] as num?)?.toInt() ?? 30;
    final cats = app.prefs.categories;
    final cat = (it['category'] ?? '').toString();
    final task = TaskItem(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      title: (it['title'] ?? '').toString(),
      category: cats.contains(cat) ? cat : (cats.isNotEmpty ? cats.last : 'অন্যান্য'),
      minutes: minutes < 5 ? 5 : (minutes > 480 ? 480 : minutes),
      priority: 2,
    );
    await app.addTask(task);
    if (mounted) snack(context, L('আপনার রুটিনে যোগ হয়েছে', 'Added to your routine'));
  }

  Future<void> _menu(String v, String uid, String name) async {
    if (v == 'delete') {
      final ok = await confirm(context, L('পোস্ট মুছবেন?', 'Delete post?'), L('এটা ফেরানো যাবে না।', 'This cannot be undone.'));
      if (ok) await cloud.deletePost(widget.doc.id);
    } else if (v == 'report') {
      final r = await pickOne<String>(
        context,
        L('কেন রিপোর্ট করছেন?', 'Why are you reporting?'),
        {
          'spam': L('স্প্যাম', 'Spam'),
          'abuse': L('অশালীন বা আপত্তিকর', 'Abusive or offensive'),
          'fake': L('ভুয়া বা প্রতারণা', 'Fake or scam'),
          'other': L('অন্য কিছু', 'Other'),
        },
        '',
      );
      if (r != null) {
        await cloud.report(widget.doc.id, uid, r);
        if (mounted) snack(context, L('রিপোর্ট পাঠানো হয়েছে। ধন্যবাদ।', 'Report sent. Thank you.'));
      }
    } else if (v == 'block') {
      final ok = await confirm(
        context,
        L('ব্লক করবেন?', 'Block this user?'),
        L('এই ইউজারের পোস্ট আর আপনার ফিডে আসবে না।', 'Their posts will no longer appear in your feed.'),
      );
      if (ok) {
        await cloud.block(uid, name);
        if (mounted) snack(context, L('ব্লক করা হয়েছে', 'Blocked'));
      }
    }
  }
}

class _NewPostSheet extends StatefulWidget {
  const _NewPostSheet();
  @override
  State<_NewPostSheet> createState() => _NewPostSheetState();
}

class _NewPostSheetState extends State<_NewPostSheet> {
  final text = TextEditingController();
  String type = 'routine';
  bool includePlan = true;
  late String audience = app.prefs.audience;
  bool busy = false;

  @override
  void dispose() {
    text.dispose();
    super.dispose();
  }

  Future<void> _post() async {
    final items = <Map<String, dynamic>>[];
    if (type == 'routine' && includePlan) {
      for (final e in app.entriesFor(DateTime.now())) {
        if (e.status == 3) continue;
        items.add({'title': e.title, 'minutes': e.minutes, 'category': e.category});
      }
    }
    if (text.text.trim().isEmpty && items.isEmpty) {
      snack(context, L('কিছু লিখুন', 'Write something'));
      return;
    }
    setState(() => busy = true);
    final err = await cloud.createPost(type: type, text: text.text.trim(), items: items, audience: audience);
    if (!mounted) return;
    setState(() => busy = false);
    if (err != null) {
      snack(context, err);
      return;
    }
    Navigator.pop(context);
    snack(
      context,
      audience == 'me'
          ? L('সেভ হয়েছে, শুধু আপনি দেখবেন', 'Saved, only you can see it')
          : L('পোস্ট হয়েছে', 'Posted'),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(L('নতুন পোস্ট', 'New post'), style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          Wrap(spacing: 8, children: [
            ChoiceChip(label: Text(L('আমার রুটিন', 'My routine')), selected: type == 'routine', onSelected: (_) => setState(() => type = 'routine')),
            ChoiceChip(label: Text(L('অর্জন বা কথা', 'Achievement or note')), selected: type == 'note', onSelected: (_) => setState(() => type = 'note')),
          ]),
          const SizedBox(height: 8),
          TextField(
            controller: text,
            maxLines: 4,
            maxLength: 500,
            decoration: InputDecoration(hintText: L('কিছু লিখুন…', 'Write something…'), border: const OutlineInputBorder()),
          ),
          if (type == 'routine')
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(L('আজকের রুটিন যোগ করুন', 'Include today\'s routine')),
              value: includePlan,
              onChanged: (v) => setState(() => includePlan = v),
            ),
          const SizedBox(height: 4),
          Text(L('কে দেখবে', 'Who can see'), style: Theme.of(context).textTheme.labelLarge),
          const SizedBox(height: 4),
          Wrap(spacing: 8, children: [
            ChoiceChip(label: Text(L('সবাই', 'Everyone')), selected: audience == 'public', onSelected: (_) => setState(() => audience = 'public')),
            ChoiceChip(label: Text(L('শুধু আমি', 'Only me')), selected: audience == 'me', onSelected: (_) => setState(() => audience = 'me')),
          ]),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: busy ? null : _post,
              child: Padding(padding: const EdgeInsets.all(10), child: Text(L('পোস্ট করুন', 'Post'))),
            ),
          ),
        ]),
      ),
    );
  }
}
