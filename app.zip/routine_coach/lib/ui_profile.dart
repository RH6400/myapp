import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'cloud.dart';
import 'i18n.dart';
import 'state.dart';
import 'theme.dart';
import 'ui_common.dart';
import 'ui_myrewards.dart';
import 'ui_settings.dart';

/// প্রোফাইল: লেভেল, স্ট্রিক, অর্জন; পুরস্কার ও সেটিংসে যাওয়ার পথ।
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([app, cloud]),
      builder: (context, _) {
        final p = Pal.of(context);
        final rewards = app.prefs.useAppRewards;
        final w = app.periodStats(7);
        final counted = w.done + w.left + w.skipped;
        return Scaffold(
          appBar: AppBar(title: Text(L('প্রোফাইল', 'Profile'))),
          body: ListView(
            padding: listPad(context, top: 12, bottom: 32),
            children: [
              MCard(
                child: Row(children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: p.priSoft,
                    backgroundImage: cloud.signedIn && cloud.photoUrl.isNotEmpty ? NetworkImage(cloud.photoUrl) : null,
                    child: cloud.signedIn && cloud.photoUrl.isNotEmpty ? null : Icon(Icons.person, color: p.pri, size: 30),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(
                        cloud.signedIn && cloud.displayName.isNotEmpty
                            ? cloud.displayName
                            : (app.prefs.callName.isNotEmpty ? app.prefs.callName : t('user.default')),
                        style: TextStyle(color: p.tx, fontSize: 17, fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 4),
                      Row(children: [
                        StatusTag('🔥 ${app.streak} ${L('দিন', 'days')}', color: p.fire, bg: p.fireSoft),
                        if (rewards) ...[
                          const SizedBox(width: 8),
                          StatusTag('${L('লেভেল', 'Level')} ${app.level}', color: p.pri, bg: p.priSoft),
                        ],
                      ]),
                    ]),
                  ),
                ]),
              ),
              if (rewards)
                MCard(
                  margin: const EdgeInsets.only(top: 10),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Text('${app.xp} XP', style: TextStyle(color: p.fire, fontWeight: FontWeight.w800, fontSize: 16)),
                      const Spacer(),
                      Text('${200 - app.xpIntoLevel} XP ${L('বাকি পরের লেভেলে', 'to next level')}',
                          style: TextStyle(color: p.sub, fontSize: 12.5)),
                    ]),
                    const SizedBox(height: 8),
                    Bar(app.xpIntoLevel / 200, color: p.fire),
                  ]),
                ),
              MCard(
                margin: const EdgeInsets.only(top: 10),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(L('গত ৭ দিন', 'Last 7 days'), style: TextStyle(color: p.tx, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  Bar(counted == 0 ? 0 : w.done / counted, color: p.ok),
                  const SizedBox(height: 6),
                  Text(
                    '${L('শেষ করা কাজ', 'Tasks done')} ${w.done}/$counted • ${L('ফোকাস', 'Focus')} ${w.minutes ~/ 60}${L(' ঘণ্টা ', ' h ')}${w.minutes % 60}${L(' মিনিট', ' min')}',
                    style: TextStyle(color: p.sub, fontSize: 13),
                  ),
                ]),
              ),
              const SizedBox(height: 12),
              SettingGroup(children: [
                SettingTile(
                  icon: Icons.card_giftcard,
                  title: L('আমার পুরস্কার', 'My rewards'),
                  value: app.rewards.isEmpty ? null : '${app.rewards.length}',
                  onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const MyRewardsScreen())),
                ),
                SettingTile(
                  icon: Icons.settings_outlined,
                  title: L('সেটিংস', 'Settings'),
                  onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const SettingsScreen())),
                ),
              ]),
              if (rewards) ...[
                SectionTitle(L('অর্জন', 'Achievements')),
                for (final a in achievementList) _ach(context, p, a),
              ],
            ],
          ),
        );
      },
    );
  }

  Widget _ach(BuildContext context, Pal p, Achievement a) {
    final ok = app.unlocked.contains(a.id);
    final v = math.min(a.value(app), a.target);
    return MCard(
      margin: const EdgeInsets.only(bottom: 8),
      color: ok ? p.priSoft : null,
      child: Row(children: [
        Text(ok ? a.icon : '🔒', style: const TextStyle(fontSize: 26)),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t('ach.${a.id}.t'), style: TextStyle(color: p.tx, fontWeight: FontWeight.w700, fontSize: 14)),
            Text('${t('ach.${a.id}.d')}  ($v/${a.target})', style: TextStyle(color: p.sub, fontSize: 12.5)),
          ]),
        ),
        if (ok)
          IconButton(
            icon: Icon(Icons.share, color: p.pri),
            tooltip: L('কমিউনিটিতে পোস্ট', 'Post to community'),
            onPressed: () async {
              if (!cloud.signedIn) {
                snack(context, L('পোস্ট করতে আগে Google দিয়ে লগইন করুন (সেটিংসে)', 'Sign in with Google first (in Settings)'));
                return;
              }
              final err = await cloud.createPost(
                type: 'achievement',
                text: '${a.icon} ${t('ach.${a.id}.t')}',
                items: const [],
                audience: app.prefs.audience,
              );
              if (context.mounted) snack(context, err ?? L('পোস্ট হয়েছে', 'Posted'));
            },
          ),
      ]),
    );
  }
}
