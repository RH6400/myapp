import 'dart:io' show Platform;
import 'package:alarm/alarm.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'alarm_service.dart';
import 'state.dart';
import 'ui_alarm.dart';
import 'ui_assistant.dart';
import 'ui_home.dart';
import 'ui_rewards.dart';
import 'ui_social.dart';
import 'ui_tasks.dart';

final navKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await app.load();
  await AlarmService.init();
  if (Platform.isAndroid) {
    try {
      await Permission.notification.request();
      await Permission.scheduleExactAlarm.request();
    } catch (_) {}
  }
  Alarm.ringStream.stream.listen((settings) {
    final e = app.findPendingByAlarm(settings.id);
    if (e == null) {
      AlarmService.cancel(settings.id);
      return;
    }
    navKey.currentState?.push(MaterialPageRoute(builder: (_) => RingScreen(entry: e)));
  });
  runApp(const RoutineApp());
}

class RoutineApp extends StatelessWidget {
  const RoutineApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navKey,
      title: 'রুটিন কোচ',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF5B5BD6),
        brightness: Brightness.light,
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF5B5BD6),
        brightness: Brightness.dark,
      ),
      home: const Shell(),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int tab = 0;

  @override
  Widget build(BuildContext context) {
    const pages = [HomeTab(), TasksTab(), RewardsTab(), AssistantTab(), SocialTab()];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: tab, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.today), label: 'আজ'),
          NavigationDestination(icon: Icon(Icons.checklist), label: 'কাজ'),
          NavigationDestination(icon: Icon(Icons.emoji_events), label: 'পুরস্কার'),
          NavigationDestination(icon: Icon(Icons.psychology), label: 'সহকারী'),
          NavigationDestination(icon: Icon(Icons.groups), label: 'কমিউনিটি'),
        ],
      ),
    );
  }
}
