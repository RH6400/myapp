import 'package:alarm/alarm.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'alarm_service.dart';
import 'cloud.dart';
import 'i18n.dart';
import 'notif.dart';
import 'state.dart';
import 'theme.dart';
import 'ui_alarm.dart';
import 'ui_assistant.dart';
import 'ui_community.dart';
import 'ui_home.dart';
import 'ui_login.dart';
import 'ui_summary.dart';
import 'ui_tasks.dart';

final navKey = GlobalKey<NavigatorState>();
int? _ringingId;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // ফোনের নেভিগেশন বারের নিচ পর্যন্ত আঁকা হবে; প্রতিটা স্ক্রিন নিজে জায়গা ছেড়ে দেয়।
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  await app.load();
  await cloud.init();
  await AlarmService.init();
  await notif.init();
  Alarm.ringStream.stream.listen(_onRing);
  runApp(const MailoApp());
}

/// অ্যালার্ম বাজলে রিং-স্ক্রিন খোলে। অ্যাপ ঠান্ডা অবস্থা থেকে উঠলে নেভিগেটর তৈরি হওয়া পর্যন্ত অপেক্ষা করে।
Future<void> _onRing(AlarmSettings settings) async {
  final e = app.findPendingByAlarm(settings.id);
  if (e == null) {
    await AlarmService.cancel(settings.id);
    return;
  }
  if (_ringingId == settings.id) return;
  _ringingId = settings.id;
  for (var i = 0; i < 40; i++) {
    final nav = navKey.currentState;
    if (nav != null) {
      await nav.push(MaterialPageRoute<void>(builder: (_) => RingScreen(entry: e)));
      _ringingId = null;
      return;
    }
    await Future<void>.delayed(const Duration(milliseconds: 250));
  }
  _ringingId = null;
}

class MailoApp extends StatelessWidget {
  const MailoApp({super.key});

  ThemeMode _mode(String s) {
    switch (s) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        return MaterialApp(
          navigatorKey: navKey,
          title: 'Mailo',
          debugShowCheckedModeBanner: false,
          themeMode: _mode(app.prefs.theme),
          theme: buildTheme(Brightness.light),
          darkTheme: buildTheme(Brightness.dark),
          builder: (context, child) {
            final dark = Theme.of(context).brightness == Brightness.dark;
            return AnnotatedRegion<SystemUiOverlayStyle>(
              value: SystemUiOverlayStyle(
                statusBarColor: Colors.transparent,
                systemNavigationBarColor: Colors.transparent,
                systemNavigationBarContrastEnforced: false,
                statusBarIconBrightness: dark ? Brightness.light : Brightness.dark,
                systemNavigationBarIconBrightness: dark ? Brightness.light : Brightness.dark,
              ),
              child: child ?? const SizedBox.shrink(),
            );
          },
          home: app.prefs.onboarded ? const Shell() : const LoginScreen(),
        );
      },
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int tab = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await app.replan();
      await notif.refresh();
    });
  }

  @override
  Widget build(BuildContext context) {
    const pages = [HomeTab(), TasksTab(), AssistantTab(), SummaryTab(), SocialTab()];
    return ListenableBuilder(
      listenable: Listenable.merge([app, cloud]),
      builder: (context, _) {
        return Scaffold(
          body: SafeArea(bottom: false, child: IndexedStack(index: tab, children: pages)),
          bottomNavigationBar: NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            destinations: [
              NavigationDestination(
                  icon: const Icon(Icons.calendar_today_outlined),
                  selectedIcon: const Icon(Icons.calendar_today),
                  label: L('আজ', 'Today')),
              NavigationDestination(
                  icon: const Icon(Icons.checklist), label: L('কাজ', 'Tasks')),
              NavigationDestination(
                  icon: const Icon(Icons.auto_awesome_outlined),
                  selectedIcon: const Icon(Icons.auto_awesome),
                  label: app.prefs.assistantName),
              NavigationDestination(
                  icon: const Icon(Icons.bar_chart), label: L('সারাংশ', 'Summary')),
              NavigationDestination(
                  icon: const Icon(Icons.groups_outlined),
                  selectedIcon: const Icon(Icons.groups),
                  label: L('কমিউনিটি', 'Community')),
            ],
          ),
        );
      },
    );
  }
}
