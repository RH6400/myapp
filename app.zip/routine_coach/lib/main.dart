import 'package:alarm/alarm.dart';
import 'package:flutter/material.dart';
import 'alarm_service.dart';
import 'cloud.dart';
import 'i18n.dart';
import 'notif.dart';
import 'state.dart';
import 'ui_alarm.dart';
import 'ui_assistant.dart';
import 'ui_community.dart';
import 'ui_home.dart';
import 'ui_login.dart';
import 'ui_rewards.dart';
import 'ui_settings.dart';
import 'ui_tasks.dart';

final navKey = GlobalKey<NavigatorState>();
int? _ringingId;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await app.load();
  await cloud.init();
  await AlarmService.init();
  await notif.init();
  Alarm.ringStream.stream.listen(_onRing);
  runApp(const UthanApp());
}

/// অ্যালার্ম বাজলে রিং-স্ক্রিন খোলে। অ্যাপ ঠান্ডা অবস্থা থেকে উঠলে নেভিগেটর তৈরি হওয়া পর্যন্ত অপেক্ষা করে।
Future<void> _onRing(AlarmSettings settings) async {
  final e = app.findPendingByAlarm(settings.id);
  if (e == null) {
    await AlarmService.cancel(settings.id);
    return;
  }
  if (_ringingId == settings.id) return;
  _ringingId = settings.id;
  for (var i = 0; i < 40; i++) {
    final nav = navKey.currentState;
    if (nav != null) {
      await nav.push(MaterialPageRoute<void>(builder: (_) => RingScreen(entry: e)));
      _ringingId = null;
      return;
    }
    await Future<void>.delayed(const Duration(milliseconds: 250));
  }
  _ringingId = null;
}

class UthanApp extends StatelessWidget {
  const UthanApp({super.key});

  ThemeMode _mode(String s) {
    switch (s) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        return MaterialApp(
          navigatorKey: navKey,
          title: 'Uthan',
          debugShowCheckedModeBanner: false,
          themeMode: _mode(app.prefs.theme),
          theme: ThemeData(
            useMaterial3: true,
            colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF5B5BD6)),
          ),
          darkTheme: ThemeData(
            useMaterial3: true,
            colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF5B5BD6), brightness: Brightness.dark),
          ),
          home: app.prefs.onboarded ? const Shell() : const LoginScreen(),
        );
      },
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int tab = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await app.replan();
      await notif.refresh();
    });
  }

  @override
  Widget build(BuildContext context) {
    const pages = [HomeTab(), TasksTab(), RewardsTab(), AssistantTab(), SocialTab()];
    return ListenableBuilder(
      listenable: Listenable.merge([app, cloud]),
      builder: (context, _) {
        final photo = cloud.photoUrl;
        return Scaffold(
          appBar: AppBar(
            title: const Text('Uthan'),
            actions: [
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: IconButton(
                  tooltip: L('সেটিংস', 'Settings'),
                  onPressed: () => Navigator.of(context)
                      .push(MaterialPageRoute<void>(builder: (_) => const SettingsScreen())),
                  icon: CircleAvatar(
                    radius: 16,
                    backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null,
                    child: photo.isEmpty
                        ? Text(cloud.displayName.isEmpty ? 'U' : cloud.displayName.substring(0, 1))
                        : null,
                  ),
                ),
              ),
            ],
          ),
          body: SafeArea(child: IndexedStack(index: tab, children: pages)),
          bottomNavigationBar: NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            destinations: [
              NavigationDestination(icon: const Icon(Icons.today), label: L('আজ', 'Today')),
              NavigationDestination(icon: const Icon(Icons.checklist), label: L('কাজ', 'Tasks')),
              NavigationDestination(icon: const Icon(Icons.emoji_events), label: L('পুরস্কার', 'Rewards')),
              NavigationDestination(icon: const Icon(Icons.psychology), label: L('সহকারী', 'Assistant')),
              NavigationDestination(icon: const Icon(Icons.groups), label: L('কমিউনিটি', 'Community')),
            ],
          ),
        );
      },
    );
  }
}
