import 'package:alarm/alarm.dart';
import 'package:flutter/material.dart';
import 'alarm_service.dart';
import 'cloud.dart';
import 'i18n.dart';
import 'mailo_widgets.dart';
import 'notif.dart';
import 'state.dart';
import 'theme.dart';
import 'ui_alarm.dart';
import 'ui_assistant.dart';
import 'ui_community.dart';
import 'ui_home.dart';
import 'ui_login.dart';
import 'ui_rewards.dart';
import 'ui_tasks.dart';

final navKey = GlobalKey<NavigatorState>();
int? _ringingId;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await app.load();
  await cloud.init();
  await AlarmService.init();
  await notif.init();
  Alarm.ringStream.stream.listen(_onRing);
  runApp(const MailoApp());
}

/// অ্যালার্ম বাজলে রিং-স্ক্রিন খোলে। অ্যাপ ঠান্ডা অবস্থা থেকে উঠলে নেভিগেটর তৈরি হওয়া পর্যন্ত অপেক্ষা করে।
Future<void> _onRing(AlarmSettings settings) async {
  final e = app.findPendingByAlarm(settings.id);
  if (e == null) {
    await AlarmService.cancel(settings.id);
    return;
  }
  if (_ringingId == settings.id) return;
  _ringingId = settings.id;
  for (var i = 0; i < 40; i++) {
    final nav = navKey.currentState;
    if (nav != null) {
      await nav.push(MaterialPageRoute<void>(builder: (_) => RingScreen(entry: e)));
      _ringingId = null;
      return;
    }
    await Future<void>.delayed(const Duration(milliseconds: 250));
  }
  _ringingId = null;
}

class MailoApp extends StatelessWidget {
  const MailoApp({super.key});

  ThemeMode _mode(String s) {
    switch (s) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        return MaterialApp(
          navigatorKey: navKey,
          title: 'Mailo',
          debugShowCheckedModeBanner: false,
          themeMode: _mode(app.prefs.theme),
          theme: mailoTheme(Brightness.light),
          darkTheme: mailoTheme(Brightness.dark),
          home: app.prefs.onboarded ? const Shell() : const LoginScreen(),
        );
      },
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int tab = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await app.replan();
      await notif.refresh();
    });
  }

  // যে ট্যাবের নিজের হেডার নেই, তাকে হেডারসহ মুড়ে দেয়।
  Widget _wrap(String title, Widget child, {Widget? leading}) => Column(children: [
        TabHeader(title: title, leading: leading),
        Expanded(child: child),
      ]);

  @override
  Widget build(BuildContext context) {
    // ধাপ ২-এ সারাংশ ও Mailo ট্যাবের নিজস্ব হেডার/ডিজাইন আসবে।
    final pages = <Widget>[
      const HomeTab(),
      const TasksTab(),
      _wrap('Mailo', const AssistantTab(), leading: const MailoAiBadge(size: 40)),
      _wrap(L('সারাংশ', 'Summary'), const RewardsTab()),
      _wrap(L('কমিউনিটি', 'Community'), const SocialTab()),
    ];
    return ListenableBuilder(
      listenable: Listenable.merge([app, cloud]),
      builder: (context, _) {
        return Scaffold(
          body: SafeArea(child: IndexedStack(index: tab, children: pages)),
          bottomNavigationBar: NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            destinations: [
              NavigationDestination(
                icon: const Icon(Icons.calendar_today_outlined),
                selectedIcon: const Icon(Icons.calendar_today),
                label: L('আজ', 'Today'),
              ),
              NavigationDestination(
                icon: const Icon(Icons.checklist_rounded),
                selectedIcon: const Icon(Icons.checklist_rounded),
                label: L('কাজ', 'Tasks'),
              ),
              const NavigationDestination(
                icon: MailoAi(width: 34),
                selectedIcon: MailoAi(width: 34),
                label: 'Mailo',
              ),
              NavigationDestination(
                icon: const Icon(Icons.bar_chart_rounded),
                selectedIcon: const Icon(Icons.bar_chart_rounded),
                label: L('সারাংশ', 'Summary'),
              ),
              NavigationDestination(
                icon: const Icon(Icons.groups_outlined),
                selectedIcon: const Icon(Icons.groups),
                label: L('কমিউনিটি', 'Community'),
              ),
            ],
          ),
        );
      },
    );
  }
}
