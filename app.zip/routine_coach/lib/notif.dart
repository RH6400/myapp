import 'dart:async';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'i18n.dart';
import 'models.dart';
import 'state.dart';

/// সবসময়-থাকা নোটিফিকেশন ও সহকারীর মাঝেমধ্যে খোঁজ-নেওয়া মেসেজ।
/// (অ্যালার্ম নিজে `alarm` প্যাকেজ বাজায়; এটা শুধু নোটিফিকেশনের কাজ।)
final notif = Notif();

class Notif {
  final FlutterLocalNotificationsPlugin _p = FlutterLocalNotificationsPlugin();
  bool _ready = false;
  Timer? _debounce;

  String get _name => app.prefs.assistantName.isEmpty ? 'Mailo' : app.prefs.assistantName;
  static const _large = DrawableResourceAndroidBitmap('mailo_large');

  Future<void> init() async {
    try {
      await _p.initialize(
        settings: const InitializationSettings(
          android: AndroidInitializationSettings('ic_stat_mailo'),
        ),
      );
      _ready = true;
    } catch (_) {
      // ছোট আইকন না পেলে লঞ্চার আইকন দিয়ে চেষ্টা
      try {
        await _p.initialize(
          settings: const InitializationSettings(
            android: AndroidInitializationSettings('@mipmap/ic_launcher'),
          ),
        );
        _ready = true;
      } catch (_) {}
    }
  }

  Future<bool> requestPermission() async {
    try {
      final a = _p.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      final r = await a?.requestNotificationsPermission();
      return r ?? false;
    } catch (_) {
      return false;
    }
  }

  void refreshSoon() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(seconds: 2), refresh);
  }

  Future<void> refresh() async {
    if (!_ready) return;
    await _persistent();
    await _nudges();
  }

  Future<void> _persistent() async {
    try {
      if (!app.prefs.persistent) {
        await _p.cancel(id: 1);
        return;
      }
      final now = DateTime.now();
      final nowMin = now.hour * 60 + now.minute;
      PlanEntry? next;
      for (final e in app.entriesFor(now)) {
        if (e.status == 0 && e.startMin >= nowMin) {
          next = e;
          break;
        }
      }
      final body = next == null
          ? t('notif.persist.none')
          : t('notif.persist.next', [next.title, fmtMin(next.startMin)]);
      await _p.show(
        id: 1,
        title: _name,
        body: body,
        notificationDetails: NotificationDetails(
          android: AndroidNotificationDetails(
            'mailo_persistent',
            L('সবসময়-থাকা', 'Always on'),
            channelDescription: L('পরের কাজ দেখায়', 'Shows your next task'),
            importance: Importance.low,
            priority: Priority.low,
            ongoing: true,
            autoCancel: false,
            playSound: false,
            enableVibration: false,
            showWhen: false,
            onlyAlertOnce: true,
            largeIcon: _large,
          ),
        ),
      );
    } catch (_) {}
  }

  tz.TZDateTime _utc(DateTime local) {
    final u = local.toUtc();
    return tz.TZDateTime.utc(u.year, u.month, u.day, u.hour, u.minute, u.second);
  }

  /// আগামী ৩ দিনের জন্য খোঁজ-নেওয়া মেসেজ সাজায়। প্রতিবার আগেরগুলো মুছে নতুন করে বসায়।
  Future<void> _nudges() async {
    try {
      await _p.cancelAllPendingNotifications();
      final mood = app.prefs.mood;
      final n = app.prefs.nudges;
      if (mood == 'quiet' || n <= 0) return;
      final key = mood == 'coach' ? 'coach' : (mood == 'chatty' ? 'chatty' : 'normal');
      final now = DateTime.now();
      // দিনের ১০:০০ থেকে ২০:০০-র মধ্যে সমান ফাঁকে
      final slots = <int>[];
      if (n == 1) {
        slots.add(15 * 60);
      } else {
        final span = 10 * 60;
        for (var i = 0; i < n; i++) {
          slots.add(10 * 60 + (span * i ~/ (n - 1)));
        }
      }
      var id = 1000;
      for (var d = 0; d < 3; d++) {
        final day = DateTime(now.year, now.month, now.day + d);
        if (app.prefs.offDay != 0 && day.weekday == app.prefs.offDay) continue;
        for (var i = 0; i < slots.length; i++) {
          final at = DateTime(day.year, day.month, day.day, slots[i] ~/ 60, slots[i] % 60);
          if (at.isBefore(now.add(const Duration(minutes: 2)))) continue;
          final msg = t('nudge.$key.${(i + d) % 3 + 1}');
          await _p.zonedSchedule(
            id: id++,
            title: _name,
            body: msg,
            scheduledDate: _utc(at),
            androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
            notificationDetails: NotificationDetails(
              android: AndroidNotificationDetails(
                'mailo_nudge',
                L('সহকারীর খোঁজ', 'Assistant check-ins'),
                channelDescription: L('মাঝেমধ্যে কেমন চলছে জিজ্ঞেস করে', 'Occasionally asks how you are doing'),
                importance: Importance.defaultImportance,
                priority: Priority.defaultPriority,
                largeIcon: _large,
              ),
            ),
          );
        }
      }
    } catch (_) {}
  }
}
