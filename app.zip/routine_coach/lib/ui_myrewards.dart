import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'i18n.dart';
import 'models.dart';
import 'state.dart';
import 'theme.dart';
import 'ui_common.dart';

/// আমার পুরস্কার: লক্ষ্য পূরণ হলে ইউজার নিজেকে যা উপহার দেবে। চাইলে অ্যাপের XP/ব্যাজ বন্ধ করা যায়।
class MyRewardsScreen extends StatelessWidget {
  const MyRewardsScreen({super.key});

  String _condText(Reward r) {
    switch (r.cond) {
      case 'goal':
        final g = app.goalById(r.goalId);
        return g == null ? L('লক্ষ্য মুছে গেছে', 'Goal removed') : L('লক্ষ্য: ${g.title}', 'Goal: ${g.title}');
      case 'streak':
        return L('${r.value} দিন টানা', '${r.value}-day streak');
      default:
        return L('সপ্তাহের সব কাজ শেষ', 'Finish all tasks this week');
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final p = Pal.of(context);
        return Scaffold(
          appBar: AppBar(title: Text(L('আমার পুরস্কার', 'My rewards'))),
          floatingActionButton: Padding(
            padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewPadding.bottom),
            child: FloatingActionButton.extended(
              onPressed: () => showMailoSheet<void>(context, (_) => const _RewardSheet()),
              icon: const Icon(Icons.add),
              label: Text(L('নতুন পুরস্কার', 'New reward')),
            ),
          ),
          body: ListView(
            padding: listPad(context, top: 12, bottom: 96),
            children: [
              SettingGroup(children: [
                SwitchTile(
                  icon: Icons.emoji_events_outlined,
                  title: L('অ্যাপের XP ও ব্যাজ', 'App XP and badges'),
                  subtitle: L('বন্ধ করলে শুধু আপনার নিজের পুরস্কার থাকবে', 'Turn off to keep only your own rewards'),
                  value: app.prefs.useAppRewards,
                  onChanged: (v) {
                    app.prefs.useAppRewards = v;
                    app.savePrefs();
                  },
                ),
              ]),
              SectionTitle(L('আমার তালিকা', 'My list')),
              if (app.rewards.isEmpty)
                MCard(
                  child: Text(
                    L('এখনো কোনো পুরস্কার নেই। যেমন: “৩০ দিন শেষ হলে নতুন জুতা”, “৭ দিন টানা করলে সিনেমা”।',
                        'No rewards yet. E.g. “new shoes after 30 days”, “a movie after a 7-day streak”.'),
                    style: TextStyle(color: p.sub, fontSize: 13.5),
                  ),
                ),
              for (final r in app.rewards) _card(context, p, r),
            ],
          ),
        );
      },
    );
  }

  Widget _card(BuildContext context, Pal p, Reward r) {
    final f = app.rewardProgress(r);
    final ready = app.rewardReady(r);
    return MCard(
      margin: const EdgeInsets.only(bottom: 9),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          IconTile(r.claimed ? Icons.check_circle_outline : Icons.card_giftcard,
              color: r.claimed ? p.ok : p.fire, bg: r.claimed ? p.okSoft : p.fireSoft),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(r.text, style: TextStyle(color: p.tx, fontWeight: FontWeight.w700, fontSize: 14.5)),
              Text(_condText(r), style: TextStyle(color: p.sub, fontSize: 12.5)),
            ]),
          ),
          IconButton(
            icon: Icon(Icons.delete_outline, color: p.sub),
            onPressed: () async {
              final ok = await confirm(context, L('পুরস্কার মুছবেন?', 'Delete reward?'), r.text,
                  yes: L('মুছুন', 'Delete'));
              if (ok) app.removeReward(r.id);
            },
          ),
        ]),
        const SizedBox(height: 10),
        if (r.claimed)
          Text(L('নেওয়া হয়ে গেছে 🎉', 'Claimed 🎉'), style: TextStyle(color: p.ok, fontWeight: FontWeight.w600))
        else ...[
          Bar(f, color: ready ? p.ok : p.pri),
          const SizedBox(height: 8),
          Row(children: [
            Text('${(f * 100).round()}%', style: TextStyle(color: p.sub, fontSize: 12.5)),
            const Spacer(),
            if (ready)
              FilledButton(
                onPressed: () {
                  app.claimReward(r);
                  snack(context, L('অভিনন্দন! নিজেকে উপহার দিন।', 'Congratulations! Treat yourself.'));
                },
                child: Text(L('নিলাম', 'Claim')),
              ),
          ]),
        ],
      ]),
    );
  }
}

class _RewardSheet extends StatefulWidget {
  const _RewardSheet();
  @override
  State<_RewardSheet> createState() => _RewardSheetState();
}

class _RewardSheetState extends State<_RewardSheet> {
  final text = TextEditingController();
  String cond = 'goal';
  String? goalId = app.goals.isNotEmpty ? app.goals.first.id : null;
  int streakDays = 7;
  String? err;

  @override
  void dispose() {
    text.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final name = text.text.trim();
    if (name.isEmpty) {
      setState(() => err = L('পুরস্কারের নাম লিখুন', 'Enter the reward'));
      return;
    }
    if (cond == 'goal' && goalId == null) {
      setState(() => err = L('আগে একটা লক্ষ্য যোগ করুন', 'Add a goal first'));
      return;
    }
    await app.addReward(Reward(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      text: name,
      cond: cond,
      goalId: cond == 'goal' ? goalId : null,
      value: streakDays,
    ));
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final mq = MediaQuery.of(context);
    final bottom = math.max(mq.viewInsets.bottom, mq.viewPadding.bottom);
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Flexible(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(18, 0, 18, 8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(L('নতুন পুরস্কার', 'New reward'),
                style: TextStyle(color: p.tx, fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            TextField(
              controller: text,
              decoration: InputDecoration(
                labelText: L('কী উপহার দেবেন?', 'What will you give yourself?'),
                hintText: L('যেমন: নতুন জুতা', 'e.g. new shoes'),
                errorText: err,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
              ),
              onChanged: (_) {
                if (err != null) setState(() => err = null);
              },
            ),
            SectionTitle(L('কখন পাবেন', 'When')),
            Wrap(spacing: 8, children: [
              ChoiceChip(label: Text(L('লক্ষ্য পূরণে', 'Goal reached')), selected: cond == 'goal', onSelected: (_) => setState(() => cond = 'goal')),
              ChoiceChip(label: Text(L('টানা দিন', 'Streak')), selected: cond == 'streak', onSelected: (_) => setState(() => cond = 'streak')),
              ChoiceChip(label: Text(L('সপ্তাহ শেষে', 'Week')), selected: cond == 'week', onSelected: (_) => setState(() => cond = 'week')),
            ]),
            const SizedBox(height: 10),
            if (cond == 'goal')
              if (app.goals.isEmpty)
                Text(L('আগে “সারাংশ” ট্যাবে লক্ষ্য যোগ করুন।', 'Add a goal in the Summary tab first.'),
                    style: TextStyle(color: p.sub))
              else
                Wrap(spacing: 8, runSpacing: 6, children: [
                  for (final g in app.goals)
                    ChoiceChip(
                      label: Text(g.title),
                      selected: goalId == g.id,
                      onSelected: (_) => setState(() => goalId = g.id),
                    ),
                ]),
            if (cond == 'streak') ...[
              Text('${L('টানা', 'Streak of')} $streakDays ${L('দিন', 'days')}', style: TextStyle(color: p.tx)),
              Slider(
                value: streakDays.toDouble(),
                min: 3,
                max: 60,
                divisions: 57,
                onChanged: (v) => setState(() => streakDays = v.round()),
              ),
            ],
            if (cond == 'week')
              Text(L('গত ৭ দিনের সব কাজ শেষ হলে পাবেন।', 'You get it when all tasks of the last 7 days are done.'),
                  style: TextStyle(color: p.sub, fontSize: 13)),
          ]),
        ),
      ),
      Padding(
        padding: EdgeInsets.fromLTRB(18, 8, 18, 12 + bottom),
        child: SizedBox(
          width: double.infinity,
          child: FilledButton(
            onPressed: _save,
            child: Padding(padding: const EdgeInsets.all(10), child: Text(L('যোগ করুন', 'Add'))),
          ),
        ),
      ),
    ]);
  }
}
