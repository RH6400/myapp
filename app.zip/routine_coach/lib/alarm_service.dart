import 'package:alarm/alarm.dart';
import 'i18n.dart';
import 'models.dart';

/// `alarm` প্যাকেজ (v4.1.1) দিয়ে অ্যালার্ম। প্রতিটি এন্ট্রির অ্যালার্টের ধরন আলাদা হতে পারে।
class AlarmService {
  static Future<void> init() async {
    try {
      await Alarm.init();
    } catch (_) {}
  }

  static Future<void> scheduleAt(PlanEntry e, DateTime when, Prefs p) async {
    if (when.isBefore(DateTime.now())) return;
    final kind = p.resolveAlert(e.alert);
    // alarm: সাউন্ড + ভাইব্রেশন + লক-স্ক্রিনে ফুল-স্ক্রিন
    // vibrate: নিঃশব্দ + ভাইব্রেশন + ফুল-স্ক্রিন
    // notify: নিঃশব্দ, ভাইব্রেশন নেই, শুধু নোটিফিকেশন
    final double volume = kind == 'alarm' ? 0.9 : 0.0;
    final bool vibrate = kind != 'notify';
    final bool fullScreen = kind != 'notify';
    try {
      await Alarm.set(
        alarmSettings: AlarmSettings(
          id: e.alarmId,
          dateTime: when,
          assetAudioPath: 'assets/alarm.wav',
          loopAudio: true,
          vibrate: vibrate,
          volume: volume,
          fadeDuration: kind == 'alarm' ? 3.0 : 0.0,
          androidFullScreenIntent: fullScreen,
          notificationSettings: NotificationSettings(
            title: '⏰ ${e.title}',
            body: t('alarm.body', [e.minutes]),
          ),
        ),
      );
    } catch (_) {}
  }

  static Future<void> scheduleEntry(PlanEntry e, DateTime date, Prefs p) =>
      scheduleAt(e, DateTime(date.year, date.month, date.day, 0, e.startMin), p);

  static Future<void> cancelAll() async {
    try {
      await Alarm.stopAll();
    } catch (_) {}
  }

  static Future<void> cancel(int id) async {
    if (id == 0) return;
    try {
      await Alarm.stop(id);
    } catch (_) {}
  }
}
