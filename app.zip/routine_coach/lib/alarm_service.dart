import 'package:alarm/alarm.dart';
import 'models.dart';

/// `alarm` প্যাকেজ (v4.x) দিয়ে ফুল-স্ক্রিন অ্যালার্ম।
class AlarmService {
  static Future<void> init() async {
    try {
      await Alarm.init();
    } catch (_) {}
  }

  static Future<void> scheduleAt(PlanEntry e, DateTime when) async {
    if (when.isBefore(DateTime.now())) return;
    try {
      await Alarm.set(
        alarmSettings: AlarmSettings(
          id: e.alarmId,
          dateTime: when,
          assetAudioPath: 'assets/alarm.wav',
          loopAudio: true,
          vibrate: true,
          volume: 0.9,
          fadeDuration: 3.0,
          notificationSettings: NotificationSettings(
            title: '⏰ ${e.title}',
            body: 'এখনই শুরু করার সময়! ${e.minutes} মিনিটের কাজ।',
          ),
        ),
      );
    } catch (_) {}
  }

  static Future<void> scheduleEntry(PlanEntry e, DateTime date) =>
      scheduleAt(e, DateTime(date.year, date.month, date.day, 0, e.startMin));

  static Future<void> cancel(int id) async {
    try {
      await Alarm.stop(id);
    } catch (_) {}
  }
}
