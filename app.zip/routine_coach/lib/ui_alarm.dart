import 'dart:async';
import 'package:flutter/material.dart';
import 'alarm_service.dart';
import 'assistant.dart';
import 'i18n.dart';
import 'models.dart';
import 'mailo_pet.dart';
import 'state.dart';
import 'theme.dart';

/// অ্যালার্ম বাজলে এই স্ক্রিন আসে। ফোর্স কতটা কড়া, সেটা ইউজারের সেটিং (বা কাজের নিজস্ব সেটিং) ঠিক করে।
class RingScreen extends StatefulWidget {
  final PlanEntry entry;
  const RingScreen({super.key, required this.entry});
  @override
  State<RingScreen> createState() => _RingScreenState();
}

class _RingScreenState extends State<RingScreen> {
  final input = TextEditingController();
  String reply = '';
  bool busy = false;

  PlanEntry get e => widget.entry;

  @override
  void dispose() {
    input.dispose();
    super.dispose();
  }

  Future<void> _ask(String text) async {
    if (text.trim().isEmpty || busy) return;
    setState(() => busy = true);
    final before = assistant.msgs.length;
    await assistant.send(text);
    if (!mounted) return;
    final fresh = assistant.msgs.skip(before).where((m) => !m.user).map((m) => m.text).join('\n');
    input.clear();
    setState(() {
      busy = false;
      reply = fresh;
    });
    final nowMin = DateTime.now().hour * 60 + DateTime.now().minute;
    final moved = e.startMin > nowMin;
    if (e.status != 0 || moved) {
      await Future<void>.delayed(const Duration(milliseconds: 1500));
      if (mounted) Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = app.cfgFor(e);
    final left = c.snoozeMax - e.snoozes;
    return PopScope(
      canPop: !c.blockBack,
      child: Scaffold(
        backgroundColor: const Color(0xFF0B1F5C),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                  child: const MailoPet(size: 150),
                ),
                const SizedBox(height: 16),
                Text(e.title,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.white)),
                const SizedBox(height: 8),
                Text('${fmtMin(e.startMin)} • ${e.minutes} ${L('মিনিট', 'min')}',
                    style: const TextStyle(fontSize: 18, color: Colors.white70)),
                const SizedBox(height: 32),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: const Color(0xFF0B1F5C),
                        padding: const EdgeInsets.symmetric(vertical: 18)),
                    onPressed: () async {
                      await AlarmService.cancel(e.alarmId);
                      if (!context.mounted) return;
                      Navigator.of(context)
                          .pushReplacement(MaterialPageRoute<void>(builder: (_) => FocusScreen(entry: e)));
                    },
                    child: Text(L('শুরু করছি', 'Starting now'), style: const TextStyle(fontSize: 20)),
                  ),
                ),
                const SizedBox(height: 8),
                if (left > 0)
                  TextButton(
                    onPressed: () async {
                      await app.snooze(e);
                      if (context.mounted) Navigator.of(context).pop();
                    },
                    child: Text(
                      L('${c.snoozeMin} মিনিট পরে${c.xpPenalty && app.prefs.useAppRewards ? ' (-৫ XP)' : ''}, আর $left বার',
                          'In ${c.snoozeMin} min${c.xpPenalty && app.prefs.useAppRewards ? ' (-5 XP)' : ''}, $left left'),
                      style: const TextStyle(color: Colors.white70),
                    ),
                  )
                else
                  Text(L('আর স্নুজ নেই। এবার শুরু করুন!', 'No snoozes left. Start now!'),
                      style: TextStyle(color: Pal.light.fire)),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white10,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(L('${app.prefs.assistantName}-কে বলুন', 'Tell ${app.prefs.assistantName}'),
                        style: const TextStyle(color: Colors.white70, fontSize: 13)),
                    const SizedBox(height: 6),
                    TextField(
                      controller: input,
                      style: const TextStyle(color: Colors.white),
                      onSubmitted: _ask,
                      decoration: InputDecoration(
                        hintText: L('যেমন: ৯টায় করব / আজ করব না', 'e.g. do it at 9 / skip today'),
                        hintStyle: const TextStyle(color: Colors.white38),
                        suffixIcon: busy
                            ? const Padding(
                                padding: EdgeInsets.all(12),
                                child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)))
                            : IconButton(
                                icon: const Icon(Icons.send, color: Colors.white70),
                                onPressed: () => _ask(input.text)),
                      ),
                    ),
                    if (reply.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Text(reply, style: const TextStyle(color: Colors.white)),
                      ),
                  ]),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// ফোকাস টাইমার: ফোর্স সেটিং অনুযায়ী একটা শতাংশ সময় না কাটলে "শেষ" চাপা যায় না।
class FocusScreen extends StatefulWidget {
  final PlanEntry entry;
  const FocusScreen({super.key, required this.entry});
  @override
  State<FocusScreen> createState() => _FocusScreenState();
}

class _FocusScreenState extends State<FocusScreen> {
  late final int total = widget.entry.minutes * 60;
  late final DateTime startedAt = DateTime.now();
  int elapsed = 0;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      // ফোন ঘুমিয়ে থাকলেও সঠিক সময় পেতে ঘড়ি থেকে হিসাব
      final s = DateTime.now().difference(startedAt).inSeconds;
      if (s != elapsed && mounted) setState(() => elapsed = s > total ? total : s);
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  String _clock(int s) =>
      '${(s ~/ 60).toString().padLeft(2, '0')}:${(s % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final c = app.cfgFor(widget.entry);
    final need = total * c.lockPct / 100;
    final canFinish = elapsed >= need;
    return PopScope(
      canPop: !c.blockBack,
      child: Scaffold(
        appBar: AppBar(title: Text(widget.entry.title), automaticallyImplyLeading: false),
        body: SafeArea(
         child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                width: 220,
                height: 220,
                child: Stack(alignment: Alignment.center, children: [
                  SizedBox.expand(child: CircularProgressIndicator(value: elapsed / total, strokeWidth: 12)),
                  Text(_clock(total - elapsed), style: const TextStyle(fontSize: 44, fontWeight: FontWeight.bold)),
                ]),
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: canFinish ? _finish : null,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Text(L('শেষ করেছি', 'Done'), style: const TextStyle(fontSize: 18)),
                  ),
                ),
              ),
              if (!canFinish)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(L('কমপক্ষে ${c.lockPct}% সময় পার হলে শেষ করা যাবে',
                      'You can finish after ${c.lockPct}% of the time')),
                ),
              const SizedBox(height: 16),
              TextButton(
                onPressed: _giveUp,
                child: Text(L('ছেড়ে দিচ্ছি${c.xpPenalty && app.prefs.useAppRewards ? ' (-১০ XP)' : ''}', 'Give up${c.xpPenalty && app.prefs.useAppRewards ? ' (-10 XP)' : ''}')),
              ),
            ],
          ),
        ),
        ),
      ),
    );
  }

  Future<void> _finish() async {
    final gain = app.complete(widget.entry);
    final unlocked = List<String>.from(app.lastUnlocked);
    await showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(L('দারুণ!', 'Great job!')),
        content: Text(app.prefs.useAppRewards
            ? '+$gain XP'
                '${unlocked.isEmpty ? '' : '\n\n${L('নতুন অর্জন (+৫০ XP)', 'New achievement (+50 XP)')}:\n${unlocked.join('\n')}'}'
            : L('কাজ শেষ। ${app.prefs.assistantName} খুশি!', 'Task done. ${app.prefs.assistantName} is happy!')),
        actions: [TextButton(onPressed: () => Navigator.pop(c), child: Text(L('ঠিক আছে', 'OK')))],
      ),
    );
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _giveUp() async {
    final c = app.cfgFor(widget.entry);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(L('সত্যিই ছেড়ে দেবেন?', 'Really give up?')),
        content: Text(c.xpPenalty
            ? L('কাজ স্কিপ হবে এবং ১০ XP কাটা যাবে।', 'The task will be skipped and 10 XP deducted.')
            : L('কাজ স্কিপ হবে।', 'The task will be skipped.')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(L('না, চালিয়ে যাই', 'No, continue'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(L('হ্যাঁ', 'Yes'))),
        ],
      ),
    );
    if (ok == true) {
      app.skip(widget.entry);
      if (mounted) Navigator.of(context).pop();
    }
  }
}
