import 'dart:async';
import 'package:flutter/material.dart';
import 'alarm_service.dart';
import 'models.dart';
import 'state.dart';

/// অ্যালার্ম বাজলে এই স্ক্রিন আসে। ব্যাক চাপলে বন্ধ হয় না;
/// শুরু করতে হবে, নয়তো সর্বোচ্চ ২ বার স্নুজ (প্রতিবার -৫ XP)।
class RingScreen extends StatelessWidget {
  final PlanEntry entry;
  const RingScreen({super.key, required this.entry});

  @override
  Widget build(BuildContext context) {
    final left = 2 - entry.snoozes;
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: const Color(0xFF1E1B4B),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.alarm, size: 96, color: Colors.amber),
                const SizedBox(height: 16),
                Text(entry.title,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 32, fontWeight: FontWeight.bold, color: Colors.white)),
                const SizedBox(height: 8),
                Text('${fmtMin(entry.startMin)} • ${entry.minutes} মিনিট',
                    style: const TextStyle(fontSize: 18, color: Colors.white70)),
                const SizedBox(height: 40),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 18)),
                    onPressed: () async {
                      await AlarmService.cancel(entry.alarmId);
                      if (!context.mounted) return;
                      Navigator.of(context).pushReplacement(
                          MaterialPageRoute(builder: (_) => FocusScreen(entry: entry)));
                    },
                    child: const Text('শুরু করছি 💪', style: TextStyle(fontSize: 20)),
                  ),
                ),
                const SizedBox(height: 12),
                if (left > 0)
                  TextButton(
                    onPressed: () async {
                      await app.snooze(entry);
                      if (context.mounted) Navigator.of(context).pop();
                    },
                    child: Text('১০ মিনিট পরে (-৫ XP, আর $leftবার)',
                        style: const TextStyle(color: Colors.white70)),
                  )
                else
                  const Text('আর স্নুজ নেই — এবার শুরু করুন!',
                      style: TextStyle(color: Colors.amber)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// ফোকাস টাইমার: কমপক্ষে ৮০% সময় না কাটলে "শেষ" চাপা যায় না।
class FocusScreen extends StatefulWidget {
  final PlanEntry entry;
  const FocusScreen({super.key, required this.entry});
  @override
  State<FocusScreen> createState() => _FocusScreenState();
}

class _FocusScreenState extends State<FocusScreen> {
  late final int total = widget.entry.minutes * 60;
  int elapsed = 0;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (elapsed < total) setState(() => elapsed++);
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  String _clock(int s) =>
      '${(s ~/ 60).toString().padLeft(2, '0')}:${(s % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final canFinish = elapsed >= total * 0.8;
    return PopScope(
      canPop: false,
      child: Scaffold(
        appBar: AppBar(title: Text(widget.entry.title), automaticallyImplyLeading: false),
        body: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                width: 220,
                height: 220,
                child: Stack(alignment: Alignment.center, children: [
                  SizedBox.expand(
                    child: CircularProgressIndicator(value: elapsed / total, strokeWidth: 12),
                  ),
                  Text(_clock(total - elapsed),
                      style: const TextStyle(fontSize: 44, fontWeight: FontWeight.bold)),
                ]),
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: canFinish ? _finish : null,
                  child: const Padding(
                    padding: EdgeInsets.all(12),
                    child: Text('শেষ করেছি ✅', style: TextStyle(fontSize: 18)),
                  ),
                ),
              ),
              if (!canFinish)
                const Padding(
                  padding: EdgeInsets.only(top: 8),
                  child: Text('কমপক্ষে ৮০% সময় পার হলে শেষ করা যাবে'),
                ),
              const SizedBox(height: 16),
              TextButton(onPressed: _giveUp, child: const Text('ছেড়ে দিচ্ছি (-১০ XP)')),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _finish() async {
    final gain = app.complete(widget.entry);
    final unlocked = List<String>.from(app.lastUnlocked);
    await showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('দারুণ! 🎉'),
        content: Text('+$gain XP পেয়েছেন'
            '${unlocked.isEmpty ? '' : '\n\nনতুন অর্জন (+৫০ XP):\n${unlocked.join('\n')}'}'),
        actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('ঠিক আছে'))],
      ),
    );
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _giveUp() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('সত্যিই ছেড়ে দেবেন?'),
        content: const Text('কাজ স্কিপ হবে এবং ১০ XP কাটা যাবে।'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('না, চালিয়ে যাই')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('হ্যাঁ')),
        ],
      ),
    );
    if (ok == true) {
      app.skip(widget.entry);
      if (mounted) Navigator.of(context).pop();
    }
  }
}
