import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'state.dart';

/// Mailo: লোগোর "M"-এ দুটো চোখ। সব জায়গায় একই চেহারা, একই অ্যাসেট।
/// ১০ সেকেন্ডের চক্রে ৫ রকম নড়াচড়া: দম নেওয়া, লাফ, নাচ, তাকানো, আড়মোড়া।
/// [animate] = false হলে স্থির (শুধু মাঝে মাঝে চোখ পিটপিট করে না, একদম স্থির)।
/// [blinkOnly] = true হলে শুধু চোখ পিটপিট করে (ছোট জায়গার জন্য, ফোন কম খাটে)।
class MailoPet extends StatefulWidget {
  final double size; // মাসকটের প্রস্থ
  final bool animate;
  final bool blinkOnly;
  const MailoPet({super.key, this.size = 120, this.animate = true, this.blinkOnly = false});

  @override
  State<MailoPet> createState() => _MailoPetState();
}

class _PetPose {
  double sx = 1, sy = 1, dy = 0, rot = 0, aL = 0, aR = 0, open = 1, happy = 0, px = 0, py = 0;
}

double _ease(double x) {
  final v = x.clamp(0.0, 1.0);
  return v * v * (3 - 2 * v);
}

double _seg(double t, double a, double b) => _ease((t - a) / (b - a));
double _pulse(double t, double c, double w) => math.max(0.0, 1 - (t - c).abs() / w);

_PetPose _poseAt(double t, {bool blinkOnly = false}) {
  final s = _PetPose();
  if (blinkOnly) {
    // ৪ সেকেন্ডের চক্র, ৩ সেকেন্ডে একবার পিটপিট
    final k = t % 4.0;
    s.open = 1 - math.min(1.0, _pulse(k, 3.0, 0.09) * 1.4);
    return s;
  }
  t = t % 10.0;
  final br = math.sin(t * 2 * math.pi / 2.4);
  s.sy = 1 + 0.015 * br;
  s.sx = 1 - 0.01 * br;
  for (final c in const [1.2, 5.9, 8.1, 8.45]) {
    s.open = math.min(s.open, 1 - math.min(1.0, _pulse(t, c, 0.09) * 1.4));
  }
  // লাফ ২.০–৩.৫
  if (t >= 2.0 && t < 3.5) {
    final u = t - 2.0;
    if (u < 0.3) {
      final k = _ease(u / 0.3);
      s.sy = 1 - 0.14 * k;
      s.sx = 1 + 0.10 * k;
      s.aL = -3 * k;
      s.aR = 3 * k;
    } else if (u < 0.9) {
      final k = (u - 0.3) / 0.6;
      final w = math.sin(math.pi * k);
      s.dy = -95 * w;
      s.sy = 1 + 0.10 * w;
      s.sx = 1 - 0.06 * w;
      s.aL = -9 * w;
      s.aR = 9 * w;
      s.happy = 1;
    } else if (u < 1.2) {
      final k = (u - 0.9) / 0.3;
      final w = math.sin(math.pi * k);
      s.sy = 1 - 0.16 * w;
      s.sx = 1 + 0.12 * w;
      s.happy = 1 - k;
    } else {
      final k = (u - 1.2) / 0.3;
      s.sy = 1 + 0.03 * math.sin(math.pi * k * 2) * (1 - k);
    }
  }
  // নাচ ৪.০–৬.৬
  if (t >= 4.0 && t < 6.6) {
    final u = t - 4.0;
    final f = _seg(u, 0, 0.3) * (1 - _seg(u, 2.3, 2.6));
    final ph = u * 2 * math.pi / 0.9;
    s.rot = 7 * math.sin(ph) * f;
    s.aL = -8 * math.max(0.0, math.sin(ph)) * f + 2 * f;
    s.aR = 8 * math.max(0.0, -math.sin(ph)) * f - 2 * f;
    s.dy = -10 * math.sin(ph).abs() * f;
    s.happy = (u > 0.6 && u < 2.2) ? 0.7 * f : 0;
  }
  // তাকানো ৬.৮–৮.৩
  if (t >= 6.8 && t < 8.3) {
    final u = t - 6.8;
    s.px = 14 * math.sin(u * 2 * math.pi / 1.5) * _ease(math.min(1.0, u / 0.3));
    s.py = -4 * math.sin(u * 2 * math.pi / 1.5);
    s.rot = 2.5 * math.sin(u * 2 * math.pi / 1.5);
  }
  // আড়মোড়া ৮.৭–১০
  if (t >= 8.7) {
    final u = t - 8.7;
    final k = math.sin(math.pi * math.min(1.0, u / 1.3));
    s.sy = 1 + 0.06 * k;
    s.sx = 1 - 0.04 * k;
    s.aL = -3 * k;
    s.aR = 3 * k;
  }
  return s;
}

class _MailoPetState extends State<MailoPet> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 10));
  bool _running = false;

  bool get _wantAnim =>
      widget.animate && app.prefs.animations && !MediaQuery.of(context).disableAnimations;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _sync();
  }

  @override
  void didUpdateWidget(MailoPet old) {
    super.didUpdateWidget(old);
    _sync();
  }

  void _sync() {
    final want = _wantAnim;
    if (want && !_running) {
      _c.repeat();
      _running = true;
    } else if (!want && _running) {
      _c.stop();
      _running = false;
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final w = widget.size;
    final k = w / 1050.0; // মূল লোগো-মার্কের প্রস্থ ১০৫০ ধরে হিসাব
    final markH = w * 356 / 700;
    final head = 120 * k; // লাফের জন্য ওপরে জায়গা
    final foot = 40 * k; // ছায়ার জন্য নিচে জায়গা
    return SizedBox(
      width: w,
      height: markH + head + foot,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          final t = _c.value * 10.0;
          final pose = _running
              ? _poseAt(widget.blinkOnly ? _c.value * 10.0 : t, blinkOnly: widget.blinkOnly)
              : _PetPose();
          return _frame(context, pose, w, markH, head, k);
        },
      ),
    );
  }

  Widget _frame(BuildContext context, _PetPose s, double w, double markH, double head, double k) {
    const pivot = Alignment(0.1, 0.1); // (0.55, 0.55) জোড়ার বিন্দু
    const ground = Alignment(0, 0.94);
    final shadowK = math.max(0.4, 1 + s.dy / 200);
    Widget leg(String asset, double angle, Offset eye, bool flip) {
      return Transform.rotate(
        angle: -angle * math.pi / 180,
        alignment: pivot,
        child: SizedBox(
          width: w,
          height: markH,
          child: Stack(children: [
            Positioned.fill(child: Image.asset(asset, fit: BoxFit.fill, filterQuality: FilterQuality.medium)),
            Positioned.fill(
              child: CustomPaint(
                painter: _EyePainter(
                  center: Offset(eye.dx * w, eye.dy * markH),
                  k: k,
                  open: s.open,
                  happy: s.happy,
                  px: s.px,
                  py: s.py,
                  tilt: flip ? 14 : -14,
                ),
              ),
            ),
          ]),
        ),
      );
    }

    final body = SizedBox(
      width: w,
      height: markH,
      child: Stack(children: [
        leg('assets/mailo_leg_right.png', s.aR, const Offset(0.635, 0.385), true),
        leg('assets/mailo_leg_left.png', s.aL, const Offset(0.385, 0.41), false),
      ]),
    );

    return Stack(clipBehavior: Clip.none, children: [
      // ছায়া
      Positioned(
        left: w * 0.5 - (w * 0.55 * shadowK) / 2,
        top: head + markH * 0.97 + 14 * k,
        child: Container(
          width: w * 0.55 * shadowK,
          height: 20 * k,
          decoration: BoxDecoration(
            color: const Color(0xFF0B1F5C).withAlpha(38),
            borderRadius: BorderRadius.circular(100),
          ),
        ),
      ),
      Positioned(
        left: 0,
        top: head,
        child: Transform.translate(
          offset: Offset(0, s.dy * k),
          child: Transform.rotate(
            angle: -s.rot * math.pi / 180,
            alignment: ground,
            child: Transform(
              transform: Matrix4.diagonal3Values(s.sx, s.sy, 1),
              alignment: ground,
              child: body,
            ),
          ),
        ),
      ),
    ]);
  }
}

class _EyePainter extends CustomPainter {
  final Offset center;
  final double k, open, happy, px, py, tilt;
  _EyePainter({
    required this.center,
    required this.k,
    required this.open,
    required this.happy,
    required this.px,
    required this.py,
    required this.tilt,
  });

  static const navy = Color(0xFF0B1F5C);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(tilt * math.pi / 180);
    canvas.scale(k, k);
    final paint = Paint()..color = navy..isAntiAlias = true;
    if (happy > 0.5) {
      final p = Paint()
        ..color = navy
        ..style = PaintingStyle.stroke
        ..strokeWidth = 13
        ..strokeCap = StrokeCap.round
        ..isAntiAlias = true;
      canvas.drawArc(const Rect.fromLTRB(-42, -16, 42, 46), math.pi * 1.1, math.pi * 0.78, false, p);
    } else {
      final o = open.clamp(0.0, 1.0);
      final ry = 52 * o;
      if (ry < 6) {
        final p = Paint()
          ..color = navy
          ..strokeWidth = 8
          ..strokeCap = StrokeCap.round;
        canvas.drawLine(const Offset(-38, 8), const Offset(38, 8), p);
      } else {
        canvas.drawOval(Rect.fromLTRB(-38, -ry, 38, ry), paint);
        final hx = px * 0.5, hy = py * 0.5;
        final r1 = 13 * math.sqrt(o);
        canvas.drawCircle(Offset(9 + hx, -ry * 0.45 + hy), r1, Paint()..color = Colors.white);
        final r2 = 6 * math.sqrt(o);
        canvas.drawCircle(
            Offset(-10 + hx, ry * 0.45 + hy), r2, Paint()..color = const Color(0xC8FFFFFF));
      }
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _EyePainter o) =>
      o.open != open || o.happy != happy || o.px != px || o.py != py || o.center != center || o.k != k;
}
