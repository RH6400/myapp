import 'package:flutter/material.dart';

// Mailo রঙ: নীল (প্রধান) + কমলা (উচ্ছ্বাস) + গাঢ় নেভি (লেখা)
const kBlue = Color(0xFF2563EB);
const kOrange = Color(0xFFFF8A00);
const kNavy = Color(0xFF0B1B5C);
const kGreen = Color(0xFF16A34A);
const kRed = Color(0xFFDC2626);

ThemeData mailoTheme(Brightness b) {
  final dark = b == Brightness.dark;
  final primary = dark ? const Color(0xFF6B93FF) : kBlue;
  final bg = dark ? const Color(0xFF0A1020) : const Color(0xFFF4F6FC);
  final card = dark ? const Color(0xFF141B2E) : Colors.white;
  final text = dark ? const Color(0xFFE8ECFA) : kNavy;
  final cs = ColorScheme.fromSeed(seedColor: kBlue, brightness: b).copyWith(
    primary: primary,
    onPrimary: dark ? const Color(0xFF0A1020) : Colors.white,
    primaryContainer: dark ? const Color(0xFF1E2A4F) : const Color(0xFFE6EDFF),
    onPrimaryContainer: dark ? const Color(0xFFDCE5FF) : kBlue,
    secondary: kOrange,
    surface: bg,
    onSurface: text,
    surfaceContainerLow: card,
    surfaceContainer: card,
    surfaceContainerHigh: card,
    surfaceContainerHighest: dark ? const Color(0xFF1B2440) : const Color(0xFFE9EDF8),
    outlineVariant: dark ? const Color(0xFF26304D) : const Color(0xFFE3E8F5),
  );
  return ThemeData(
    useMaterial3: true,
    brightness: b,
    colorScheme: cs,
    scaffoldBackgroundColor: bg,
    canvasColor: bg,
    appBarTheme: AppBarTheme(
      backgroundColor: bg,
      foregroundColor: text,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: card,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      height: 68,
      indicatorColor: cs.primaryContainer,
      labelTextStyle: WidgetStateProperty.resolveWith((st) => TextStyle(
            fontSize: 11,
            fontWeight: st.contains(WidgetState.selected) ? FontWeight.w700 : FontWeight.w500,
            color: st.contains(WidgetState.selected) ? primary : cs.onSurfaceVariant,
          )),
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: primary,
      foregroundColor: cs.onPrimary,
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    ),
    chipTheme: ChipThemeData(
      shape: const StadiumBorder(),
      side: BorderSide(color: cs.outlineVariant),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: card,
      surfaceTintColor: Colors.transparent,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
    ),
    dialogTheme: DialogThemeData(
      backgroundColor: card,
      surfaceTintColor: Colors.transparent,
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.all(Colors.white),
      trackColor: WidgetStateProperty.resolveWith(
          (st) => st.contains(WidgetState.selected) ? primary : cs.surfaceContainerHighest),
      trackOutlineColor: WidgetStateProperty.all(Colors.transparent),
    ),
  );
}
