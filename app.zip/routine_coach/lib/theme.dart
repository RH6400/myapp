import 'package:flutter/material.dart';

/// Mailo-র রঙের নিয়ম: একটাই মূল নীল, কমলা শুধু স্ট্রিক/XP, সবুজ শুধু শেষ হওয়া কাজ, লাল শুধু সতর্কতা।
class Pal {
  final Color bg, card, tx, sub, line, pri, priSoft, ok, okSoft, bad, badSoft, fire, fireSoft, nav;
  final Brightness brightness;
  const Pal({
    required this.brightness,
    required this.bg,
    required this.card,
    required this.tx,
    required this.sub,
    required this.line,
    required this.pri,
    required this.priSoft,
    required this.ok,
    required this.okSoft,
    required this.bad,
    required this.badSoft,
    required this.fire,
    required this.fireSoft,
    required this.nav,
  });

  static const light = Pal(
    brightness: Brightness.light,
    bg: Color(0xFFF4F6FC),
    card: Color(0xFFFFFFFF),
    tx: Color(0xFF0B1F5C),
    sub: Color(0xFF667085),
    line: Color(0xFFE4E8F2),
    pri: Color(0xFF2457E6),
    priSoft: Color(0xFFE9EFFF),
    ok: Color(0xFF16A34A),
    okSoft: Color(0xFFE8F7EE),
    bad: Color(0xFFDC2626),
    badSoft: Color(0xFFFDECEC),
    fire: Color(0xFFFF8A00),
    fireSoft: Color(0xFFFFF2DE),
    nav: Color(0xFFFFFFFF),
  );

  static const dark = Pal(
    brightness: Brightness.dark,
    bg: Color(0xFF0B1020),
    card: Color(0xFF141A2E),
    tx: Color(0xFFEEF2FF),
    sub: Color(0xFF98A2B8),
    line: Color(0xFF232B45),
    pri: Color(0xFF6E96FF),
    priSoft: Color(0xFF1C2A5C),
    ok: Color(0xFF4ADE80),
    okSoft: Color(0xFF15301F),
    bad: Color(0xFFF87171),
    badSoft: Color(0xFF3A1C1C),
    fire: Color(0xFFFB923C),
    fireSoft: Color(0xFF3A2412),
    nav: Color(0xFF0F1528),
  );

  static Pal of(BuildContext c) =>
      Theme.of(c).brightness == Brightness.dark ? dark : light;

  /// বাটনের ওপরের লেখার রং (মূল রঙের ওপর)।
  Color get onPri => brightness == Brightness.dark ? const Color(0xFF0B1020) : Colors.white;
}

ThemeData buildTheme(Brightness b) {
  final p = b == Brightness.dark ? Pal.dark : Pal.light;
  final base = ColorScheme.fromSeed(seedColor: p.pri, brightness: b);
  final cs = base.copyWith(
    primary: p.pri,
    onPrimary: p.onPri,
    primaryContainer: p.priSoft,
    onPrimaryContainer: p.pri,
    secondary: p.fire,
    surface: p.card,
    onSurface: p.tx,
    onSurfaceVariant: p.sub,
    surfaceContainerHighest: p.priSoft,
    outline: p.line,
    outlineVariant: p.line,
    error: p.bad,
    errorContainer: p.badSoft,
    onErrorContainer: p.bad,
  );
  return ThemeData(
    useMaterial3: true,
    brightness: b,
    colorScheme: cs,
    scaffoldBackgroundColor: p.bg,
    canvasColor: p.bg,
    dividerColor: p.line,
    appBarTheme: AppBarTheme(
      backgroundColor: p.bg,
      foregroundColor: p.tx,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(color: p.tx, fontSize: 20, fontWeight: FontWeight.w700),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: p.nav,
      indicatorColor: p.priSoft,
      elevation: 0,
      height: 66,
      labelTextStyle: WidgetStateProperty.resolveWith((states) {
        final sel = states.contains(WidgetState.selected);
        return TextStyle(
          fontSize: 11,
          fontWeight: sel ? FontWeight.w700 : FontWeight.w500,
          color: sel ? p.pri : p.sub,
        );
      }),
      iconTheme: WidgetStateProperty.resolveWith((states) {
        final sel = states.contains(WidgetState.selected);
        return IconThemeData(color: sel ? p.pri : p.sub, size: 24);
      }),
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: p.pri,
      foregroundColor: p.onPri,
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: p.pri,
        foregroundColor: p.onPri,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        textStyle: const TextStyle(fontWeight: FontWeight.w600),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: p.pri,
        side: BorderSide(color: p.line),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(foregroundColor: p.pri),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: p.card,
      selectedColor: p.priSoft,
      side: BorderSide(color: p.line),
      labelStyle: TextStyle(color: p.sub, fontWeight: FontWeight.w500, fontSize: 13),
      secondaryLabelStyle: TextStyle(color: p.pri, fontWeight: FontWeight.w600, fontSize: 13),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      showCheckmark: false,
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.selected) ? Colors.white : Colors.white),
      trackColor: WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.selected) ? p.pri : p.line),
      trackOutlineColor: WidgetStateProperty.resolveWith((s) => Colors.transparent),
    ),
    sliderTheme: SliderThemeData(activeTrackColor: p.pri, thumbColor: p.pri, inactiveTrackColor: p.line),
    progressIndicatorTheme: ProgressIndicatorThemeData(color: p.pri, linearTrackColor: p.line),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: p.tx,
      contentTextStyle: TextStyle(color: p.bg),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
  );
}
