import 'dart:convert';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'alarm_service.dart';
import 'cloud.dart';
import 'i18n.dart';
import 'models.dart';
import 'notif.dart';
import 'planner.dart';

class Achievement {
  final String id, icon;
  final int target;
  final int Function(AppState) value;
  const Achievement(this.id, this.icon, this.target, this.value);
}

final achievementList = <Achievement>[
  Achievement('first', '🌱', 1, (s) => s.totalDone),
  Achievement('ten', '🎯', 10, (s) => s.totalDone),
  Achievement('fifty', '🏆', 50, (s) => s.totalDone),
  Achievement('s3', '🔥', 3, (s) => s.streak),
  Achievement('s7', '⚡', 7, (s) => s.streak),
  Achievement('xp500', '💎', 500, (s) => s.xp),
  Achievement('h10', '⏳', 10, (s) => s.totalMinutes ~/ 60),
];

/// একটি অপারেশনের ফল (যেমন কাজ যোগ বা সরানো)।
class OpResult {
  final bool ok;
  final List<PlanEntry> conflicts;
  final int? suggestion;
  final String? error; // 'past' | 'range' | 'notfound'
  const OpResult(this.ok, {this.conflicts = const [], this.suggestion, this.error});
}

/// পুরো অ্যাপের একটাই স্টেট।
final app = AppState();

class AppState extends ChangeNotifier {
  SharedPreferences? _p;

  List<TaskItem> tasks = [];
  List<TimeWindow> windows = [TimeWindow(18 * 60, 22 * 60)];
  Map<String, List<PlanEntry>> plans = {};
  int xp = 0;
  Set<String> unlocked = {};
  Prefs prefs = Prefs();
  int updatedAt = 0; // সর্বশেষ বদলের সময় (ক্লাউডের সাথে মেলাতে)

  List<String> lastUnlocked = [];
  List<TaskItem> unplaced = [];
  DateTime? _lastReplan;

  String get lang => prefs.lang;

  // ---------- লোড / সেভ ----------
  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    final raw = _p!.getString('state');
    if (raw == null) {
      _defaults();
      return;
    }
    try {
      importJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      _defaults();
    }
  }

  void _defaults() {
    tasks = [
      TaskItem(id: 't1', title: t('sample.1'), category: 'পড়াশোনা', minutes: 60, priority: 3, part: 3),
      TaskItem(id: 't2', title: t('sample.2'), category: 'ব্যায়াম', minutes: 30, priority: 2, part: 1),
      TaskItem(id: 't3', title: t('sample.3'), category: 'দক্ষতা', minutes: 45, priority: 2, part: 3),
    ];
    windows = [TimeWindow(18 * 60, 22 * 60)];
    plans = {};
    xp = 0;
    unlocked = {};
    updatedAt = 0;
  }

  Map<String, dynamic> exportJson({bool forCloud = false}) {
    final pj = prefs.toJson();
    if (forCloud) pj.remove('geminiKey');
    // পুরোনো দিনের প্ল্যান ছেঁটে ফেলা (৪৫ দিনের বেশি)
    final cutoff = dateKey(DateTime.now().subtract(const Duration(days: 45)));
    final keep = plans.entries.where((e) => e.key.compareTo(cutoff) >= 0);
    return {
      'tasks': tasks.map((e) => e.toJson()).toList(),
      'windows': windows.map((e) => e.toJson()).toList(),
      'plans': {for (final e in keep) e.key: e.value.map((x) => x.toJson()).toList()},
      'xp': xp,
      'unlocked': unlocked.toList(),
      'prefs': pj,
      'updatedAt': updatedAt,
    };
  }

  void importJson(Map<String, dynamic> j, {bool fromCloud = false}) {
    final localKey = prefs.geminiKey;
    tasks = ((j['tasks'] as List?) ?? const [])
        .map((e) => TaskItem.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
    final ws = ((j['windows'] as List?) ?? const [])
        .map((e) => TimeWindow.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
    windows = ws.isEmpty ? [TimeWindow(18 * 60, 22 * 60)] : ws;
    final pl = (j['plans'] as Map?) ?? const {};
    plans = {
      for (final k in pl.keys)
        k.toString(): ((pl[k] as List))
            .map((e) => PlanEntry.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList()
    };
    xp = (j['xp'] as num?)?.toInt() ?? 0;
    unlocked = ((j['unlocked'] as List?) ?? const []).map((e) => e.toString()).toSet();
    updatedAt = (j['updatedAt'] as num?)?.toInt() ?? 0;
    final pj = j['prefs'];
    if (pj is Map) {
      prefs.loadJson(Map<String, dynamic>.from(pj));
    } else {
      // পুরোনো ভার্সনের ডাটা
      prefs.geminiKey = (j['key'] as String?) ?? prefs.geminiKey;
      prefs.geminiModel = (j['model'] as String?) ?? prefs.geminiModel;
    }
    if (fromCloud && localKey.isNotEmpty) prefs.geminiKey = localKey;
    if (prefs.categories.isEmpty) prefs.categories = List<String>.from(defaultCategories);
    gLang = prefs.lang;
    final today = dateKey(DateTime.now());
    tasks.removeWhere((x) => x.onDate != null && x.onDate!.compareTo(today) < 0);
    if (fromCloud) _save();
  }

  void _save() {
    _p?.setString('state', jsonEncode(exportJson()));
  }

  void _commit({bool touch = true}) {
    if (touch) updatedAt = DateTime.now().millisecondsSinceEpoch;
    gLang = prefs.lang;
    _save();
    notifyListeners();
    cloud.pushSoon();
    notif.refreshSoon();
  }

  /// লগআউটের পর এই ফোনের ডাটা মুছে ফেলা (ক্লাউডে থাকে)।
  Future<void> resetLocal() async {
    await AlarmService.cancelAll();
    final lang = prefs.lang;
    final theme = prefs.theme;
    prefs = Prefs()
      ..lang = lang
      ..theme = theme
      ..onboarded = false;
    _defaults();
    _save();
    notifyListeners();
  }

  // ---------- সেটিংস ----------
  Future<void> savePrefs({bool replanNow = false}) async {
    if (replanNow) {
      await replan(force: true);
    }
    _commit();
  }

  // ---------- কাজ ও সময় ----------
  Future<void> addTask(TaskItem t) async {
    tasks.add(t);
    await replan(force: true);
    _commit();
  }

  Future<void> removeTask(String id) async {
    tasks.removeWhere((t) => t.id == id);
    await replan(force: true);
    _commit();
  }

  Future<void> setWindows(List<TimeWindow> w) async {
    windows = w;
    await replan(force: true);
    _commit();
  }

  // ---------- রুটিন ----------
  List<PlanEntry> entriesFor(DateTime d) => plans[dateKey(d)] ?? <PlanEntry>[];

  Iterable<PlanEntry> get allEntries => plans.values.expand((l) => l);

  PlanEntry? findPendingByAlarm(int alarmId) {
    for (final e in allEntries) {
      if (e.alarmId == alarmId && e.status == 0) return e;
    }
    return null;
  }

  DateTime? dateOf(PlanEntry e) {
    for (final k in plans.keys) {
      if (plans[k]!.contains(e)) return DateTime.parse(k);
    }
    return null;
  }

  PlanEntry _mkEntry(TaskItem t, int start, {bool fixed = false}) => PlanEntry(
        id: '${t.id}-${DateTime.now().microsecondsSinceEpoch}',
        taskId: t.id,
        title: t.title,
        category: t.category,
        priority: t.priority,
        startMin: start,
        minutes: t.minutes,
        fixed: fixed,
        alert: t.alert,
        force: t.force,
      );

  int _nextAlarmN(Set<int> used) {
    for (var n = 0; n < 99; n++) {
      if (!used.contains(n)) {
        used.add(n);
        return n;
      }
    }
    return 99;
  }

  /// আজ থেকে ৭ দিনের রুটিন ও অ্যালার্ম সাজায়।
  Future<void> replan({bool force = false}) async {
    final now = DateTime.now();
    if (!force && _lastReplan != null && now.difference(_lastReplan!).inMinutes < 5) return;
    _lastReplan = now;
    for (var i = 0; i < 7; i++) {
      await _genDay(DateTime(now.year, now.month, now.day + i));
    }
    final today = dateKey(now);
    tasks.removeWhere((x) => x.onDate != null && x.onDate!.compareTo(today) < 0);
    _commit(touch: false);
  }

  Future<void> _genDay(DateTime date) async {
    final now = DateTime.now();
    final key = dateKey(date);
    final isToday = key == dateKey(now);
    final nowMin = now.hour * 60 + now.minute;
    final existing = plans[key] ?? <PlanEntry>[];

    final kept = <PlanEntry>[];
    for (final e in existing) {
      final taskAlive = tasks.any((t) => t.id == e.taskId);
      final started = isToday && e.startMin <= nowMin;
      final keep = e.status != 0 || ((e.pinned || started) && taskAlive);
      if (keep) {
        kept.add(e);
      } else {
        await AlarmService.cancel(e.alarmId);
      }
    }

    final used = kept.map((e) => e.alarmId % 100).toSet();
    final keptTaskIds = kept.map((e) => e.taskId).toSet();
    final off = prefs.offDay != 0 && date.weekday == prefs.offDay;
    final todo = off
        ? <TaskItem>[]
        : tasks.where((t) => t.activeOn(date) && !keptTaskIds.contains(t.id)).toList();

    final busy = <TimeWindow>[
      for (final e in kept)
        if (e.status != 3) TimeWindow(e.startMin, e.startMin + e.minutes)
    ];
    final fresh = <PlanEntry>[];

    for (final t in todo.where((t) => t.fixedMin != null)) {
      final st = t.fixedMin!;
      if (isToday && st <= nowMin) continue;
      fresh.add(_mkEntry(t, st, fixed: true));
      busy.add(TimeWindow(st, st + t.minutes));
    }

    final autos = todo.where((t) => t.fixedMin == null).toList();
    final notBefore = isToday ? ((nowMin + 5 + 4) ~/ 5) * 5 : 0;
    final res = buildPlan(autos, windows, busy: busy, notBefore: notBefore);
    fresh.addAll(res.entries);
    if (isToday) unplaced = res.unplaced;

    for (final e in fresh) {
      e.alarmId = dateInt(date) * 100 + _nextAlarmN(used);
      await AlarmService.scheduleEntry(e, date, prefs);
    }
    final all = <PlanEntry>[...kept, ...fresh];
    all.sort((a, b) => a.startMin.compareTo(b.startMin));
    plans[key] = all;
  }

  // ---------- সংঘর্ষ যাচাই ও সরানো (সহকারী ও UI দুজনেই ব্যবহার করে) ----------
  List<PlanEntry> conflictsFor(DateTime date, int start, int minutes, {String? ignoreId}) {
    return entriesFor(date)
        .where((e) =>
            e.id != ignoreId &&
            (e.status == 0 || e.status == 1) &&
            e.startMin < start + minutes &&
            start < e.startMin + e.minutes)
        .toList();
  }

  int? suggestSlot(DateTime date, int minutes, int from, {String? ignoreId}) {
    final now = DateTime.now();
    var start = from;
    if (dateKey(date) == dateKey(now)) {
      final nm = ((now.hour * 60 + now.minute + 5 + 4) ~/ 5) * 5;
      if (start < nm) start = nm;
    }
    final busy = <TimeWindow>[
      for (final e in entriesFor(date))
        if (e.id != ignoreId && (e.status == 0 || e.status == 1))
          TimeWindow(e.startMin, e.startMin + e.minutes)
    ];
    return findFreeSlot(minutes, start, busy);
  }

  /// কাজটা যে দিনে প্রথম বাজবে সেই দিন (আজ সময় পার হয়ে গেলে পরের দিন)।
  DateTime? nextOccurrence(TaskItem t) {
    final now = DateTime.now();
    for (var i = 0; i < 7; i++) {
      final d = DateTime(now.year, now.month, now.day + i);
      if (!t.activeOn(d)) continue;
      if (i == 0 && t.fixedMin != null && t.fixedMin! <= now.hour * 60 + now.minute) continue;
      return d;
    }
    return null;
  }

  Future<OpResult> addTaskChecked(TaskItem t, {bool force = false}) async {
    if (t.fixedMin != null && !force) {
      final d = nextOccurrence(t);
      if (d != null) {
        final c = conflictsFor(d, t.fixedMin!, t.minutes);
        if (c.isNotEmpty) {
          return OpResult(false,
              conflicts: c, suggestion: suggestSlot(d, t.minutes, t.fixedMin!));
        }
      }
    }
    await addTask(t);
    return const OpResult(true);
  }

  Future<OpResult> moveEntry(PlanEntry e, int newStart, {bool force = false}) async {
    final d = dateOf(e);
    if (d == null) return const OpResult(false, error: 'notfound');
    final now = DateTime.now();
    if (dateKey(d) == dateKey(now) && newStart <= now.hour * 60 + now.minute) {
      return const OpResult(false, error: 'past');
    }
    if (newStart < 0 || newStart + e.minutes > 24 * 60) {
      return const OpResult(false, error: 'range');
    }
    if (!force) {
      final c = conflictsFor(d, newStart, e.minutes, ignoreId: e.id);
      if (c.isNotEmpty) {
        return OpResult(false,
            conflicts: c, suggestion: suggestSlot(d, e.minutes, newStart, ignoreId: e.id));
      }
    }
    await AlarmService.cancel(e.alarmId);
    e.startMin = newStart;
    e.pinned = true;
    e.snoozes = 0;
    await AlarmService.scheduleEntry(e, d, prefs);
    plans[dateKey(d)]!.sort((a, b) => a.startMin.compareTo(b.startMin));
    _commit();
    return const OpResult(true);
  }

  Future<OpResult> delayEntry(PlanEntry e, int minutes) {
    final now = DateTime.now();
    final d = dateOf(e);
    var base = e.startMin;
    if (d != null && dateKey(d) == dateKey(now)) {
      final nm = ((now.hour * 60 + now.minute + 4) ~/ 5) * 5;
      if (base < nm) base = nm;
    }
    return moveEntry(e, base + minutes);
  }

  /// "আজ করব না": জরিমানা ছাড়া আজকের জন্য বাদ।
  Future<void> skipToday(PlanEntry e) async {
    e.status = 3;
    await AlarmService.cancel(e.alarmId);
    _commit();
  }

  // ---------- কাজের ফলাফল ----------
  ForceConfig cfgFor(PlanEntry e) => prefs.resolveForce(e.force);

  int complete(PlanEntry e) {
    e.status = 1;
    AlarmService.cancel(e.alarmId);
    final gain = e.minutes + e.priority * 10;
    xp += gain;
    _checkUnlocks();
    _commit();
    return gain;
  }

  void skip(PlanEntry e) {
    e.status = 2;
    AlarmService.cancel(e.alarmId);
    if (cfgFor(e).xpPenalty) xp = max(0, xp - 10);
    _commit();
  }

  Future<bool> snooze(PlanEntry e) async {
    final c = cfgFor(e);
    if (e.snoozes >= c.snoozeMax) return false;
    e.snoozes++;
    if (c.xpPenalty) xp = max(0, xp - 5);
    await AlarmService.cancel(e.alarmId);
    await AlarmService.scheduleAt(e, DateTime.now().add(Duration(minutes: c.snoozeMin)), prefs);
    _commit();
    return true;
  }

  void _checkUnlocks() {
    lastUnlocked = [];
    for (final a in achievementList) {
      if (!unlocked.contains(a.id) && a.value(this) >= a.target) {
        unlocked.add(a.id);
        xp += 50;
        lastUnlocked.add('${a.icon} ${t('ach.${a.id}.t')}');
      }
    }
  }

  // ---------- পরিসংখ্যান ----------
  int get totalDone => allEntries.where((e) => e.status == 1).length;
  int get totalMinutes =>
      allEntries.where((e) => e.status == 1).fold(0, (s, e) => s + e.minutes);
  int get level => xp ~/ 200 + 1;
  int get xpIntoLevel => xp % 200;

  bool _dayOk(DateTime d) {
    final l = (plans[dateKey(d)] ?? <PlanEntry>[]).where((e) => e.status != 3).toList();
    if (l.isEmpty) return false;
    final done = l.where((e) => e.status == 1).length;
    return done > 0 && done / l.length >= 0.7;
  }

  int get streak {
    var d = DateTime.now();
    if (!_dayOk(d)) d = d.subtract(const Duration(days: 1));
    var s = 0;
    while (_dayOk(d)) {
      s++;
      d = d.subtract(const Duration(days: 1));
    }
    return s;
  }

  /// গত ৭ দিন: [শেষ, মোট, ফোকাস মিনিট]
  List<int> weekStats() {
    var done = 0, total = 0, mins = 0;
    final now = DateTime.now();
    for (var i = 0; i < 7; i++) {
      final d = DateTime(now.year, now.month, now.day - i);
      for (final e in entriesFor(d)) {
        if (e.status == 3) continue;
        total++;
        if (e.status == 1) {
          done++;
          mins += e.minutes;
        }
      }
    }
    return [done, total, mins];
  }

  void touchUi() => notifyListeners();
}
