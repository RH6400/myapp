import 'dart:convert';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'alarm_service.dart';
import 'models.dart';
import 'planner.dart';

class Achievement {
  final String id, title, desc, icon;
  final int target;
  final int Function(AppState) value;
  const Achievement(this.id, this.icon, this.title, this.desc, this.target, this.value);
}

final achievementList = <Achievement>[
  Achievement('first', '🌱', 'প্রথম পদক্ষেপ', 'প্রথম কাজ শেষ করুন', 1, (s) => s.totalDone),
  Achievement('ten', '🎯', 'দশে দশ', '১০টি কাজ শেষ করুন', 10, (s) => s.totalDone),
  Achievement('fifty', '🏆', 'পঞ্চাশ ক্লাব', '৫০টি কাজ শেষ করুন', 50, (s) => s.totalDone),
  Achievement('s3', '🔥', '৩ দিনের স্ট্রিক', 'টানা ৩ দিন ৭০%+ কাজ শেষ', 3, (s) => s.streak),
  Achievement('s7', '⚡', 'সাপ্তাহিক যোদ্ধা', 'টানা ৭ দিনের স্ট্রিক', 7, (s) => s.streak),
  Achievement('xp500', '💎', '৫০০ XP', 'মোট ৫০০ XP অর্জন করুন', 500, (s) => s.xp),
  Achievement('h10', '⏳', '১০ ঘণ্টা ফোকাস', 'মোট ১০ ঘণ্টা কাজ করুন', 10, (s) => s.totalMinutes ~/ 60),
];

/// ডেমোর জন্য একটাই গ্লোবাল স্টেট।
final app = AppState();

class AppState extends ChangeNotifier {
  SharedPreferences? _p;

  List<TaskItem> tasks = [];
  List<TimeWindow> windows = [TimeWindow(18 * 60, 22 * 60)];
  Map<String, List<PlanEntry>> plans = {};
  int xp = 0;
  Set<String> unlocked = {};
  Set<String> likedPosts = {};
  String geminiKey = '';
  String geminiModel = 'gemini-2.0-flash';

  List<String> lastUnlocked = [];
  List<TaskItem> unplaced = [];

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    final raw = _p!.getString('state');
    if (raw == null) {
      tasks = [
        TaskItem(id: 't1', title: 'পড়াশোনা', category: 'পড়াশোনা', minutes: 60, priority: 3, part: 3),
        TaskItem(id: 't2', title: 'ব্যায়াম', category: 'ব্যায়াম', minutes: 30, priority: 2, part: 1),
        TaskItem(id: 't3', title: 'নতুন স্কিল শেখা', category: 'দক্ষতা', minutes: 45, priority: 2, part: 3),
      ];
      return;
    }
    try {
      final j = jsonDecode(raw) as Map<String, dynamic>;
      tasks = (j['tasks'] as List).map((e) => TaskItem.fromJson(e)).toList();
      windows = (j['windows'] as List).map((e) => TimeWindow.fromJson(e)).toList();
      plans = (j['plans'] as Map<String, dynamic>).map((k, v) =>
          MapEntry(k, (v as List).map((e) => PlanEntry.fromJson(e)).toList()));
      xp = j['xp'] as int;
      unlocked = Set<String>.from(j['unlocked'] as List);
      likedPosts = Set<String>.from(j['liked'] as List);
      geminiKey = j['key'] as String;
      geminiModel = j['model'] as String;
    } catch (_) {}
  }

  void _commit() {
    _p?.setString(
      'state',
      jsonEncode({
        'tasks': tasks.map((e) => e.toJson()).toList(),
        'windows': windows.map((e) => e.toJson()).toList(),
        'plans': plans.map((k, v) => MapEntry(k, v.map((e) => e.toJson()).toList())),
        'xp': xp,
        'unlocked': unlocked.toList(),
        'liked': likedPosts.toList(),
        'key': geminiKey,
        'model': geminiModel,
      }),
    );
    notifyListeners();
  }

  // ---------- কাজ ও সময় ----------
  void addTask(TaskItem t) {
    tasks.add(t);
    _commit();
  }

  void removeTask(String id) {
    tasks.removeWhere((t) => t.id == id);
    _commit();
  }

  void setWindows(List<TimeWindow> w) {
    windows = w;
    _commit();
  }

  void setApiSettings(String key, String model) {
    geminiKey = key.trim();
    if (model.trim().isNotEmpty) geminiModel = model.trim();
    _commit();
  }

  void toggleLike(String id) {
    likedPosts.contains(id) ? likedPosts.remove(id) : likedPosts.add(id);
    _commit();
  }

  // ---------- রুটিন ----------
  List<PlanEntry> entriesFor(DateTime d) => plans[dateKey(d)] ?? [];

  Iterable<PlanEntry> get allEntries => plans.values.expand((l) => l);

  PlanEntry? findPendingByAlarm(int alarmId) {
    for (final e in allEntries) {
      if (e.alarmId == alarmId && e.status == 0) return e;
    }
    return null;
  }

  DateTime? dateOf(PlanEntry e) {
    for (final k in plans.keys) {
      if (plans[k]!.contains(e)) return DateTime.parse(k);
    }
    return null;
  }

  Future<void> generate(DateTime date) async {
    final now = DateTime.now();
    final key = dateKey(date);
    final existing = plans[key] ?? [];
    for (final e in existing.where((e) => e.status == 0)) {
      await AlarmService.cancel(e.alarmId);
    }
    final kept = existing.where((e) => e.status != 0).toList();
    final doneIds = kept.map((e) => e.taskId).toSet();
    final todo = tasks.where((t) => !doneIds.contains(t.id)).toList();

    final isToday = dateKey(now) == key;
    final notBefore = isToday ? ((now.hour * 60 + now.minute + 5 + 4) ~/ 5) * 5 : 0;
    final res = buildPlan(todo, windows, notBefore: notBefore);

    var next = existing.isEmpty ? 0 : existing.map((e) => e.alarmId % 100).reduce(max) + 1;
    for (final e in res.entries) {
      e.alarmId = dateInt(date) * 100 + (next++ % 100);
      await AlarmService.scheduleEntry(e, date);
    }
    plans[key] = [...kept, ...res.entries]..sort((a, b) => a.startMin.compareTo(b.startMin));
    unplaced = res.unplaced;
    _commit();
  }

  // ---------- কাজের ফলাফল ----------
  int complete(PlanEntry e) {
    e.status = 1;
    AlarmService.cancel(e.alarmId);
    final gain = e.minutes + e.priority * 10;
    xp += gain;
    _checkUnlocks();
    _commit();
    return gain;
  }

  void skip(PlanEntry e) {
    e.status = 2;
    AlarmService.cancel(e.alarmId);
    xp = max(0, xp - 10);
    _commit();
  }

  /// সর্বোচ্চ ২ বার, প্রতিবার -৫ XP।
  Future<bool> snooze(PlanEntry e) async {
    if (e.snoozes >= 2) return false;
    e.snoozes++;
    xp = max(0, xp - 5);
    await AlarmService.cancel(e.alarmId);
    await AlarmService.scheduleAt(e, DateTime.now().add(const Duration(minutes: 10)));
    _commit();
    return true;
  }

  void _checkUnlocks() {
    lastUnlocked = [];
    for (final a in achievementList) {
      if (!unlocked.contains(a.id) && a.value(this) >= a.target) {
        unlocked.add(a.id);
        xp += 50;
        lastUnlocked.add('${a.icon} ${a.title}');
      }
    }
  }

  // ---------- পরিসংখ্যান ----------
  int get totalDone => allEntries.where((e) => e.status == 1).length;
  int get totalMinutes =>
      allEntries.where((e) => e.status == 1).fold(0, (s, e) => s + e.minutes);
  int get level => xp ~/ 200 + 1;
  int get xpIntoLevel => xp % 200;

  bool _dayOk(DateTime d) {
    final l = plans[dateKey(d)];
    if (l == null || l.isEmpty) return false;
    final done = l.where((e) => e.status == 1).length;
    return done > 0 && done / l.length >= 0.7;
  }

  int get streak {
    var d = DateTime.now();
    if (!_dayOk(d)) d = d.subtract(const Duration(days: 1));
    var s = 0;
    while (_dayOk(d)) {
      s++;
      d = d.subtract(const Duration(days: 1));
    }
    return s;
  }
}
