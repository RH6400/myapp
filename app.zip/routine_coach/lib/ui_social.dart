import 'package:flutter/material.dart';
import 'models.dart';
import 'state.dart';

class _Post {
  final String id, name, avatar, bio;
  final int streak, baseLikes;
  final List<(String, String, int, int, int)> tasks; // নাম, ক্যাটাগরি, মিনিট, অগ্রাধিকার, সময়ভাগ
  const _Post(this.id, this.name, this.avatar, this.bio, this.streak, this.baseLikes, this.tasks);
}

// ডামি ডেটা — অনলাইনে গেলে এগুলো ব্যাকএন্ড থেকে আসবে।
const _posts = <_Post>[
  _Post('p1', 'রিয়া', '👩‍💻', 'সকালে কঠিন কাজ, রাতে হালকা', 21, 128, [
    ('ডিপ ওয়ার্ক', 'কাজ', 90, 3, 1),
    ('ব্যায়াম', 'ব্যায়াম', 30, 2, 1),
    ('বই পড়া', 'পড়াশোনা', 30, 1, 3),
  ]),
  _Post('p2', 'সাকিব', '🧑‍🎓', 'ভর্তি প্রস্তুতির ৪ ঘণ্টার রুটিন', 9, 76, [
    ('গণিত', 'পড়াশোনা', 60, 3, 1),
    ('ইংরেজি', 'পড়াশোনা', 45, 2, 2),
    ('মডেল টেস্ট', 'পড়াশোনা', 60, 3, 3),
  ]),
  _Post('p3', 'নুসরাত', '🧘‍♀️', 'ছোট ছোট অভ্যাসে বড় পরিবর্তন', 45, 301, [
    ('মেডিটেশন', 'স্বাস্থ্য', 10, 2, 1),
    ('হাঁটা', 'ব্যায়াম', 20, 2, 3),
    ('জার্নাল লেখা', 'অন্যান্য', 10, 1, 3),
  ]),
];

class SocialTab extends StatelessWidget {
  const SocialTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('কমিউনিটি', style: Theme.of(context).textTheme.titleLarge),
          const Text('অন্যদের রুটিন দেখুন, পছন্দ হলে নিজের করে নিন (ডেমো ডেটা)।',
              style: TextStyle(fontSize: 12)),
          const SizedBox(height: 8),
          for (final p in _posts) _PostCard(p: p),
        ],
      ),
    );
  }
}

class _PostCard extends StatelessWidget {
  final _Post p;
  const _PostCard({required this.p});

  @override
  Widget build(BuildContext context) {
    final liked = app.likedPosts.contains(p.id);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Text(p.avatar, style: const TextStyle(fontSize: 32)),
            const SizedBox(width: 8),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(p.name, style: Theme.of(context).textTheme.titleMedium),
                Text(p.bio, style: Theme.of(context).textTheme.bodySmall),
              ]),
            ),
            Chip(label: Text('🔥 ${p.streak}')),
          ]),
          const Divider(),
          for (final t in p.tasks) Text('• ${t.$1} — ${t.$3} মিনিট (${t.$2})'),
          const SizedBox(height: 8),
          Row(children: [
            IconButton(
              onPressed: () => app.toggleLike(p.id),
              icon: Icon(liked ? Icons.favorite : Icons.favorite_border,
                  color: liked ? Colors.red : null),
            ),
            Text('${p.baseLikes + (liked ? 1 : 0)}'),
            const Spacer(),
            FilledButton.tonalIcon(
              icon: const Icon(Icons.download),
              label: const Text('আমার করো'),
              onPressed: () {
                for (final t in p.tasks) {
                  app.addTask(TaskItem(
                    id: '${DateTime.now().microsecondsSinceEpoch}-${t.$1}',
                    title: t.$1,
                    category: t.$2,
                    minutes: t.$3,
                    priority: t.$4,
                    part: t.$5,
                  ));
                }
                ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('${p.name}-এর ${p.tasks.length}টি কাজ যোগ হয়েছে')));
              },
            ),
          ]),
        ]),
      ),
    );
  }
}
