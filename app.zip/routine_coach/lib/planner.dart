import 'models.dart';

/// সময়ের ভাগ: 1 সকাল, 2 দুপুর, 3 সন্ধ্যা/রাত
int partOf(int m) => m < 12 * 60 ? 1 : (m < 17 * 60 ? 2 : 3);

const partNames = {0: 'যেকোনো সময়', 1: 'সকাল', 2: 'দুপুর', 3: 'সন্ধ্যা/রাত'};

class PlanResult {
  final List<PlanEntry> entries;
  final List<TaskItem> unplaced;
  PlanResult(this.entries, this.unplaced);
}

/// ফ্রি সময়ের জানালায় কাজ বসায়: আগে উচ্চ অগ্রাধিকার, পছন্দের সময়ভাগ মানার চেষ্টা,
/// দুই কাজের মাঝে [gap] মিনিট বিরতি।
PlanResult buildPlan(
  List<TaskItem> tasks,
  List<TimeWindow> windows, {
  int notBefore = 0,
  int gap = 10,
}) {
  final ws = [...windows]..sort((a, b) => a.start.compareTo(b.start));
  final cursor = ws.map((w) => w.start < notBefore ? notBefore : w.start).toList();

  final sorted = [...tasks]
    ..sort((a, b) => b.priority != a.priority
        ? b.priority.compareTo(a.priority)
        : b.minutes.compareTo(a.minutes));

  final entries = <PlanEntry>[];
  final unplaced = <TaskItem>[];

  for (final t in sorted) {
    int? slot;
    for (final strict in [true, false]) {
      for (var i = 0; i < ws.length; i++) {
        if (strict && t.part != 0 && partOf(cursor[i]) != t.part) continue;
        if (cursor[i] + t.minutes <= ws[i].end) {
          slot = i;
          break;
        }
      }
      if (slot != null) break;
    }
    if (slot == null) {
      unplaced.add(t);
    } else {
      entries.add(PlanEntry(
        id: '${t.id}-${DateTime.now().microsecondsSinceEpoch}',
        taskId: t.id,
        title: t.title,
        category: t.category,
        priority: t.priority,
        startMin: cursor[slot],
        minutes: t.minutes,
      ));
      cursor[slot] += t.minutes + gap;
    }
  }
  entries.sort((a, b) => a.startMin.compareTo(b.startMin));
  return PlanResult(entries, unplaced);
}
