import 'models.dart';

/// সময়ের ভাগ: 1 সকাল, 2 দুপুর, 3 সন্ধ্যা/রাত
int partOf(int m) => m < 12 * 60 ? 1 : (m < 17 * 60 ? 2 : 3);

class PlanResult {
  final List<PlanEntry> entries;
  final List<TaskItem> unplaced;
  PlanResult(this.entries, this.unplaced);
}

/// একে অপরের সাথে মিশে যাওয়া ফ্রি সময় একত্র করে।
List<TimeWindow> mergeWindows(List<TimeWindow> input) {
  final ws = input.where((w) => w.end > w.start).map((w) => TimeWindow(w.start, w.end)).toList()
    ..sort((a, b) => a.start.compareTo(b.start));
  final out = <TimeWindow>[];
  for (final w in ws) {
    if (out.isNotEmpty && w.start <= out.last.end) {
      if (w.end > out.last.end) out.last.end = w.end;
    } else {
      out.add(w);
    }
  }
  return out;
}

/// ফ্রি সময় থেকে ব্যস্ত সময় বাদ দিয়ে খালি টুকরোগুলো বের করে।
List<TimeWindow> freeSegments(List<TimeWindow> windows, List<TimeWindow> busy, int notBefore) {
  var segs = <TimeWindow>[];
  for (final w in mergeWindows(windows)) {
    final s = w.start < notBefore ? notBefore : w.start;
    if (s < w.end) segs.add(TimeWindow(s, w.end));
  }
  for (final b in busy) {
    final next = <TimeWindow>[];
    for (final s in segs) {
      if (b.end <= s.start || b.start >= s.end) {
        next.add(s);
        continue;
      }
      if (b.start > s.start) next.add(TimeWindow(s.start, b.start));
      if (b.end < s.end) next.add(TimeWindow(b.end, s.end));
    }
    segs = next;
  }
  segs.sort((a, b) => a.start.compareTo(b.start));
  return segs;
}

/// ফ্রি সময়ের জানালায় অটো-কাজ বসায়: আগে উচ্চ অগ্রাধিকার, পছন্দের সময়ভাগ মানার চেষ্টা,
/// দুই কাজের মাঝে [gap] মিনিট বিরতি। [busy] সময়গুলোতে কিছু বসবে না।
PlanResult buildPlan(
  List<TaskItem> tasks,
  List<TimeWindow> windows, {
  List<TimeWindow> busy = const [],
  int notBefore = 0,
  int gap = 10,
}) {
  final segs = freeSegments(windows, busy, notBefore);
  final cursor = segs.map((s) => s.start).toList();

  final sorted = [...tasks]
    ..sort((a, b) => b.priority != a.priority
        ? b.priority.compareTo(a.priority)
        : b.minutes.compareTo(a.minutes));

  final entries = <PlanEntry>[];
  final unplaced = <TaskItem>[];

  for (final t in sorted) {
    int? slot;
    for (final strict in [true, false]) {
      for (var i = 0; i < segs.length; i++) {
        if (strict && t.part != 0 && partOf(cursor[i]) != t.part) continue;
        if (cursor[i] + t.minutes <= segs[i].end) {
          slot = i;
          break;
        }
      }
      if (slot != null) break;
    }
    if (slot == null) {
      unplaced.add(t);
    } else {
      entries.add(PlanEntry(
        id: '${t.id}-${DateTime.now().microsecondsSinceEpoch}',
        taskId: t.id,
        title: t.title,
        category: t.category,
        priority: t.priority,
        startMin: cursor[slot],
        minutes: t.minutes,
        alert: t.alert,
        force: t.force,
      ));
      cursor[slot] += t.minutes + gap;
    }
  }
  entries.sort((a, b) => a.startMin.compareTo(b.startMin));
  return PlanResult(entries, unplaced);
}

/// [from] বা তার পরের প্রথম খালি জায়গা (দৈর্ঘ্য [minutes]); না পেলে null।
int? findFreeSlot(int minutes, int from, List<TimeWindow> busy) {
  final sorted = [...busy]..sort((a, b) => a.start.compareTo(b.start));
  var c = from;
  for (final b in sorted) {
    if (c + minutes <= b.start) break;
    if (b.end > c) c = b.end;
  }
  return c + minutes <= 24 * 60 ? c : null;
}
