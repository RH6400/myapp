import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'cloud.dart';
import 'i18n.dart';
import 'models.dart';
import 'notif.dart';
import 'state.dart';
import 'theme.dart';
import 'ui_common.dart';
import 'ui_myrewards.dart';

/// সেটিংস: সাধারণ অ্যাপের মতো গ্রুপ করে সাজানো।
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(L('সেটিংস', 'Settings'))),
      body: ListenableBuilder(
        listenable: Listenable.merge([app, cloud]),
        builder: (context, _) => _body(context),
      ),
    );
  }

  Widget _body(BuildContext context) {
    final p = app.prefs;
    final pal = Pal.of(context);
    final an = p.assistantName;
    final weekdays = <int, String>{
      0: L('নেই', 'None'),
      for (var d = 1; d <= 7; d++) d: weekdayName(d),
    };
    return ListView(
      padding: listPad(context, top: 8, bottom: 32),
      children: [
        // ---------- অ্যাকাউন্ট ----------
        MCard(
          child: Row(children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: pal.priSoft,
              backgroundImage: cloud.signedIn && cloud.photoUrl.isNotEmpty ? NetworkImage(cloud.photoUrl) : null,
              child: cloud.signedIn && cloud.photoUrl.isNotEmpty
                  ? null
                  : Icon(Icons.person_outline, color: pal.pri),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(
                  cloud.signedIn
                      ? (cloud.displayName.isEmpty ? t('user.default') : cloud.displayName)
                      : L('লগইন করা নেই', 'Not signed in'),
                  style: TextStyle(color: pal.tx, fontWeight: FontWeight.w700, fontSize: 15),
                ),
                Text(
                  cloud.signedIn
                      ? cloud.email
                      : (Cloud.configured
                          ? L('লগইন করলে ডাটা ক্লাউডে সেভ থাকবে', 'Sign in to keep your data in the cloud')
                          : L('অনলাইন লগইন এখনো চালু হয়নি', 'Online sign-in is not enabled yet')),
                  style: TextStyle(color: pal.sub, fontSize: 12.5),
                ),
              ]),
            ),
            if (!cloud.signedIn && Cloud.configured)
              FilledButton(
                onPressed: () async {
                  final err = await cloud.signInWithGoogle();
                  if (err != null && context.mounted) snack(context, err);
                },
                child: const Text('Google'),
              ),
          ]),
        ),

        // ---------- আমার পুরস্কার ----------
        const SizedBox(height: 12),
        SettingGroup(children: [
          SettingTile(
            icon: Icons.card_giftcard,
            title: L('আমার পুরস্কার', 'My rewards'),
            subtitle: L('লক্ষ্য পূরণ হলে নিজেকে যা দেবেন', 'What you give yourself when you reach a goal'),
            onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const MyRewardsScreen())),
          ),
        ]),

        // ---------- অ্যালার্ম ও ফোকাস ----------
        SectionTitle(L('অ্যালার্ম ও ফোকাস', 'Alarm and focus')),
        SettingGroup(children: [
          SettingTile(
            icon: Icons.shield_outlined,
            title: L('ফোর্স লেভেল', 'Force level'),
            value: forceLabel(p.force),
            onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const ForceScreen())),
          ),
          SettingTile(
            icon: alertIcon(p.alert),
            title: L('ডিফল্ট মনে করানোর ধরন', 'Default alert type'),
            value: alertLabel(p.alert),
            onTap: () async {
              final v = await pickOne<String>(
                context,
                L('মনে করানোর ধরন', 'Alert type'),
                {for (final k in const ['alarm', 'vibrate', 'notify']) k: alertLabel(k)},
                p.alert,
              );
              if (v != null) {
                p.alert = v;
                await app.savePrefs(replanNow: true);
              }
            },
          ),
          SettingTile(
            icon: Icons.event_busy,
            title: L('ছুটির দিন (অ্যালার্ম বন্ধ)', 'Day off (no alarms)'),
            value: weekdays[p.offDay] ?? '',
            onTap: () async {
              final v = await pickOne<int>(context, L('ছুটির দিন', 'Day off'), weekdays, p.offDay);
              if (v != null) {
                p.offDay = v;
                await app.savePrefs(replanNow: true);
              }
            },
          ),
          SettingTile(
            icon: Icons.verified_user_outlined,
            title: L('পারমিশন ও Xiaomi গাইড', 'Permissions and phone guide'),
            subtitle: L('অ্যালার্ম সময়মতো বাজাতে এগুলো ঠিক করুন', 'Fix these so alarms ring on time'),
            onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const PermScreen())),
          ),
        ]),

        // ---------- নোটিফিকেশন ----------
        SectionTitle(L('নোটিফিকেশন', 'Notifications')),
        SettingGroup(children: [
          SwitchTile(
            icon: Icons.push_pin_outlined,
            title: L('সবসময়-থাকা নোটিফিকেশন', 'Always-on notification'),
            subtitle: L('নোটিফিকেশন বারে পরের কাজ দেখায়', 'Shows your next task in the notification bar'),
            value: p.persistent,
            onChanged: (v) {
              p.persistent = v;
              app.savePrefs();
            },
          ),
          SettingTile(
            icon: Icons.chat_bubble_outline,
            title: L('$an কতবার খোঁজ নেবে', '$an check-ins per day'),
            subtitle: p.mood == 'quiet'
                ? L('মুড “চুপচাপ” থাকলে খোঁজ নেওয়া হয় না', 'No check-ins while mood is “Quiet”')
                : null,
            value: p.nudges == 0 ? L('বন্ধ', 'Off') : L('দিনে ${p.nudges} বার', '${p.nudges} per day'),
            onTap: () async {
              final v = await pickOne<int>(
                context,
                L('দিনে কতবার', 'Per day'),
                {
                  0: L('বন্ধ', 'Off'),
                  for (var i = 1; i <= 5; i++) i: L('দিনে $i বার', '$i per day'),
                },
                p.nudges,
              );
              if (v != null) {
                p.nudges = v;
                await app.savePrefs();
              }
            },
          ),
        ]),

        // ---------- সহকারী ----------
        SectionTitle(an),
        SettingGroup(children: [
          SettingTile(
            icon: Icons.badge_outlined,
            title: L('সহকারীর নাম', 'Assistant name'),
            value: an,
            onTap: () async {
              final v = await askText(context, L('সহকারীর নাম', 'Assistant name'), an,
                  hint: 'Mailo', maxLen: 20);
              if (v != null && v.trim().isNotEmpty) {
                p.assistantName = v.trim();
                await app.savePrefs();
                notif.refreshSoon();
              }
            },
          ),
          SettingTile(
            icon: Icons.psychology_outlined,
            title: L('মুড', 'Mood'),
            value: moodLabel(p.mood),
            onTap: () async {
              final v = await pickOne<String>(
                context,
                L('$an-র মুড', '$an mood'),
                {for (final k in const ['quiet', 'normal', 'chatty', 'coach']) k: moodLabel(k)},
                p.mood,
              );
              if (v != null) {
                p.mood = v;
                await app.savePrefs();
              }
            },
          ),
          SettingTile(
            icon: Icons.school_outlined,
            title: L('যা শিখিয়েছি', 'What I taught $an'),
            value: '${p.customRules.length}',
            onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const TaughtScreen())),
          ),
          SettingTile(
            icon: Icons.key_outlined,
            title: 'Gemini API key',
            subtitle: p.geminiKey.isEmpty
                ? L('ঐচ্ছিক: আরও স্মার্ট উত্তরের জন্য', 'Optional: for smarter replies')
                : L('চালু (${p.geminiModel})', 'On (${p.geminiModel})'),
            onTap: () => _geminiDialog(context),
          ),
          SwitchTile(
            icon: Icons.animation,
            title: L('$an-র নড়াচড়া', '$an animations'),
            subtitle: L('বন্ধ করলে ব্যাটারি সামান্য বাঁচে', 'Turn off to save a little battery'),
            value: p.animations,
            onChanged: (v) {
              p.animations = v;
              app.savePrefs();
            },
          ),
        ]),

        // ---------- গোপনীয়তা ও নিরাপত্তা ----------
        SectionTitle(L('গোপনীয়তা ও নিরাপত্তা', 'Privacy and safety')),
        SettingGroup(children: [
          SettingTile(
            icon: Icons.public,
            title: L('ডিফল্ট পোস্ট অডিয়েন্স', 'Default post audience'),
            value: p.audience == 'me' ? L('শুধু আমি', 'Only me') : L('সবাই', 'Everyone'),
            onTap: () async {
              final v = await pickOne<String>(
                context,
                L('কে দেখবে', 'Who can see'),
                {'public': L('সবাই', 'Everyone'), 'me': L('শুধু আমি', 'Only me')},
                p.audience,
              );
              if (v != null) {
                p.audience = v;
                await app.savePrefs();
              }
            },
          ),
          SettingTile(
            icon: Icons.block,
            title: L('ব্লক করা ইউজার', 'Blocked users'),
            value: '${cloud.blocked.length}',
            onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const BlockedScreen())),
          ),
        ]),

        // ---------- চেহারা ও ভাষা ----------
        SectionTitle(L('চেহারা ও ভাষা', 'Appearance and language')),
        SettingGroup(children: [
          SettingTile(
            icon: Icons.language,
            title: L('ভাষা', 'Language'),
            value: supportedLanguages[p.lang] ?? p.lang,
            onTap: () async {
              final v = await pickOne<String>(context, L('ভাষা', 'Language'), supportedLanguages, p.lang);
              if (v != null) {
                p.lang = v;
                gLang = v;
                await app.savePrefs();
              }
            },
          ),
          SettingTile(
            icon: Icons.brightness_6_outlined,
            title: L('থিম', 'Theme'),
            value: _themeLabel(p.theme),
            onTap: () async {
              final v = await pickOne<String>(
                context,
                L('থিম', 'Theme'),
                {for (final k in const ['system', 'light', 'dark']) k: _themeLabel(k)},
                p.theme,
              );
              if (v != null) {
                p.theme = v;
                await app.savePrefs();
              }
            },
          ),
          SettingTile(
            icon: Icons.category_outlined,
            title: L('ক্যাটাগরি সম্পাদনা', 'Edit categories'),
            subtitle: p.categories.join(', '),
            onTap: () => showDialog<void>(context: context, builder: (_) => const _CategoriesDialog()),
          ),
        ]),

        // ---------- ডাটা ----------
        SectionTitle(L('ডাটা', 'Data')),
        SettingGroup(children: [
          SwitchTile(
            icon: Icons.cloud_upload_outlined,
            title: L('ক্লাউড ব্যাকআপ', 'Cloud backup'),
            subtitle: !cloud.signedIn
                ? L('লগইন করলে চালু হবে', 'Available after sign-in')
                : (cloud.lastSync == null
                    ? L('এখনো সেভ হয়নি', 'Not saved yet')
                    : '${L('শেষ সেভ', 'Last saved')}: ${fmtMin(cloud.lastSync!.hour * 60 + cloud.lastSync!.minute)}'),
            value: p.cloudBackup,
            onChanged: cloud.signedIn
                ? (v) async {
                    p.cloudBackup = v;
                    await app.savePrefs();
                    if (v) await cloud.pushNow();
                  }
                : null,
          ),
        ]),

        // ---------- সম্পর্কে ----------
        SectionTitle(L('সম্পর্কে', 'About')),
        SettingGroup(children: [
          SettingTile(
            icon: Icons.policy_outlined,
            title: L('গোপনীয়তা নীতি', 'Privacy policy'),
            onTap: () => showDialog<void>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: Text(L('গোপনীয়তা নীতি', 'Privacy policy')),
                content: SingleChildScrollView(
                  child: Text(L(
                    'লগইন করলে আপনার Google নাম, ছবি ও ইমেইল শুধু আপনাকে চেনাতে ব্যবহার হয়। আপনার কাজ, রুটিন ও সেটিং আপনার অ্যাকাউন্টের নিচে ব্যাকআপ হিসেবে সেভ হয়; অন্য কেউ দেখতে পায় না। “সবাই” অডিয়েন্সে করা পোস্ট সব ইউজার দেখতে পায়। আপনি যেকোনো সময় পোস্ট মুছতে এবং সেটিংস থেকে পুরো অ্যাকাউন্ট ও ডাটা মুছে ফেলতে পারেন। আমরা আপনার ডাটা বিক্রি করি না।',
                    'When you sign in, your Google name, photo and email are used only to identify you. Your tasks, routines and settings are saved as a private backup under your account; nobody else can see them. Posts with the “Everyone” audience are visible to all users. You can delete posts at any time and delete your whole account and data from Settings. We do not sell your data.',
                  )),
                ),
                actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: Text(L('ঠিক আছে', 'OK')))],
              ),
            ),
          ),
          SettingTile(
            icon: Icons.info_outline,
            title: 'Mailo',
            subtitle: 'Plan Today. Live Better.',
            value: 'v2.0',
          ),
          if (cloud.signedIn)
            SettingTile(
              icon: Icons.logout,
              title: L('লগআউট', 'Sign out'),
              onTap: () async {
                final ok = await confirm(
                  context,
                  L('লগআউট করবেন?', 'Sign out?'),
                  L('এই ফোনের ডাটা মুছে যাবে। আবার লগইন করলে ক্লাউড থেকে ফিরে আসবে।',
                      'Data on this phone will be cleared. It comes back from the cloud when you sign in again.'),
                );
                if (!ok || !context.mounted) return;
                final nav = Navigator.of(context);
                await cloud.signOut();
                nav.popUntil((r) => r.isFirst);
              },
            ),
          if (cloud.signedIn)
            SettingTile(
              icon: Icons.delete_forever_outlined,
              danger: true,
              title: L('অ্যাকাউন্ট মুছুন', 'Delete account'),
              subtitle: L('সব ডাটা স্থায়ীভাবে যাবে', 'All data will be removed permanently'),
              onTap: () async {
                final ok = await confirm(
                  context,
                  L('অ্যাকাউন্ট মুছবেন?', 'Delete account?'),
                  L('আপনার সব পোস্ট, রুটিন ও ব্যাকআপ স্থায়ীভাবে মুছে যাবে। এটা ফেরানো যাবে না।',
                      'All your posts, routines and backup will be removed permanently. This cannot be undone.'),
                  yes: L('মুছে ফেলুন', 'Delete'),
                );
                if (!ok || !context.mounted) return;
                final nav = Navigator.of(context);
                final messenger = ScaffoldMessenger.of(context);
                final err = await cloud.deleteAccount();
                if (err != null) {
                  messenger.showSnackBar(SnackBar(content: Text(err)));
                } else {
                  nav.popUntil((r) => r.isFirst);
                }
              },
            ),
        ]),
      ],
    );
  }

  static String _themeLabel(String k) {
    switch (k) {
      case 'light':
        return L('হালকা', 'Light');
      case 'dark':
        return L('গাঢ়', 'Dark');
      default:
        return L('ডিভাইস অনুযায়ী', 'Follow device');
    }
  }

  Future<void> _geminiDialog(BuildContext context) async {
    final key = TextEditingController(text: app.prefs.geminiKey);
    final model = TextEditingController(text: app.prefs.geminiModel);
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Gemini'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(
              L('Google AI Studio থেকে ফ্রি API key নিয়ে বসান। এটা শুধু এই ফোনে থাকে।',
                  'Paste a free API key from Google AI Studio. It stays on this phone only.'),
              style: const TextStyle(fontSize: 12),
            ),
            TextField(controller: key, obscureText: true, decoration: const InputDecoration(labelText: 'API key')),
            TextField(controller: model, decoration: InputDecoration(labelText: L('মডেলের নাম', 'Model name'))),
          ]),
        ),
        actions: [
          TextButton(
            onPressed: () {
              app.prefs.geminiKey = key.text.trim();
              if (model.text.trim().isNotEmpty) app.prefs.geminiModel = model.text.trim();
              app.savePrefs();
              Navigator.pop(ctx);
            },
            child: Text(L('সংরক্ষণ', 'Save')),
          ),
        ],
      ),
    );
    key.dispose();
    model.dispose();
  }
}

/// “যা শিখিয়েছি”: Mailo-কে শেখানো নিয়মের তালিকা।
class TaughtScreen extends StatelessWidget {
  const TaughtScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final p = Pal.of(context);
        final rules = app.prefs.customRules;
        final an = app.prefs.assistantName;
        return Scaffold(
          appBar: AppBar(
            title: Text(L('যা শিখিয়েছি', 'What I taught $an')),
            actions: [
              if (rules.isNotEmpty || app.prefs.callName.isNotEmpty)
                TextButton(
                  onPressed: () async {
                    final ok = await confirm(
                      context,
                      L('সব ভুলিয়ে দেবেন?', 'Forget everything?'),
                      L('শেখানো সব নিয়ম মুছে যাবে।', 'All taught rules will be removed.'),
                      yes: L('ভুলিয়ে দিন', 'Forget all'),
                    );
                    if (!ok) return;
                    app.prefs.customRules = [];
                    app.prefs.callName = '';
                    await app.savePrefs();
                  },
                  child: Text(L('সব ভুলুক', 'Forget all')),
                ),
            ],
          ),
          body: ListView(
            padding: listPad(context, top: 12, bottom: 32),
            children: [
              MCard(
                color: p.priSoft,
                border: p.priSoft,
                child: Text(
                  L('চ্যাটে লিখুন “এখন থেকে ...” — যেমন “এখন থেকে আমাকে রুবায়েত ডাকবে” বা “এখন থেকে সকালের উত্তর ছোট করবে”। সর্বোচ্চ ২০টা নিয়ম।',
                      'Type “from now on ...” in the chat, e.g. “from now on call me Rubaiat” or “keep morning answers short”. Up to 20 rules.'),
                  style: TextStyle(color: p.tx, fontSize: 13, height: 1.5),
                ),
              ),
              if (app.prefs.callName.isNotEmpty)
                MCard(
                  margin: const EdgeInsets.only(top: 10),
                  child: Row(children: [
                    IconTile(Icons.face_outlined),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(L('ডাকনাম: ${app.prefs.callName}', 'Call name: ${app.prefs.callName}'),
                          style: TextStyle(color: p.tx, fontWeight: FontWeight.w600)),
                    ),
                  ]),
                ),
              const SizedBox(height: 10),
              if (rules.isEmpty)
                Padding(
                  padding: const EdgeInsets.all(24),
                  child: Center(
                    child: Text(L('এখনো কিছু শেখানো হয়নি', 'Nothing taught yet'), style: TextStyle(color: p.sub)),
                  ),
                )
              else
                SettingGroup(children: [
                  for (var i = 0; i < rules.length; i++)
                    SettingTile(
                      icon: Icons.lightbulb_outline,
                      title: rules[i],
                      trailing: IconButton(
                        icon: Icon(Icons.delete_outline, color: p.bad),
                        onPressed: () {
                          app.prefs.customRules.removeAt(i);
                          app.savePrefs();
                        },
                      ),
                      onTap: () async {
                        final v = await askText(context, L('নিয়ম বদলান', 'Edit rule'), rules[i], maxLen: 200);
                        if (v != null && v.trim().isNotEmpty) {
                          app.prefs.customRules[i] = v.trim();
                          await app.savePrefs();
                        }
                      },
                    ),
                ]),
            ],
          ),
        );
      },
    );
  }
}

class _CategoriesDialog extends StatefulWidget {
  const _CategoriesDialog();
  @override
  State<_CategoriesDialog> createState() => _CategoriesDialogState();
}

class _CategoriesDialogState extends State<_CategoriesDialog> {
  final ctl = TextEditingController();

  @override
  void dispose() {
    ctl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cats = app.prefs.categories;
    return AlertDialog(
      title: Text(L('ক্যাটাগরি', 'Categories')),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Wrap(spacing: 6, runSpacing: 6, children: [
          for (final c in cats)
            InputChip(
              label: Text(c),
              onDeleted: cats.length > 1
                  ? () {
                      setState(() => cats.remove(c));
                      app.savePrefs();
                    }
                  : null,
            ),
        ]),
        TextField(
          controller: ctl,
          decoration: InputDecoration(
            labelText: L('নতুন ক্যাটাগরি', 'New category'),
            suffixIcon: IconButton(
              icon: const Icon(Icons.add),
              onPressed: () {
                final v = ctl.text.trim();
                if (v.isNotEmpty && !cats.contains(v)) {
                  setState(() => cats.add(v));
                  app.savePrefs();
                }
                ctl.clear();
              },
            ),
          ),
        ),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text(L('ঠিক আছে', 'OK')))],
    );
  }
}

/// ফোর্স: ইউজার নিজেই ঠিক করে অ্যাপ কতটা চাপ দেবে।
class ForceScreen extends StatefulWidget {
  const ForceScreen({super.key});
  @override
  State<ForceScreen> createState() => _ForceScreenState();
}

class _ForceScreenState extends State<ForceScreen> {
  @override
  Widget build(BuildContext context) {
    final p = app.prefs;
    final cs = Theme.of(context).colorScheme;
    final cfg = p.forceFor(p.force);
    return Scaffold(
      appBar: AppBar(title: Text(L('ফোর্স লেভেল', 'Force level'))),
      body: ListView(
        padding: listPad(context, top: 16, bottom: 24),
        children: [
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final k in const ['soft', 'mid', 'hard', 'own'])
              ChoiceChip(
                label: Text(forceLabel(k)),
                selected: p.force == k,
                onSelected: (_) {
                  setState(() => p.force = k);
                  app.savePrefs();
                },
              ),
          ]),
          const SizedBox(height: 8),
          Text(forceHint(p.force), style: TextStyle(color: cs.onSurfaceVariant)),
          const SizedBox(height: 16),
          if (p.force == 'own') ...[
            Text('${L('স্নুজ করা যাবে', 'Snoozes allowed')}: ${p.snoozeMax}'),
            Slider(
              value: p.snoozeMax.toDouble(),
              min: 0,
              max: 5,
              divisions: 5,
              onChanged: (v) => setState(() => p.snoozeMax = v.round()),
              onChangeEnd: (_) => app.savePrefs(),
            ),
            Text('${L('স্নুজের সময়', 'Snooze length')}: ${p.snoozeMin} ${L('মিনিট', 'min')}'),
            Slider(
              value: p.snoozeMin.toDouble(),
              min: 5,
              max: 30,
              divisions: 5,
              onChanged: (v) => setState(() => p.snoozeMin = v.round()),
              onChangeEnd: (_) => app.savePrefs(),
            ),
            Text('${L('“শেষ” চাপতে লাগবে', 'Finish unlocks after')}: ${p.lockPct}%'),
            Slider(
              value: p.lockPct.toDouble(),
              min: 0,
              max: 100,
              divisions: 10,
              onChanged: (v) => setState(() => p.lockPct = v.round()),
              onChangeEnd: (_) => app.savePrefs(),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(L('ব্যাক বাটন আটকানো', 'Block the back button')),
              value: p.blockBack,
              onChanged: (v) {
                setState(() => p.blockBack = v);
                app.savePrefs();
              },
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(L('XP কাটা (স্নুজ বা ছেড়ে দিলে)', 'XP penalty (snooze or give up)')),
              value: p.xpPenalty,
              onChanged: (v) {
                setState(() => p.xpPenalty = v);
                app.savePrefs();
              },
            ),
          ] else
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${L('স্নুজ', 'Snoozes')}: ${cfg.snoozeMax} × ${cfg.snoozeMin} ${L('মিনিট', 'min')}'),
                  Text('${L('“শেষ” চাপতে লাগবে', 'Finish unlocks after')}: ${cfg.lockPct}%'),
                  Text('${L('ব্যাক বাটন', 'Back button')}: ${cfg.blockBack ? L('আটকানো', 'blocked') : L('খোলা', 'free')}'),
                  Text('${L('XP কাটা', 'XP penalty')}: ${cfg.xpPenalty ? L('আছে', 'on') : L('নেই', 'off')}'),
                ]),
              ),
            ),
          const SizedBox(height: 16),
          Text(
            L('মনে রাখবেন: Android ফোন পুরোপুরি লক করতে দেয় না। কড়া মানে হলো বের হলে মূল্য দিতে হবে, ফোন আটকে যাবে না। প্রতিটা কাজে আলাদা কড়াকড়িও দেওয়া যায়।',
                'Note: Android does not allow an app to fully lock the phone. “Strict” means leaving has a cost, not that the phone is locked. You can also set strictness per task.'),
            style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
          ),
        ],
      ),
    );
  }
}

class _PermItem {
  final String title;
  final String desc;
  final Permission perm;
  bool granted = false;
  _PermItem(this.title, this.desc, this.perm);
}

/// পারমিশন গাইড: অ্যালার্ম সময়মতো বাজতে যা লাগে।
class PermScreen extends StatefulWidget {
  const PermScreen({super.key});
  @override
  State<PermScreen> createState() => _PermScreenState();
}

class _PermScreenState extends State<PermScreen> with WidgetsBindingObserver {
  late final List<_PermItem> items = [
    _PermItem(L('নোটিফিকেশন', 'Notifications'),
        L('অ্যালার্ম ও মনে করানো দেখাতে', 'To show alarms and reminders'), Permission.notification),
    _PermItem(L('সঠিক সময়ের অ্যালার্ম', 'Exact alarms'),
        L('ঠিক সময়ে অ্যালার্ম বাজাতে', 'To ring exactly on time'), Permission.scheduleExactAlarm),
    _PermItem(L('ব্যাটারি সেভার থেকে ছাড়', 'Ignore battery optimisation'),
        L('ব্যাকগ্রাউন্ডে অ্যাপ বন্ধ না হতে', 'So the system does not kill the app'), Permission.ignoreBatteryOptimizations),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refresh();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refresh();
  }

  Future<void> _refresh() async {
    for (final i in items) {
      try {
        i.granted = await i.perm.isGranted;
      } catch (_) {
        i.granted = false;
      }
    }
    if (mounted) setState(() {});
  }

  Future<void> _ask(_PermItem i) async {
    try {
      await i.perm.request();
    } catch (_) {}
    await _refresh();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(L('পারমিশন', 'Permissions'))),
      body: ListView(
        padding: listPad(context, top: 16, bottom: 24),
        children: [
          for (final i in items)
            Card(
              child: ListTile(
                leading: Icon(i.granted ? Icons.check_circle : Icons.error_outline,
                    color: i.granted ? cs.primary : cs.error),
                title: Text(i.title),
                subtitle: Text(i.desc),
                trailing: i.granted
                    ? null
                    : FilledButton(onPressed: () => _ask(i), child: Text(L('অনুমতি দিন', 'Allow'))),
              ),
            ),
          const SizedBox(height: 8),
          Text(L('Xiaomi / MIUI ফোনে হাতে ঠিক করুন', 'On Xiaomi / MIUI phones, set these by hand'),
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Text(
            L('এই অনুমতিগুলো অ্যাপ নিজে চেক করতে পারে না। নিচের বাটনে অ্যাপের সেটিংস খুলবে:\n'
                '1. Autostart চালু করুন।\n'
                '2. Battery saver এ “No restrictions” দিন।\n'
                '3. “Other permissions” এ লক স্ক্রিনে দেখানো ও ব্যাকগ্রাউন্ডে পপআপ দেখানো চালু করুন।\n'
                '4. Recent apps এ অ্যাপটাকে লক (পিন) করে রাখুন।',
                'The app cannot check these itself. The button below opens the app settings:\n'
                '1. Turn on Autostart.\n'
                '2. Set Battery saver to “No restrictions”.\n'
                '3. Under “Other permissions” allow showing on the lock screen and pop-ups while in the background.\n'
                '4. Lock (pin) the app in Recent apps.'),
            style: TextStyle(color: cs.onSurfaceVariant),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () => openAppSettings(),
            icon: const Icon(Icons.settings),
            label: Text(L('অ্যাপের সেটিংস খুলুন', 'Open app settings')),
          ),
        ],
      ),
    );
  }
}

class BlockedScreen extends StatefulWidget {
  const BlockedScreen({super.key});
  @override
  State<BlockedScreen> createState() => _BlockedScreenState();
}

class _BlockedScreenState extends State<BlockedScreen> {
  late Future<List<Map<String, dynamic>>> future = cloud.blockedList();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(L('ব্লক করা ইউজার', 'Blocked users'))),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: future,
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final l = snap.data!;
          if (l.isEmpty) {
            return Center(child: Text(L('কাউকে ব্লক করা নেই', 'No blocked users')));
          }
          return ListView(padding: listPad(context, top: 8, bottom: 24), children: [
            for (final u in l)
              ListTile(
                title: Text((u['name'] as String).isEmpty ? (u['uid'] as String) : (u['name'] as String)),
                trailing: TextButton(
                  onPressed: () async {
                    await cloud.unblock(u['uid'] as String);
                    if (mounted) setState(() => future = cloud.blockedList());
                  },
                  child: Text(L('আনব্লক', 'Unblock')),
                ),
              ),
          ]);
        },
      ),
    );
  }
}
