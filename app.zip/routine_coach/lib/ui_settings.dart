import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'cloud.dart';
import 'i18n.dart';
import 'models.dart';
import 'state.dart';
import 'ui_common.dart';

/// সেটিংস: সাধারণ অ্যাপের মতো গ্রুপ করে সাজানো।
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(L('সেটিংস', 'Settings'))),
      body: ListenableBuilder(
        listenable: Listenable.merge([app, cloud]),
        builder: (context, _) => _body(context),
      ),
    );
  }

  Widget _body(BuildContext context) {
    final p = app.prefs;
    final cs = Theme.of(context).colorScheme;
    final weekdays = <int, String>{
      0: L('নেই', 'None'),
      for (var d = 1; d <= 7; d++) d: weekdayName(d),
    };
    return ListView(
      padding: const EdgeInsets.only(bottom: 32),
      children: [
        // ---------- প্রোফাইল ----------
        if (cloud.signedIn)
          ListTile(
            leading: CircleAvatar(
              backgroundImage: cloud.photoUrl.isNotEmpty ? NetworkImage(cloud.photoUrl) : null,
              child: cloud.photoUrl.isEmpty
                  ? Text(cloud.displayName.isEmpty ? 'U' : cloud.displayName.substring(0, 1))
                  : null,
            ),
            title: Text(cloud.displayName.isEmpty ? t('user.default') : cloud.displayName),
            subtitle: Text(cloud.email),
          )
        else
          ListTile(
            leading: const CircleAvatar(child: Icon(Icons.person_outline)),
            title: Text(L('লগইন করা নেই', 'Not signed in')),
            subtitle: Text(Cloud.configured
                ? L('লগইন করলে ডাটা ক্লাউডে সেভ থাকবে', 'Sign in to keep your data in the cloud')
                : L('অনলাইন লগইন এখনো চালু হয়নি', 'Online sign-in is not enabled yet')),
            trailing: Cloud.configured
                ? FilledButton(
                    onPressed: () async {
                      final err = await cloud.signInWithGoogle();
                      if (err != null && context.mounted) snack(context, err);
                    },
                    child: const Text('Google'),
                  )
                : null,
          ),

        // ---------- অ্যালার্ম ও ফোকাস ----------
        groupTitle(context, L('অ্যালার্ম ও ফোকাস', 'Alarm and focus')),
        ListTile(
          leading: const Icon(Icons.shield_outlined),
          title: Text(L('ফোর্স লেভেল', 'Force level')),
          subtitle: Text('${forceLabel(p.force)} • ${forceHint(p.force)}'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const ForceScreen())),
        ),
        ListTile(
          leading: Icon(alertIcon(p.alert)),
          title: Text(L('ডিফল্ট মনে করানোর ধরন', 'Default alert type')),
          subtitle: Text('${alertLabel(p.alert)}\n${alertHint(p.alert)}'),
          isThreeLine: true,
          onTap: () async {
            final v = await pickOne<String>(
              context,
              L('মনে করানোর ধরন', 'Alert type'),
              {for (final k in const ['alarm', 'vibrate', 'notify']) k: alertLabel(k)},
              p.alert,
            );
            if (v != null) {
              p.alert = v;
              await app.savePrefs(replanNow: true);
            }
          },
        ),
        ListTile(
          leading: const Icon(Icons.event_busy),
          title: Text(L('ছুটির দিন (অ্যালার্ম বন্ধ)', 'Day off (no alarms)')),
          subtitle: Text(weekdays[p.offDay] ?? ''),
          onTap: () async {
            final v = await pickOne<int>(context, L('ছুটির দিন', 'Day off'), weekdays, p.offDay);
            if (v != null) {
              p.offDay = v;
              await app.savePrefs(replanNow: true);
            }
          },
        ),
        ListTile(
          leading: const Icon(Icons.verified_user_outlined),
          title: Text(L('পারমিশন ও Xiaomi গাইড', 'Permissions and phone guide')),
          subtitle: Text(L('অ্যালার্ম সময়মতো বাজাতে এগুলো ঠিক করুন', 'Fix these so alarms ring on time')),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const PermScreen())),
        ),

        // ---------- নোটিফিকেশন ----------
        groupTitle(context, L('নোটিফিকেশন', 'Notifications')),
        SwitchListTile(
          secondary: const Icon(Icons.push_pin_outlined),
          title: Text(L('সবসময়-থাকা নোটিফিকেশন', 'Always-on notification')),
          subtitle: Text(L('নোটিফিকেশন বারে পরের কাজ দেখায়', 'Shows your next task in the notification bar')),
          value: p.persistent,
          onChanged: (v) {
            p.persistent = v;
            app.savePrefs();
          },
        ),
        ListTile(
          leading: const Icon(Icons.chat_bubble_outline),
          title: Text(L('সহকারী কতবার খোঁজ নেবে', 'Assistant check-ins per day')),
          subtitle: Text(p.mood == 'quiet'
              ? L('মুড “চুপচাপ” থাকলে খোঁজ নেওয়া হয় না', 'No check-ins while mood is “Quiet”')
              : (p.nudges == 0 ? L('বন্ধ', 'Off') : L('দিনে ${p.nudges} বার', '${p.nudges} per day'))),
          onTap: () async {
            final v = await pickOne<int>(
              context,
              L('দিনে কতবার', 'Per day'),
              {
                0: L('বন্ধ', 'Off'),
                for (var i = 1; i <= 5; i++) i: L('দিনে $i বার', '$i per day'),
              },
              p.nudges,
            );
            if (v != null) {
              p.nudges = v;
              await app.savePrefs();
            }
          },
        ),

        // ---------- সহকারী ----------
        groupTitle(context, L('সহকারী', 'Assistant')),
        ListTile(
          leading: const Icon(Icons.psychology_outlined),
          title: Text(L('মুড', 'Mood')),
          subtitle: Text(moodLabel(p.mood)),
          onTap: () async {
            final v = await pickOne<String>(
              context,
              L('সহকারীর মুড', 'Assistant mood'),
              {for (final k in const ['quiet', 'normal', 'chatty', 'coach']) k: moodLabel(k)},
              p.mood,
            );
            if (v != null) {
              p.mood = v;
              await app.savePrefs();
            }
          },
        ),
        ListTile(
          leading: const Icon(Icons.key_outlined),
          title: const Text('Gemini API key'),
          subtitle: Text(p.geminiKey.isEmpty
              ? L('ঐচ্ছিক: আরও স্মার্ট উত্তরের জন্য', 'Optional: for smarter replies')
              : L('চালু (${p.geminiModel})', 'On (${p.geminiModel})')),
          onTap: () => _geminiDialog(context),
        ),

        // ---------- গোপনীয়তা ও নিরাপত্তা ----------
        groupTitle(context, L('গোপনীয়তা ও নিরাপত্তা', 'Privacy and safety')),
        ListTile(
          leading: const Icon(Icons.public),
          title: Text(L('ডিফল্ট পোস্ট অডিয়েন্স', 'Default post audience')),
          subtitle: Text(p.audience == 'me' ? L('শুধু আমি', 'Only me') : L('সবাই', 'Everyone')),
          onTap: () async {
            final v = await pickOne<String>(
              context,
              L('কে দেখবে', 'Who can see'),
              {'public': L('সবাই', 'Everyone'), 'me': L('শুধু আমি', 'Only me')},
              p.audience,
            );
            if (v != null) {
              p.audience = v;
              await app.savePrefs();
            }
          },
        ),
        ListTile(
          leading: const Icon(Icons.block),
          title: Text(L('ব্লক করা ইউজার', 'Blocked users')),
          subtitle: Text('${cloud.blocked.length}'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const BlockedScreen())),
        ),

        // ---------- চেহারা ও ভাষা ----------
        groupTitle(context, L('চেহারা ও ভাষা', 'Appearance and language')),
        ListTile(
          leading: const Icon(Icons.language),
          title: Text(L('ভাষা', 'Language')),
          subtitle: Text(supportedLanguages[p.lang] ?? p.lang),
          onTap: () async {
            final v = await pickOne<String>(context, L('ভাষা', 'Language'), supportedLanguages, p.lang);
            if (v != null) {
              p.lang = v;
              gLang = v;
              await app.savePrefs();
            }
          },
        ),
        ListTile(
          leading: const Icon(Icons.brightness_6_outlined),
          title: Text(L('থিম', 'Theme')),
          subtitle: Text(_themeLabel(p.theme)),
          onTap: () async {
            final v = await pickOne<String>(
              context,
              L('থিম', 'Theme'),
              {for (final k in const ['system', 'light', 'dark']) k: _themeLabel(k)},
              p.theme,
            );
            if (v != null) {
              p.theme = v;
              await app.savePrefs();
            }
          },
        ),
        ListTile(
          leading: const Icon(Icons.category_outlined),
          title: Text(L('ক্যাটাগরি সম্পাদনা', 'Edit categories')),
          subtitle: Text(p.categories.join(', ')),
          onTap: () => showDialog<void>(context: context, builder: (_) => const _CategoriesDialog()),
        ),

        // ---------- ডাটা ----------
        groupTitle(context, L('ডাটা', 'Data')),
        SwitchListTile(
          secondary: const Icon(Icons.cloud_upload_outlined),
          title: Text(L('ক্লাউড ব্যাকআপ', 'Cloud backup')),
          subtitle: Text(!cloud.signedIn
              ? L('লগইন করলে চালু হবে', 'Available after sign-in')
              : (cloud.lastSync == null
                  ? L('এখনো সেভ হয়নি', 'Not saved yet')
                  : '${L('শেষ সেভ', 'Last saved')}: ${fmtMin(cloud.lastSync!.hour * 60 + cloud.lastSync!.minute)}')),
          value: p.cloudBackup,
          onChanged: cloud.signedIn
              ? (v) async {
                  p.cloudBackup = v;
                  await app.savePrefs();
                  if (v) await cloud.pushNow();
                }
              : null,
        ),

        // ---------- সম্পর্কে ----------
        groupTitle(context, L('সম্পর্কে', 'About')),
        ListTile(
          leading: const Icon(Icons.policy_outlined),
          title: Text(L('গোপনীয়তা নীতি', 'Privacy policy')),
          onTap: () => showDialog<void>(
            context: context,
            builder: (ctx) => AlertDialog(
              title: Text(L('গোপনীয়তা নীতি', 'Privacy policy')),
              content: SingleChildScrollView(
                child: Text(L(
                  'লগইন করলে আপনার Google নাম, ছবি ও ইমেইল শুধু আপনাকে চেনাতে ব্যবহার হয়। আপনার কাজ, রুটিন ও সেটিং আপনার অ্যাকাউন্টের নিচে ব্যাকআপ হিসেবে সেভ হয়; অন্য কেউ দেখতে পায় না। “সবাই” অডিয়েন্সে করা পোস্ট সব ইউজার দেখতে পায়। আপনি যেকোনো সময় পোস্ট মুছতে এবং সেটিংস থেকে পুরো অ্যাকাউন্ট ও ডাটা মুছে ফেলতে পারেন। আমরা আপনার ডাটা বিক্রি করি না।',
                  'When you sign in, your Google name, photo and email are used only to identify you. Your tasks, routines and settings are saved as a private backup under your account; nobody else can see them. Posts with the “Everyone” audience are visible to all users. You can delete posts at any time and delete your whole account and data from Settings. We do not sell your data.',
                )),
              ),
              actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: Text(L('ঠিক আছে', 'OK')))],
            ),
          ),
        ),
        if (cloud.signedIn)
          ListTile(
            leading: const Icon(Icons.logout),
            title: Text(L('লগআউট', 'Sign out')),
            onTap: () async {
              final ok = await confirm(
                context,
                L('লগআউট করবেন?', 'Sign out?'),
                L('এই ফোনের ডাটা মুছে যাবে। আবার লগইন করলে ক্লাউড থেকে ফিরে আসবে।',
                    'Data on this phone will be cleared. It comes back from the cloud when you sign in again.'),
              );
              if (!ok || !context.mounted) return;
              final nav = Navigator.of(context);
              await cloud.signOut();
              nav.popUntil((r) => r.isFirst);
            },
          ),
        if (cloud.signedIn)
          ListTile(
            leading: Icon(Icons.delete_forever_outlined, color: cs.error),
            title: Text(L('অ্যাকাউন্ট মুছুন', 'Delete account'), style: TextStyle(color: cs.error)),
            subtitle: Text(L('সব ডাটা স্থায়ীভাবে যাবে', 'All data will be removed permanently')),
            onTap: () async {
              final ok = await confirm(
                context,
                L('অ্যাকাউন্ট মুছবেন?', 'Delete account?'),
                L('আপনার সব পোস্ট, রুটিন ও ব্যাকআপ স্থায়ীভাবে মুছে যাবে। এটা ফেরানো যাবে না।',
                    'All your posts, routines and backup will be removed permanently. This cannot be undone.'),
                yes: L('মুছে ফেলুন', 'Delete'),
              );
              if (!ok || !context.mounted) return;
              final nav = Navigator.of(context);
              final messenger = ScaffoldMessenger.of(context);
              final err = await cloud.deleteAccount();
              if (err != null) {
                messenger.showSnackBar(SnackBar(content: Text(err)));
              } else {
                nav.popUntil((r) => r.isFirst);
              }
            },
          ),
      ],
    );
  }

  static String _themeLabel(String k) {
    switch (k) {
      case 'light':
        return L('হালকা', 'Light');
      case 'dark':
        return L('গাঢ়', 'Dark');
      default:
        return L('ডিভাইস অনুযায়ী', 'Follow device');
    }
  }

  Future<void> _geminiDialog(BuildContext context) async {
    final key = TextEditingController(text: app.prefs.geminiKey);
    final model = TextEditingController(text: app.prefs.geminiModel);
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Gemini'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(
            L('Google AI Studio থেকে ফ্রি API key নিয়ে বসান। এটা শুধু এই ফোনে থাকে।',
                'Paste a free API key from Google AI Studio. It stays on this phone only.'),
            style: const TextStyle(fontSize: 12),
          ),
          TextField(controller: key, obscureText: true, decoration: const InputDecoration(labelText: 'API key')),
          TextField(controller: model, decoration: InputDecoration(labelText: L('মডেলের নাম', 'Model name'))),
        ]),
        actions: [
          TextButton(
            onPressed: () {
              app.prefs.geminiKey = key.text.trim();
              if (model.text.trim().isNotEmpty) app.prefs.geminiModel = model.text.trim();
              app.savePrefs();
              Navigator.pop(ctx);
            },
            child: Text(L('সংরক্ষণ', 'Save')),
          ),
        ],
      ),
    );
    key.dispose();
    model.dispose();
  }
}

class _CategoriesDialog extends StatefulWidget {
  const _CategoriesDialog();
  @override
  State<_CategoriesDialog> createState() => _CategoriesDialogState();
}

class _CategoriesDialogState extends State<_CategoriesDialog> {
  final ctl = TextEditingController();

  @override
  void dispose() {
    ctl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cats = app.prefs.categories;
    return AlertDialog(
      title: Text(L('ক্যাটাগরি', 'Categories')),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Wrap(spacing: 6, runSpacing: 6, children: [
          for (final c in cats)
            InputChip(
              label: Text(c),
              onDeleted: cats.length > 1
                  ? () {
                      setState(() => cats.remove(c));
                      app.savePrefs();
                    }
                  : null,
            ),
        ]),
        TextField(
          controller: ctl,
          decoration: InputDecoration(
            labelText: L('নতুন ক্যাটাগরি', 'New category'),
            suffixIcon: IconButton(
              icon: const Icon(Icons.add),
              onPressed: () {
                final v = ctl.text.trim();
                if (v.isNotEmpty && !cats.contains(v)) {
                  setState(() => cats.add(v));
                  app.savePrefs();
                }
                ctl.clear();
              },
            ),
          ),
        ),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text(L('ঠিক আছে', 'OK')))],
    );
  }
}

/// ফোর্স: ইউজার নিজেই ঠিক করে অ্যাপ কতটা চাপ দেবে।
class ForceScreen extends StatefulWidget {
  const ForceScreen({super.key});
  @override
  State<ForceScreen> createState() => _ForceScreenState();
}

class _ForceScreenState extends State<ForceScreen> {
  @override
  Widget build(BuildContext context) {
    final p = app.prefs;
    final cs = Theme.of(context).colorScheme;
    final cfg = p.forceFor(p.force);
    return Scaffold(
      appBar: AppBar(title: Text(L('ফোর্স লেভেল', 'Force level'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final k in const ['soft', 'mid', 'hard', 'own'])
              ChoiceChip(
                label: Text(forceLabel(k)),
                selected: p.force == k,
                onSelected: (_) {
                  setState(() => p.force = k);
                  app.savePrefs();
                },
              ),
          ]),
          const SizedBox(height: 8),
          Text(forceHint(p.force), style: TextStyle(color: cs.onSurfaceVariant)),
          const SizedBox(height: 16),
          if (p.force == 'own') ...[
            Text('${L('স্নুজ করা যাবে', 'Snoozes allowed')}: ${p.snoozeMax}'),
            Slider(
              value: p.snoozeMax.toDouble(),
              min: 0,
              max: 5,
              divisions: 5,
              onChanged: (v) => setState(() => p.snoozeMax = v.round()),
              onChangeEnd: (_) => app.savePrefs(),
            ),
            Text('${L('স্নুজের সময়', 'Snooze length')}: ${p.snoozeMin} ${L('মিনিট', 'min')}'),
            Slider(
              value: p.snoozeMin.toDouble(),
              min: 5,
              max: 30,
              divisions: 5,
              onChanged: (v) => setState(() => p.snoozeMin = v.round()),
              onChangeEnd: (_) => app.savePrefs(),
            ),
            Text('${L('“শেষ” চাপতে লাগবে', 'Finish unlocks after')}: ${p.lockPct}%'),
            Slider(
              value: p.lockPct.toDouble(),
              min: 0,
              max: 100,
              divisions: 10,
              onChanged: (v) => setState(() => p.lockPct = v.round()),
              onChangeEnd: (_) => app.savePrefs(),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(L('ব্যাক বাটন আটকানো', 'Block the back button')),
              value: p.blockBack,
              onChanged: (v) {
                setState(() => p.blockBack = v);
                app.savePrefs();
              },
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(L('XP কাটা (স্নুজ বা ছেড়ে দিলে)', 'XP penalty (snooze or give up)')),
              value: p.xpPenalty,
              onChanged: (v) {
                setState(() => p.xpPenalty = v);
                app.savePrefs();
              },
            ),
          ] else
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${L('স্নুজ', 'Snoozes')}: ${cfg.snoozeMax} × ${cfg.snoozeMin} ${L('মিনিট', 'min')}'),
                  Text('${L('“শেষ” চাপতে লাগবে', 'Finish unlocks after')}: ${cfg.lockPct}%'),
                  Text('${L('ব্যাক বাটন', 'Back button')}: ${cfg.blockBack ? L('আটকানো', 'blocked') : L('খোলা', 'free')}'),
                  Text('${L('XP কাটা', 'XP penalty')}: ${cfg.xpPenalty ? L('আছে', 'on') : L('নেই', 'off')}'),
                ]),
              ),
            ),
          const SizedBox(height: 16),
          Text(
            L('মনে রাখবেন: Android ফোন পুরোপুরি লক করতে দেয় না। কড়া মানে হলো বের হলে মূল্য দিতে হবে, ফোন আটকে যাবে না। প্রতিটা কাজে আলাদা কড়াকড়িও দেওয়া যায়।',
                'Note: Android does not allow an app to fully lock the phone. “Strict” means leaving has a cost, not that the phone is locked. You can also set strictness per task.'),
            style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
          ),
        ],
      ),
    );
  }
}

class _PermItem {
  final String title;
  final String desc;
  final Permission perm;
  bool granted = false;
  _PermItem(this.title, this.desc, this.perm);
}

/// পারমিশন গাইড: অ্যালার্ম সময়মতো বাজতে যা লাগে।
class PermScreen extends StatefulWidget {
  const PermScreen({super.key});
  @override
  State<PermScreen> createState() => _PermScreenState();
}

class _PermScreenState extends State<PermScreen> with WidgetsBindingObserver {
  late final List<_PermItem> items = [
    _PermItem(L('নোটিফিকেশন', 'Notifications'),
        L('অ্যালার্ম ও মনে করানো দেখাতে', 'To show alarms and reminders'), Permission.notification),
    _PermItem(L('সঠিক সময়ের অ্যালার্ম', 'Exact alarms'),
        L('ঠিক সময়ে অ্যালার্ম বাজাতে', 'To ring exactly on time'), Permission.scheduleExactAlarm),
    _PermItem(L('ব্যাটারি সেভার থেকে ছাড়', 'Ignore battery optimisation'),
        L('ব্যাকগ্রাউন্ডে অ্যাপ বন্ধ না হতে', 'So the system does not kill the app'), Permission.ignoreBatteryOptimizations),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refresh();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refresh();
  }

  Future<void> _refresh() async {
    for (final i in items) {
      try {
        i.granted = await i.perm.isGranted;
      } catch (_) {
        i.granted = false;
      }
    }
    if (mounted) setState(() {});
  }

  Future<void> _ask(_PermItem i) async {
    try {
      await i.perm.request();
    } catch (_) {}
    await _refresh();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(L('পারমিশন', 'Permissions'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          for (final i in items)
            Card(
              child: ListTile(
                leading: Icon(i.granted ? Icons.check_circle : Icons.error_outline,
                    color: i.granted ? cs.primary : cs.error),
                title: Text(i.title),
                subtitle: Text(i.desc),
                trailing: i.granted
                    ? null
                    : FilledButton(onPressed: () => _ask(i), child: Text(L('অনুমতি দিন', 'Allow'))),
              ),
            ),
          const SizedBox(height: 8),
          Text(L('Xiaomi / MIUI ফোনে হাতে ঠিক করুন', 'On Xiaomi / MIUI phones, set these by hand'),
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Text(
            L('এই অনুমতিগুলো অ্যাপ নিজে চেক করতে পারে না। নিচের বাটনে অ্যাপের সেটিংস খুলবে:\n'
                '1. Autostart চালু করুন।\n'
                '2. Battery saver এ “No restrictions” দিন।\n'
                '3. “Other permissions” এ লক স্ক্রিনে দেখানো ও ব্যাকগ্রাউন্ডে পপআপ দেখানো চালু করুন।\n'
                '4. Recent apps এ অ্যাপটাকে লক (পিন) করে রাখুন।',
                'The app cannot check these itself. The button below opens the app settings:\n'
                '1. Turn on Autostart.\n'
                '2. Set Battery saver to “No restrictions”.\n'
                '3. Under “Other permissions” allow showing on the lock screen and pop-ups while in the background.\n'
                '4. Lock (pin) the app in Recent apps.'),
            style: TextStyle(color: cs.onSurfaceVariant),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () => openAppSettings(),
            icon: const Icon(Icons.settings),
            label: Text(L('অ্যাপের সেটিংস খুলুন', 'Open app settings')),
          ),
        ],
      ),
    );
  }
}

class BlockedScreen extends StatefulWidget {
  const BlockedScreen({super.key});
  @override
  State<BlockedScreen> createState() => _BlockedScreenState();
}

class _BlockedScreenState extends State<BlockedScreen> {
  late Future<List<Map<String, dynamic>>> future = cloud.blockedList();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(L('ব্লক করা ইউজার', 'Blocked users'))),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: future,
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final l = snap.data!;
          if (l.isEmpty) {
            return Center(child: Text(L('কাউকে ব্লক করা নেই', 'No blocked users')));
          }
          return ListView(children: [
            for (final u in l)
              ListTile(
                title: Text((u['name'] as String).isEmpty ? (u['uid'] as String) : (u['name'] as String)),
                trailing: TextButton(
                  onPressed: () async {
                    await cloud.unblock(u['uid'] as String);
                    if (mounted) setState(() => future = cloud.blockedList());
                  },
                  child: Text(L('আনব্লক', 'Unblock')),
                ),
              ),
          ]);
        },
      ),
    );
  }
}
