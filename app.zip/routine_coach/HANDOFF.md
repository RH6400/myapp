# MAILO — AI HANDOFF SPEC (fill-in form)

Purpose: let another AI system continue the Mailo redesign without prior chat context.
Project = Flutter Android app in this folder (`routine_coach`), formerly "Uthan", now **Mailo**.
Owner: "md" (Bangladesh). Owner talks to the assistant in Bangla; **all code, comments-in-code, and this spec stay in English**.

---------------------------------------------------------------------
## 0. HOW TO WORK WITH THE OWNER (hard rules)
- Reply to the owner in **Bangla** in chat. Be direct, no preamble.
- Deliver **complete files** (full replacements), never partial diffs.
- Show/confirm a **mockup or plan before implementing** anything not already in the mockups.
- **Consult before changing** behaviour that exists today (alarms, planner, cloud sync).
- Work in small steps; each step must build on its own (no half-broken state).
- The build is done by the owner via GitHub Actions (repo `RH6400/myapp`, runs `setup.sh`). No Flutter SDK was available when step 1 was written, so **nothing has been compiled yet** (only bracket-balance checked). First job of any new AI: run `flutter analyze` / build and fix errors.

## 1. DO NOT BREAK
- applicationId stays `com.rh6400.uthan` (so installs update in place; Firebase/Google sign-in keep working). Only the visible label changed to "Mailo".
- Notification channel ids stay `uthan_persistent`, `uthan_nudge`, … (renaming creates new channels).
- Keystore env vars `UTHAN_KEYSTORE` / `UTHAN_PASS` in `setup.sh` stay as they are.
- `setup.sh` runs `flutter create` on every build, then patches gradle/manifest, then copies `assets/android_res/*` over `android/app/src/main/res/` (launcher + notification icons).
- Language switch: `L('বাংলা', 'English')` in `i18n.dart`; Bangla digits via `nd(value)`. Every new UI string needs both languages.
- Persistence is in `state.dart` (`app` singleton, `ChangeNotifier`, JSON in shared_preferences + optional Firestore via `cloud.dart`). New saved fields must be optional in `fromJson` (old data must still load).

## 2. DESIGN TOKENS (from mockups)
| token | light | dark |
|---|---|---|
| primary blue | `#2563EB` | `#6B93FF` |
| accent orange | `#FF8A00` | same |
| navy text | `#0B1B5C` | `#E8ECFA` |
| background | `#F4F6FC` | `#0A1020` |
| card | `#FFFFFF` | `#141B2E` |
| green (done) | `#16A34A` | same |
| red (behind/skipped) | `#DC2626` | same |
All defined in `lib/theme.dart` (`mailoTheme(Brightness)`). Cards radius ~16–20, chips are pills, FAB is a rounded square with "+".
Bottom tabs (final, decided by owner): **আজ (Today) · কাজ (Tasks) · Mailo (AI) · সারাংশ (Summary) · কমিউনিটি (Community)**. The Mailo tab icon is the mascot image, not a Material icon.

## 3. ASSETS (all in `assets/`, declared in `pubspec.yaml`)
| file | what | use |
|---|---|---|
| `mailo_logo.png` | M mark, transparent | app identity: top-right of Today (tap = Settings), splash |
| `mailo_logo_full.png` | M + "Mailo" + tagline | login screen |
| `mailo_ai_still.png` | eyes-M mascot, frame 0, transparent | **AI icon everywhere** at small sizes (nav, chat avatar, cards, "Mailo বলছে") |
| `mailo_ai.webp` | mascot, 4.3 s loop, transparent, animated | medium spots |
| `mailo_ai_idle.webp` | mascot, 10 s loop (blink/look/jump), transparent, animated | big spots: Mailo tab empty state, alarm/ring screen |
| `android_res/mipmap-*/ic_launcher.png` | launcher icon (M on white) | copied by `setup.sh` |
| `android_res/drawable-*/ic_notif.png` | white M silhouette | status-bar notification icon |
Rule from owner: **wherever the AI appears, use the mascot** (`MailoAi` / `MailoAiBadge` in `lib/mailo_widgets.dart`). Source mockup images: see section 6.

## 4. DONE — STEP 1 (written, NOT yet compiled)
| # | item | files |
|---|---|---|
| D1 | Rename Uthan → Mailo (app label, app title, notification titles, login) | `setup.sh`, `main.dart`, `notif.dart`, `ui_login.dart` |
| D2 | New light/dark theme (blue/orange/navy) | `theme.dart` (new) |
| D3 | Shared widgets: `MailoLogo`, `MailoAi` (still/animated/idle), `MailoAiBadge`, `TabHeader`, `openSettings`, date/greeting helpers (`dayFull`, `monthName`, `greetingFor`) | `mailo_widgets.dart` (new) |
| D4 | Bangla digit helper `nd()` | `i18n.dart` |
| D5 | Bottom nav with 5 tabs; no AppBar; each tab has own header; Summary tab temporarily shows the old `RewardsTab`, Mailo tab shows old `AssistantTab` under a mascot header | `main.dart` |
| D6 | Today screen: greeting + date, streak chip, logo (opens Settings), Sat–Fri week strip, progress ring card + level chip, timeline cards (green/blue bar, next pending card highlighted with play button, move/skip menu kept), FAB "+" → `AddTaskSheet` | `ui_home.dart` |
| D7 | Tasks screen: header + settings, filter chips (all / daily / specific days / one day), task cards with enable switch, free-time windows section, FAB | `ui_tasks.dart` |
| D8 | New field `TaskItem.enabled` (default true; disabled tasks never enter the plan) + `app.setTaskEnabled()` | `models.dart`, `state.dart` |
| D9 | Login screen uses the full logo | `ui_login.dart` |
| D10 | Launcher + notification icons generated, installed by `setup.sh`; notification small icon = `ic_notif` | `assets/android_res`, `setup.sh`, `notif.dart` |
| D11 | Mascot assets cut from the owner's GIF and MP4 (background removed, shadow removed) | `assets/` |

Known deviations from mockup (confirm with owner): move/skip "⋮" menu kept on pending timeline cards (mockup shows only ▶); search icon on Tasks header not implemented yet.

## 5. FUTURE WORK — one form per task
Fill the `Status` / `Notes` lines when done. Order: S2 → S3 → S4. Each form is self-contained.

### FORM S2-1 — Mailo (AI chat) tab restyle
- Reference mockups: `20260.png` (right phone), `20263.png` (left phone)
- Goal: chat screen like mockup: header = `MailoAiBadge` + "Mailo" + "আপনার সহকারী • অনলাইন" + ⋮ menu; assistant bubbles white/left, user bubbles blue/right; tappable suggestion chips under assistant messages; bottom quick chips ("আজ কী বাকি?", "কাজ যোগ করো", "সময় সরাও"); pill input with mic icon.
- Files: `ui_assistant.dart` (restyle only), `main.dart` (remove the temporary `_wrap` for this tab), `mailo_widgets.dart`.
- Reuse: `assistant.dart` logic untouched.
- Open question for owner: mic button — voice input needed, or visual only? (default: visual only, disabled)
- Empty state: show `MailoAi(idle: true, width: 220)`.
- Acceptance: all existing assistant commands still work; works in dark mode; Bangla + English.
- Status: [ ] todo   Notes: ______

### FORM S2-2 — Summary (সারাংশ) tab
- Reference: `20262.png` (left), `20263.png` (left: plan card)
- Goal: new `ui_summary.dart`. Period dropdown (this week). Card: ring % + "N tasks, M done", stats row (done / left / skipped / streak days) using `app.weekStats()` and existing counters. "Mailo বলছে" card with mascot + one insight + action chips ("হ্যাঁ, সরাও" / "থাক") driven by `insights.dart` (check what it already produces). "আমার লক্ষ্য" list: goal cards with title, progress text (e.g. 18/30 days), coloured progress bar and status pill (on track = green, slightly behind = orange, behind = red).
- Data model change: new `Goal` {id, title, target, unit, deadline?, progress source}. Needs owner confirmation of how progress is computed (auto from a task category vs manual). Must be optional in `fromJson`.
- Files: `ui_summary.dart` (new), `models.dart`, `state.dart`, `main.dart` (swap `RewardsTab` for `SummaryTab`).
- Acceptance: empty-state when no goals; numbers match Today screen; dark mode.
- Status: [ ] todo   Notes: ______

### FORM S2-3 — Rewards (পুরস্কার) screen
- Reference: `20262.png` (right phone)
- Goal: screen opened from Summary (back arrow, not a tab). Top toggle "অ্যাপের XP ও ব্যাজ" (when off, only user-defined rewards remain). Reward cards: condition + prize + days/tasks left + progress bar; claimed state = orange card with "নিলাম 🎉". Dashed "+ নতুন পুরস্কার যোগ করুন" button. Mailo hint card with mascot.
- Data model: new `Reward` {id, prize, condition type (days of a goal / all week tasks / streak N), claimed}. Keep existing XP/achievements (`state.dart` `achievementList`) working; the toggle only hides them.
- Files: `ui_rewards.dart` (rewrite; keep old badge list as a section if toggle on), `models.dart`, `state.dart`.
- Status: [ ] todo   Notes: ______

### FORM S2-4 — Goal → plan via chat
- Reference: `20263.png` (left phone)
- Goal: when the user types a goal ("২ মাসে ৫ কেজি কমাতে চাই, অফিস ৯–৬"), Mailo replies with a plan card (goal, weekly tasks, milestone) and chips "রুটিনে যোগ করো / বদলাতে চাই / পরে". "রুটিনে যোগ করো" creates tasks via `app.addTaskChecked`. Follow-up bubble suggests a reward (links to S2-3).
- Check first: what `assistant.dart` can already parse. If it is rule-based, extend rules; do not add a network LLM call without owner approval.
- Status: [ ] todo   Notes: ______

### FORM S3-1 — New-task sheet restyle
- Reference: `20260.png` (left phone)
- Goal: restyle `AddTaskSheet` (in `ui_tasks.dart`): rounded sheet, fields "কাজের নাম", "সময়" (auto / fixed) + "সময়কাল", "কবে" day chips, 3 alert tiles (অ্যালার্ম / ভাইব্রেশন / নোটিফিকেশন), "কড়াকড়ি" row with chevron, big blue "সেভ করুন" button. All current options stay (category, priority, part of day, one-day date).
- Status: [ ] todo   Notes: ______

### FORM S3-2 — Settings restyle
- Reference: `20261.png` (left phone)
- Goal: grouped cards with icon tiles: "অ্যালার্ম ও ফোকাস" (default alert, strictness), "নোটিফিকেশন" (always-on notification switch, assistant check-in switch), "সহকারী" (assistant name editable, assistant mood). Keep every existing setting (theme, language, off-day, permissions, categories, account) — group them, do not delete.
- New prefs: `assistantName` (default "Mailo"), `assistantMood` (e.g. normal / gentle / strict) — optional in prefs JSON; the name must appear in chat header and notifications.
- Status: [ ] todo   Notes: ______

### FORM S3-3 — Alarm / ring screen with mascot
- Reference: `20263.png` (right phone, bottom card)
- Goal: `RingScreen`/`FocusScreen` in `ui_alarm.dart`: centered `MailoAi(idle: true)`, bold task title ("ব্যায়াম শুরুর সময়!"), one motivating line (e.g. streak-saving text), existing buttons kept (start / snooze / skip).
- Status: [ ] todo   Notes: ______

### FORM S3-4 — Notifications
- Reference: `20263.png` (right phone, top)
- Goal: heads-up notification with Mailo title, task + progress text, action buttons "শুরু করি" and "১০ মিনিট পরে" (flutter_local_notifications actions). Small icon `ic_notif` already set. Large icon: `mailo_ai_still.png` as bitmap (needs a drawable copy under `assets/android_res/drawable-*/`).
- Status: [ ] todo   Notes: ______

### FORM S3-5 — Tasks search + dark-mode & polish pass
- Reference: `20259.png` (right), `20261.png` (right = dark Today)
- Goal: search icon on Tasks header filters by title; compare every screen against the mockups in dark mode; community tab header/cards restyled to match; check text overflow with long Bangla strings and large system font.
- Status: [ ] todo   Notes: ______

### FORM S4 — QA / release
- Run `flutter analyze`; fix errors/warnings introduced by steps 1–3.
- Test on a real Android 13/14 device: exact alarms, full-screen alarm, notification icon, app icon, boot reschedule.
- Verify old saved data loads (no `enabled` field → true).
- Status: [ ] todo   Notes: ______

### BLANK TEMPLATE (copy for any new task)
```
### FORM <ID> — <title>
- Reference mockup: <file(s) + which phone>
- Goal: <what the screen/behaviour must do>
- Files to touch: <list>
- Reuse: <existing code>
- Data model change: <none | fields, optional in fromJson>
- Constraints: <from sections 0–1>
- Acceptance: <testable checks>
- Open question for owner: <or none>
- Status: [ ] todo   Notes: ______
```

## 6. MOCKUP FILE MAP (owner uploads)
| file | content |
|---|---|
| `20245.png` | full logo (M + "Mailo" + tagline "Plan Today. Live Better.") |
| `20258.gif` | animated mascot (eyes-M) = AI icon source |
| `20259.png` | left: Today (light); right: Tasks list |
| `20260.png` | left: new-task bottom sheet; right: Mailo chat |
| `20261.png` | left: Settings; right: Today (dark) |
| `20262.png` | left: Summary; right: Rewards |
| `20263.png` | left: chat creating a goal plan; right: notifications + alarm screen with mascot |
| `20659.mp4` | 10 s mascot animation (source of `mailo_ai_idle.webp`) |
Note: some mockups show a 5-tab bar with "আমি" or with an icon set different from the final one; **the final tab set is the one in section 2.**

## 7. REPORT FORMAT WHEN A TASK IS DONE
Return: (1) list of complete changed files, (2) one-line summary per file, (3) any new optional fields, (4) what was NOT verified, (5) questions for the owner in Bangla.
